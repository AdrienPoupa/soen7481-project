-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2018 at 11:42 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cachet`
--

-- --------------------------------------------------------

--
-- Table structure for table `actions`
--

CREATE TABLE `actions` (
  `id` int(10) UNSIGNED NOT NULL,
  `class_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `information` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `components`
--

CREATE TABLE `components` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` text COLLATE utf8mb4_unicode_ci,
  `status` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `meta` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `components`
--

INSERT INTO `components` (`id`, `name`, `description`, `link`, `status`, `order`, `group_id`, `enabled`, `meta`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:33:56', '2018-12-11 03:33:56', NULL),
(2, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:33:56', '2018-12-11 03:33:56', NULL),
(3, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:33:56', '2018-12-11 03:33:56', NULL),
(4, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:33:56', '2018-12-11 03:33:56', NULL),
(5, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:33:56', '2018-12-11 03:33:56', NULL),
(6, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:33:57', '2018-12-11 03:33:57', NULL),
(7, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:33:57', '2018-12-11 03:33:57', NULL),
(8, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:33:57', '2018-12-11 03:33:57', NULL),
(9, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:33:57', '2018-12-11 03:33:57', NULL),
(10, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:33:57', '2018-12-11 03:33:57', NULL),
(11, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:33:57', '2018-12-11 03:33:57', NULL),
(12, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:33:57', '2018-12-11 03:33:57', NULL),
(13, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:33:57', '2018-12-11 03:33:57', NULL),
(14, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:33:57', '2018-12-11 03:33:57', NULL),
(15, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:33:57', '2018-12-11 03:33:57', NULL),
(16, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:33:58', '2018-12-11 03:33:58', NULL),
(17, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:33:58', '2018-12-11 03:33:58', NULL),
(18, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:33:58', '2018-12-11 03:33:58', NULL),
(19, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:33:58', '2018-12-11 03:33:58', NULL),
(20, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:33:58', '2018-12-11 03:33:58', NULL),
(21, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:33:58', '2018-12-11 03:33:58', NULL),
(22, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:33:58', '2018-12-11 03:33:58', NULL),
(23, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:33:58', '2018-12-11 03:33:58', NULL),
(24, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:33:58', '2018-12-11 03:33:58', NULL),
(25, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:33:58', '2018-12-11 03:33:58', NULL),
(26, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:33:59', '2018-12-11 03:33:59', NULL),
(27, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:33:59', '2018-12-11 03:33:59', NULL),
(28, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:33:59', '2018-12-11 03:33:59', NULL),
(29, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:33:59', '2018-12-11 03:33:59', NULL),
(30, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:33:59', '2018-12-11 03:33:59', NULL),
(31, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:33:59', '2018-12-11 03:33:59', NULL),
(32, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:33:59', '2018-12-11 03:33:59', NULL),
(33, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:33:59', '2018-12-11 03:33:59', NULL),
(34, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:33:59', '2018-12-11 03:33:59', NULL),
(35, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:33:59', '2018-12-11 03:33:59', NULL),
(36, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:33:59', '2018-12-11 03:33:59', NULL),
(37, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:33:59', '2018-12-11 03:33:59', NULL),
(38, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:33:59', '2018-12-11 03:33:59', NULL),
(39, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:00', '2018-12-11 03:34:00', NULL),
(40, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:00', '2018-12-11 03:34:00', NULL),
(41, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:00', '2018-12-11 03:34:00', NULL),
(42, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:00', '2018-12-11 03:34:00', NULL),
(43, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:00', '2018-12-11 03:34:00', NULL),
(44, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:00', '2018-12-11 03:34:00', NULL),
(45, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:00', '2018-12-11 03:34:00', NULL),
(46, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:00', '2018-12-11 03:34:00', NULL),
(47, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:01', '2018-12-11 03:34:01', NULL),
(48, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:01', '2018-12-11 03:34:01', NULL),
(49, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:01', '2018-12-11 03:34:01', NULL),
(50, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:01', '2018-12-11 03:34:01', NULL),
(51, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:01', '2018-12-11 03:34:01', NULL),
(52, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:01', '2018-12-11 03:34:01', NULL),
(53, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:01', '2018-12-11 03:34:01', NULL),
(54, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:01', '2018-12-11 03:34:01', NULL),
(55, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:02', '2018-12-11 03:34:02', NULL),
(56, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:02', '2018-12-11 03:34:02', NULL),
(57, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:02', '2018-12-11 03:34:02', NULL),
(58, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:02', '2018-12-11 03:34:02', NULL),
(59, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:02', '2018-12-11 03:34:02', NULL),
(60, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:02', '2018-12-11 03:34:02', NULL),
(61, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:02', '2018-12-11 03:34:02', NULL),
(62, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:02', '2018-12-11 03:34:02', NULL),
(63, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:02', '2018-12-11 03:34:02', NULL),
(64, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:03', '2018-12-11 03:34:03', NULL),
(65, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:03', '2018-12-11 03:34:03', NULL),
(66, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:03', '2018-12-11 03:34:03', NULL),
(67, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:03', '2018-12-11 03:34:03', NULL),
(68, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:03', '2018-12-11 03:34:03', NULL),
(69, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:03', '2018-12-11 03:34:03', NULL),
(70, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:03', '2018-12-11 03:34:03', NULL),
(71, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:03', '2018-12-11 03:34:03', NULL),
(72, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:03', '2018-12-11 03:34:03', NULL),
(73, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:03', '2018-12-11 03:34:03', NULL),
(74, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:03', '2018-12-11 03:34:03', NULL),
(75, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:04', '2018-12-11 03:34:04', NULL),
(76, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:04', '2018-12-11 03:34:04', NULL),
(77, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:04', '2018-12-11 03:34:04', NULL),
(78, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:04', '2018-12-11 03:34:04', NULL),
(79, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:04', '2018-12-11 03:34:04', NULL),
(80, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:04', '2018-12-11 03:34:04', NULL),
(81, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:04', '2018-12-11 03:34:04', NULL),
(82, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:04', '2018-12-11 03:34:04', NULL),
(83, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:04', '2018-12-11 03:34:04', NULL),
(84, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:05', '2018-12-11 03:34:05', NULL),
(85, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:05', '2018-12-11 03:34:05', NULL),
(86, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:05', '2018-12-11 03:34:05', NULL),
(87, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:05', '2018-12-11 03:34:05', NULL),
(88, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:05', '2018-12-11 03:34:05', NULL),
(89, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:05', '2018-12-11 03:34:05', NULL),
(90, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:05', '2018-12-11 03:34:05', NULL),
(91, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:05', '2018-12-11 03:34:05', NULL),
(92, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:05', '2018-12-11 03:34:05', NULL),
(93, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:05', '2018-12-11 03:34:05', NULL),
(94, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:05', '2018-12-11 03:34:05', NULL),
(95, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:05', '2018-12-11 03:34:05', NULL),
(96, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:05', '2018-12-11 03:34:05', NULL),
(97, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:05', '2018-12-11 03:34:05', NULL),
(98, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:05', '2018-12-11 03:34:05', NULL),
(99, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:06', '2018-12-11 03:34:06', NULL),
(100, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:06', '2018-12-11 03:34:06', NULL),
(101, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:06', '2018-12-11 03:34:06', NULL),
(102, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:06', '2018-12-11 03:34:06', NULL),
(103, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:06', '2018-12-11 03:34:06', NULL),
(104, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:06', '2018-12-11 03:34:06', NULL),
(105, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:06', '2018-12-11 03:34:06', NULL),
(106, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:06', '2018-12-11 03:34:06', NULL),
(107, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:06', '2018-12-11 03:34:06', NULL),
(108, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:06', '2018-12-11 03:34:06', NULL),
(109, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:06', '2018-12-11 03:34:06', NULL),
(110, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:07', '2018-12-11 03:34:07', NULL),
(111, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:07', '2018-12-11 03:34:07', NULL),
(112, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:07', '2018-12-11 03:34:07', NULL),
(113, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:07', '2018-12-11 03:34:07', NULL),
(114, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:07', '2018-12-11 03:34:07', NULL),
(115, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:07', '2018-12-11 03:34:07', NULL),
(116, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:07', '2018-12-11 03:34:07', NULL),
(117, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:08', '2018-12-11 03:34:08', NULL),
(118, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:08', '2018-12-11 03:34:08', NULL),
(119, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:08', '2018-12-11 03:34:08', NULL),
(120, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:08', '2018-12-11 03:34:08', NULL),
(121, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:08', '2018-12-11 03:34:08', NULL),
(122, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:08', '2018-12-11 03:34:08', NULL),
(123, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:08', '2018-12-11 03:34:08', NULL),
(124, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:08', '2018-12-11 03:34:08', NULL),
(125, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:08', '2018-12-11 03:34:08', NULL),
(126, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:08', '2018-12-11 03:34:08', NULL),
(127, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:08', '2018-12-11 03:34:08', NULL),
(128, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:09', '2018-12-11 03:34:09', NULL),
(129, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:09', '2018-12-11 03:34:09', NULL),
(130, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:09', '2018-12-11 03:34:09', NULL),
(131, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:09', '2018-12-11 03:34:09', NULL),
(132, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:09', '2018-12-11 03:34:09', NULL),
(133, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:09', '2018-12-11 03:34:09', NULL),
(134, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:09', '2018-12-11 03:34:09', NULL),
(135, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:09', '2018-12-11 03:34:09', NULL),
(136, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:09', '2018-12-11 03:34:09', NULL),
(137, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:09', '2018-12-11 03:34:09', NULL),
(138, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:09', '2018-12-11 03:34:09', NULL),
(139, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:09', '2018-12-11 03:34:09', NULL),
(140, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:09', '2018-12-11 03:34:09', NULL),
(141, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:10', '2018-12-11 03:34:10', NULL),
(142, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:10', '2018-12-11 03:34:10', NULL),
(143, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:10', '2018-12-11 03:34:10', NULL),
(144, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:10', '2018-12-11 03:34:10', NULL),
(145, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:10', '2018-12-11 03:34:10', NULL),
(146, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:10', '2018-12-11 03:34:10', NULL),
(147, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:10', '2018-12-11 03:34:10', NULL),
(148, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:10', '2018-12-11 03:34:10', NULL),
(149, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:10', '2018-12-11 03:34:10', NULL),
(150, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:10', '2018-12-11 03:34:10', NULL),
(151, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:10', '2018-12-11 03:34:10', NULL),
(152, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:10', '2018-12-11 03:34:10', NULL),
(153, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:10', '2018-12-11 03:34:10', NULL),
(154, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:11', '2018-12-11 03:34:11', NULL),
(155, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:11', '2018-12-11 03:34:11', NULL),
(156, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:11', '2018-12-11 03:34:11', NULL),
(157, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:11', '2018-12-11 03:34:11', NULL),
(158, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:12', '2018-12-11 03:34:12', NULL),
(159, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:12', '2018-12-11 03:34:12', NULL),
(160, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:13', '2018-12-11 03:34:13', NULL),
(161, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:14', '2018-12-11 03:34:14', NULL),
(162, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:14', '2018-12-11 03:34:14', NULL),
(163, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:15', '2018-12-11 03:34:15', NULL),
(164, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:15', '2018-12-11 03:34:15', NULL),
(165, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:15', '2018-12-11 03:34:15', NULL),
(166, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:16', '2018-12-11 03:34:16', NULL),
(167, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:16', '2018-12-11 03:34:16', NULL),
(168, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:16', '2018-12-11 03:34:16', NULL),
(169, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:16', '2018-12-11 03:34:16', NULL),
(170, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:16', '2018-12-11 03:34:16', NULL),
(171, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:16', '2018-12-11 03:34:16', NULL),
(172, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:16', '2018-12-11 03:34:16', NULL),
(173, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:16', '2018-12-11 03:34:16', NULL),
(174, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:17', '2018-12-11 03:34:17', NULL),
(175, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:17', '2018-12-11 03:34:17', NULL),
(176, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:17', '2018-12-11 03:34:17', NULL),
(177, 'Blog', 'The Alt Three Blog.', 'https://blog.alt-three.com', 1, 0, 2, 1, NULL, '2018-12-11 03:34:17', '2018-12-11 03:34:17', NULL),
(178, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:17', '2018-12-11 03:34:17', NULL),
(179, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:17', '2018-12-11 03:34:17', NULL),
(180, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:17', '2018-12-11 03:34:17', NULL),
(181, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:17', '2018-12-11 03:34:17', NULL),
(182, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:17', '2018-12-11 03:34:17', NULL),
(183, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:17', '2018-12-11 03:34:17', NULL),
(184, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:18', '2018-12-11 03:34:18', NULL),
(185, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:18', '2018-12-11 03:34:18', NULL),
(186, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:18', '2018-12-11 03:34:18', NULL),
(187, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:18', '2018-12-11 03:34:18', NULL),
(188, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:18', '2018-12-11 03:34:18', NULL),
(189, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:18', '2018-12-11 03:34:18', NULL),
(190, 'GitHub', '', 'https://github.com/CachetHQ/Cachet', 1, 0, 0, 1, NULL, '2018-12-11 03:34:18', '2018-12-11 03:34:18', NULL),
(191, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:18', '2018-12-11 03:34:18', NULL),
(192, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:19', '2018-12-11 03:34:19', NULL),
(193, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:19', '2018-12-11 03:34:19', NULL),
(194, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:19', '2018-12-11 03:34:19', NULL),
(195, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:19', '2018-12-11 03:34:19', NULL),
(196, 'StyleCI', 'The PHP Coding Style Service.', 'https://styleci.io', 1, 1, 2, 1, NULL, '2018-12-11 03:34:19', '2018-12-11 03:34:19', NULL),
(197, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:19', '2018-12-11 03:34:19', NULL),
(198, 'Documentation', 'Kindly powered by Readme.io', 'https://docs.cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:19', '2018-12-11 03:34:19', NULL),
(199, 'API', 'Used by third-parties to connect to us', '', 1, 0, 0, 1, NULL, '2018-12-11 03:34:19', '2018-12-11 03:34:19', NULL),
(200, 'Website', '', 'https://cachethq.io', 1, 0, 1, 1, NULL, '2018-12-11 03:34:19', '2018-12-11 03:34:19', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `component_groups`
--

CREATE TABLE `component_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  `visible` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `collapsed` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `component_groups`
--

INSERT INTO `component_groups` (`id`, `name`, `order`, `visible`, `collapsed`, `created_at`, `updated_at`) VALUES
(1, 'Websites', 1, 0, 0, '2018-12-11 03:33:55', '2018-12-11 03:33:55'),
(2, 'Alt Three', 2, 1, 1, '2018-12-11 03:33:55', '2018-12-11 03:33:55');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` int(10) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `incidents`
--

CREATE TABLE `incidents` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `component_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `stickied` tinyint(1) NOT NULL DEFAULT '0',
  `notifications` tinyint(1) NOT NULL DEFAULT '0',
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `occurred_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `incidents`
--

INSERT INTO `incidents` (`id`, `user_id`, `component_id`, `name`, `status`, `visible`, `stickied`, `notifications`, `message`, `occurred_at`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:20', '2018-12-11 03:34:20', NULL),
(2, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:21', '2018-12-11 03:34:21', NULL),
(3, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:21', '2018-12-11 03:34:21', NULL),
(4, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:21', '2018-12-11 03:34:21', NULL),
(5, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:22', '2018-12-11 03:34:22', NULL),
(6, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:22', '2018-12-11 03:34:22', NULL),
(7, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:22', '2018-12-11 03:34:22', NULL),
(8, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:22', '2018-12-11 03:34:22', NULL),
(9, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:22', '2018-12-11 03:34:22', NULL),
(10, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:22', '2018-12-11 03:34:22', NULL),
(11, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:22', '2018-12-11 03:34:22', NULL),
(12, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:22', '2018-12-11 03:34:22', NULL),
(13, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:23', '2018-12-11 03:34:23', NULL),
(14, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:23', '2018-12-11 03:34:23', NULL),
(15, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:23', '2018-12-11 03:34:23', NULL),
(16, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:23', '2018-12-11 03:34:23', NULL),
(17, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:23', '2018-12-11 03:34:23', NULL),
(18, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:24', '2018-12-11 03:34:24', NULL),
(19, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:24', '2018-12-11 03:34:24', NULL),
(20, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:24', '2018-12-11 03:34:24', NULL),
(21, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:24', '2018-12-11 03:34:24', NULL),
(22, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:24', '2018-12-11 03:34:24', NULL),
(23, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:24', '2018-12-11 03:34:24', NULL),
(24, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:25', '2018-12-11 03:34:25', NULL),
(25, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:25', '2018-12-11 03:34:25', NULL),
(26, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:25', '2018-12-11 03:34:25', NULL),
(27, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:25', '2018-12-11 03:34:25', NULL),
(28, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:25', '2018-12-11 03:34:25', NULL),
(29, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:25', '2018-12-11 03:34:25', NULL),
(30, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:25', '2018-12-11 03:34:25', NULL),
(31, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:26', '2018-12-11 03:34:26', NULL),
(32, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:26', '2018-12-11 03:34:26', NULL),
(33, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:26', '2018-12-11 03:34:26', NULL),
(34, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:26', '2018-12-11 03:34:26', NULL),
(35, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:26', '2018-12-11 03:34:26', NULL),
(36, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:26', '2018-12-11 03:34:26', NULL),
(37, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:27', '2018-12-11 03:34:27', NULL),
(38, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:27', '2018-12-11 03:34:27', NULL),
(39, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:27', '2018-12-11 03:34:27', NULL),
(40, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:27', '2018-12-11 03:34:27', NULL),
(41, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:27', '2018-12-11 03:34:27', NULL),
(42, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:27', '2018-12-11 03:34:27', NULL),
(43, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:27', '2018-12-11 03:34:27', NULL),
(44, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:27', '2018-12-11 03:34:27', NULL),
(45, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:28', '2018-12-11 03:34:28', NULL),
(46, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:28', '2018-12-11 03:34:28', NULL),
(47, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:28', '2018-12-11 03:34:28', NULL),
(48, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:28', '2018-12-11 03:34:28', NULL),
(49, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:28', '2018-12-11 03:34:28', NULL),
(50, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:29', '2018-12-11 03:34:29', NULL),
(51, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:29', '2018-12-11 03:34:29', NULL),
(52, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:29', '2018-12-11 03:34:29', NULL),
(53, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:29', '2018-12-11 03:34:29', NULL),
(54, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:29', '2018-12-11 03:34:29', NULL),
(55, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:29', '2018-12-11 03:34:29', NULL),
(56, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:29', '2018-12-11 03:34:29', NULL),
(57, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:30', '2018-12-11 03:34:30', NULL),
(58, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:30', '2018-12-11 03:34:30', NULL),
(59, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:30', '2018-12-11 03:34:30', NULL),
(60, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:30', '2018-12-11 03:34:30', NULL),
(61, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:30', '2018-12-11 03:34:30', NULL),
(62, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:30', '2018-12-11 03:34:30', NULL),
(63, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:30', '2018-12-11 03:34:30', NULL),
(64, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:31', '2018-12-11 03:34:31', NULL),
(65, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:31', '2018-12-11 03:34:31', NULL),
(66, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:31', '2018-12-11 03:34:31', NULL),
(67, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:31', '2018-12-11 03:34:31', NULL),
(68, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:31', '2018-12-11 03:34:31', NULL),
(69, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:31', '2018-12-11 03:34:31', NULL),
(70, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:31', '2018-12-11 03:34:31', NULL),
(71, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:31', '2018-12-11 03:34:31', NULL),
(72, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:32', '2018-12-11 03:34:32', NULL),
(73, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:32', '2018-12-11 03:34:32', NULL),
(74, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:32', '2018-12-11 03:34:32', NULL),
(75, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:32', '2018-12-11 03:34:32', NULL),
(76, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:32', '2018-12-11 03:34:32', NULL),
(77, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:33', '2018-12-11 03:34:33', NULL),
(78, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:33', '2018-12-11 03:34:33', NULL),
(79, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:33', '2018-12-11 03:34:33', NULL),
(80, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:33', '2018-12-11 03:34:33', NULL),
(81, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:33', '2018-12-11 03:34:33', NULL),
(82, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:33', '2018-12-11 03:34:33', NULL),
(83, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:34', '2018-12-11 03:34:34', NULL),
(84, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:34', '2018-12-11 03:34:34', NULL),
(85, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:34', '2018-12-11 03:34:34', NULL),
(86, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:34', '2018-12-11 03:34:34', NULL),
(87, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:34', '2018-12-11 03:34:34', NULL),
(88, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:34', '2018-12-11 03:34:34', NULL),
(89, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:35', '2018-12-11 03:34:35', NULL),
(90, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:35', '2018-12-11 03:34:35', NULL),
(91, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:35', '2018-12-11 03:34:35', NULL),
(92, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:35', '2018-12-11 03:34:35', NULL),
(93, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:35', '2018-12-11 03:34:35', NULL),
(94, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:35', '2018-12-11 03:34:35', NULL),
(95, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:36', '2018-12-11 03:34:36', NULL),
(96, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:36', '2018-12-11 03:34:36', NULL),
(97, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:36', '2018-12-11 03:34:36', NULL),
(98, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:36', '2018-12-11 03:34:36', NULL),
(99, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:36', '2018-12-11 03:34:36', NULL),
(100, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:36', '2018-12-11 03:34:36', NULL),
(101, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:37', '2018-12-11 03:34:37', NULL),
(102, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:37', '2018-12-11 03:34:37', NULL),
(103, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:37', '2018-12-11 03:34:37', NULL),
(104, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:37', '2018-12-11 03:34:37', NULL),
(105, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:38', '2018-12-11 03:34:38', NULL),
(106, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:38', '2018-12-11 03:34:38', NULL),
(107, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:38', '2018-12-11 03:34:38', NULL),
(108, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:38', '2018-12-11 03:34:38', NULL),
(109, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:38', '2018-12-11 03:34:38', NULL),
(110, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:39', '2018-12-11 03:34:39', NULL),
(111, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:39', '2018-12-11 03:34:39', NULL),
(112, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:39', '2018-12-11 03:34:39', NULL),
(113, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:39', '2018-12-11 03:34:39', NULL),
(114, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:39', '2018-12-11 03:34:39', NULL),
(115, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:40', '2018-12-11 03:34:40', NULL),
(116, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:40', '2018-12-11 03:34:40', NULL),
(117, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:40', '2018-12-11 03:34:40', NULL),
(118, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:40', '2018-12-11 03:34:40', NULL),
(119, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:40', '2018-12-11 03:34:40', NULL),
(120, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:40', '2018-12-11 03:34:40', NULL),
(121, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:40', '2018-12-11 03:34:40', NULL),
(122, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:41', '2018-12-11 03:34:41', NULL),
(123, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:41', '2018-12-11 03:34:41', NULL),
(124, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:41', '2018-12-11 03:34:41', NULL),
(125, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:41', '2018-12-11 03:34:41', NULL),
(126, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:41', '2018-12-11 03:34:41', NULL),
(127, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:41', '2018-12-11 03:34:41', NULL),
(128, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:41', '2018-12-11 03:34:41', NULL),
(129, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:42', '2018-12-11 03:34:42', NULL),
(130, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:42', '2018-12-11 03:34:42', NULL),
(131, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:42', '2018-12-11 03:34:42', NULL),
(132, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:42', '2018-12-11 03:34:42', NULL),
(133, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:42', '2018-12-11 03:34:42', NULL),
(134, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:43', '2018-12-11 03:34:43', NULL),
(135, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:43', '2018-12-11 03:34:43', NULL),
(136, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:43', '2018-12-11 03:34:43', NULL),
(137, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:43', '2018-12-11 03:34:43', NULL),
(138, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:43', '2018-12-11 03:34:43', NULL),
(139, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:43', '2018-12-11 03:34:43', NULL),
(140, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:44', '2018-12-11 03:34:44', NULL),
(141, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:44', '2018-12-11 03:34:44', NULL),
(142, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:44', '2018-12-11 03:34:44', NULL),
(143, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:44', '2018-12-11 03:34:44', NULL),
(144, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:44', '2018-12-11 03:34:44', NULL),
(145, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:44', '2018-12-11 03:34:44', NULL),
(146, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:45', '2018-12-11 03:34:45', NULL),
(147, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:45', '2018-12-11 03:34:45', NULL),
(148, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:45', '2018-12-11 03:34:45', NULL),
(149, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:46', '2018-12-11 03:34:46', NULL),
(150, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:46', '2018-12-11 03:34:46', NULL),
(151, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:46', '2018-12-11 03:34:46', NULL),
(152, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:46', '2018-12-11 03:34:46', NULL),
(153, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:46', '2018-12-11 03:34:46', NULL),
(154, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:46', '2018-12-11 03:34:46', NULL),
(155, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:47', '2018-12-11 03:34:47', NULL),
(156, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:47', '2018-12-11 03:34:47', NULL),
(157, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:47', '2018-12-11 03:34:47', NULL),
(158, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:47', '2018-12-11 03:34:47', NULL),
(159, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:47', '2018-12-11 03:34:47', NULL),
(160, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:47', '2018-12-11 03:34:47', NULL),
(161, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:47', '2018-12-11 03:34:47', NULL),
(162, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:48', '2018-12-11 03:34:48', NULL),
(163, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:48', '2018-12-11 03:34:48', NULL),
(164, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:49', '2018-12-11 03:34:49', NULL),
(165, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:49', '2018-12-11 03:34:49', NULL),
(166, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:49', '2018-12-11 03:34:49', NULL),
(167, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:49', '2018-12-11 03:34:49', NULL),
(168, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:49', '2018-12-11 03:34:49', NULL),
(169, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:50', '2018-12-11 03:34:50', NULL),
(170, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:51', '2018-12-11 03:34:51', NULL),
(171, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:51', '2018-12-11 03:34:51', NULL),
(172, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:52', '2018-12-11 03:34:52', NULL),
(173, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:52', '2018-12-11 03:34:52', NULL),
(174, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:52', '2018-12-11 03:34:52', NULL),
(175, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:52', '2018-12-11 03:34:52', NULL),
(176, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:53', '2018-12-11 03:34:53', NULL),
(177, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:53', '2018-12-11 03:34:53', NULL),
(178, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:53', '2018-12-11 03:34:53', NULL),
(179, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:54', '2018-12-11 03:34:54', NULL),
(180, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:54', '2018-12-11 03:34:54', NULL),
(181, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:55', '2018-12-11 03:34:55', NULL),
(182, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:55', '2018-12-11 03:34:55', NULL),
(183, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:55', '2018-12-11 03:34:55', NULL),
(184, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:55', '2018-12-11 03:34:55', NULL),
(185, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:55', '2018-12-11 03:34:55', NULL),
(186, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:56', '2018-12-11 03:34:56', NULL),
(187, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:56', '2018-12-11 03:34:56', NULL),
(188, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:56', '2018-12-11 03:34:56', NULL),
(189, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:56', '2018-12-11 03:34:56', NULL),
(190, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:56', '2018-12-11 03:34:56', NULL),
(191, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:56', '2018-12-11 03:34:56', NULL),
(192, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:57', '2018-12-11 03:34:57', NULL),
(193, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:57', '2018-12-11 03:34:57', NULL),
(194, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:57', '2018-12-11 03:34:57', NULL),
(195, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:57', '2018-12-11 03:34:57', NULL),
(196, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:57', '2018-12-11 03:34:57', NULL),
(197, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:57', '2018-12-11 03:34:57', NULL),
(198, 1, 0, 'This is an unresolved incident', 1, 1, 0, 0, 'Unresolved incidents are left without a **Fixed** update.', '2018-12-11 03:34:19', '2018-12-11 03:34:58', '2018-12-11 03:34:58', NULL),
(199, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:58', '2018-12-11 03:34:58', NULL),
(200, 1, 0, 'Our monkeys aren\'t performing', 1, 1, 0, 0, 'We\'re investigating an issue with our monkeys not performing as they should be.', '2018-12-11 03:34:19', '2018-12-11 03:34:58', '2018-12-11 03:34:58', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `incident_components`
--

CREATE TABLE `incident_components` (
  `id` int(10) UNSIGNED NOT NULL,
  `incident_id` int(10) UNSIGNED NOT NULL,
  `component_id` int(10) UNSIGNED NOT NULL,
  `status_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `incident_templates`
--

CREATE TABLE `incident_templates` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `template` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `incident_updates`
--

CREATE TABLE `incident_updates` (
  `id` int(10) UNSIGNED NOT NULL,
  `incident_id` int(10) UNSIGNED NOT NULL,
  `status` int(11) NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `incident_updates`
--

INSERT INTO `incident_updates` (`id`, `incident_id`, `status`, `message`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:20', '2018-12-11 03:34:20'),
(2, 2, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:21', '2018-12-11 03:34:21'),
(3, 3, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:21', '2018-12-11 03:34:21'),
(4, 4, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:22', '2018-12-11 03:34:22'),
(5, 5, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:22', '2018-12-11 03:34:22'),
(6, 6, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:22', '2018-12-11 03:34:22'),
(7, 7, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:22', '2018-12-11 03:34:22'),
(8, 8, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:22', '2018-12-11 03:34:22'),
(9, 9, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:22', '2018-12-11 03:34:22'),
(10, 10, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:22', '2018-12-11 03:34:22'),
(11, 11, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:22', '2018-12-11 03:34:22'),
(12, 12, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:23', '2018-12-11 03:34:23'),
(13, 13, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:23', '2018-12-11 03:34:23'),
(14, 14, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:23', '2018-12-11 03:34:23'),
(15, 15, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:23', '2018-12-11 03:34:23'),
(16, 16, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:23', '2018-12-11 03:34:23'),
(17, 17, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:24', '2018-12-11 03:34:24'),
(18, 18, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:24', '2018-12-11 03:34:24'),
(19, 19, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:24', '2018-12-11 03:34:24'),
(20, 20, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:24', '2018-12-11 03:34:24'),
(21, 21, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:24', '2018-12-11 03:34:24'),
(22, 22, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:24', '2018-12-11 03:34:24'),
(23, 23, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:25', '2018-12-11 03:34:25'),
(24, 24, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:25', '2018-12-11 03:34:25'),
(25, 25, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:25', '2018-12-11 03:34:25'),
(26, 26, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:25', '2018-12-11 03:34:25'),
(27, 27, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:25', '2018-12-11 03:34:25'),
(28, 28, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:25', '2018-12-11 03:34:25'),
(29, 29, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:25', '2018-12-11 03:34:25'),
(30, 30, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:26', '2018-12-11 03:34:26'),
(31, 31, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:26', '2018-12-11 03:34:26'),
(32, 32, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:26', '2018-12-11 03:34:26'),
(33, 33, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:26', '2018-12-11 03:34:26'),
(34, 34, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:26', '2018-12-11 03:34:26'),
(35, 35, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:26', '2018-12-11 03:34:26'),
(36, 36, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:26', '2018-12-11 03:34:26'),
(37, 37, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:27', '2018-12-11 03:34:27'),
(38, 38, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:27', '2018-12-11 03:34:27'),
(39, 39, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:27', '2018-12-11 03:34:27'),
(40, 40, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:27', '2018-12-11 03:34:27'),
(41, 41, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:27', '2018-12-11 03:34:27'),
(42, 42, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:27', '2018-12-11 03:34:27'),
(43, 43, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:27', '2018-12-11 03:34:27'),
(44, 44, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:28', '2018-12-11 03:34:28'),
(45, 45, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:28', '2018-12-11 03:34:28'),
(46, 46, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:28', '2018-12-11 03:34:28'),
(47, 47, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:28', '2018-12-11 03:34:28'),
(48, 48, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:28', '2018-12-11 03:34:28'),
(49, 49, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:29', '2018-12-11 03:34:29'),
(50, 50, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:29', '2018-12-11 03:34:29'),
(51, 51, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:29', '2018-12-11 03:34:29'),
(52, 52, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:29', '2018-12-11 03:34:29'),
(53, 53, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:29', '2018-12-11 03:34:29'),
(54, 54, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:29', '2018-12-11 03:34:29'),
(55, 55, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:29', '2018-12-11 03:34:29'),
(56, 56, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:30', '2018-12-11 03:34:30'),
(57, 57, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:30', '2018-12-11 03:34:30'),
(58, 58, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:30', '2018-12-11 03:34:30'),
(59, 59, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:30', '2018-12-11 03:34:30'),
(60, 60, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:30', '2018-12-11 03:34:30'),
(61, 61, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:30', '2018-12-11 03:34:30'),
(62, 62, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:30', '2018-12-11 03:34:30'),
(63, 63, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:30', '2018-12-11 03:34:30'),
(64, 64, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:31', '2018-12-11 03:34:31'),
(65, 65, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:31', '2018-12-11 03:34:31'),
(66, 66, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:31', '2018-12-11 03:34:31'),
(67, 67, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:31', '2018-12-11 03:34:31'),
(68, 68, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:31', '2018-12-11 03:34:31'),
(69, 69, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:31', '2018-12-11 03:34:31'),
(70, 70, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:31', '2018-12-11 03:34:31'),
(71, 71, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:32', '2018-12-11 03:34:32'),
(72, 72, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:32', '2018-12-11 03:34:32'),
(73, 73, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:32', '2018-12-11 03:34:32'),
(74, 74, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:32', '2018-12-11 03:34:32'),
(75, 75, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:32', '2018-12-11 03:34:32'),
(76, 76, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:32', '2018-12-11 03:34:32'),
(77, 77, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:33', '2018-12-11 03:34:33'),
(78, 78, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:33', '2018-12-11 03:34:33'),
(79, 79, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:33', '2018-12-11 03:34:33'),
(80, 80, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:33', '2018-12-11 03:34:33'),
(81, 81, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:33', '2018-12-11 03:34:33'),
(82, 82, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:33', '2018-12-11 03:34:33'),
(83, 83, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:34', '2018-12-11 03:34:34'),
(84, 84, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:34', '2018-12-11 03:34:34'),
(85, 85, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:34', '2018-12-11 03:34:34'),
(86, 86, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:34', '2018-12-11 03:34:34'),
(87, 87, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:34', '2018-12-11 03:34:34'),
(88, 88, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:35', '2018-12-11 03:34:35'),
(89, 89, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:35', '2018-12-11 03:34:35'),
(90, 90, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:35', '2018-12-11 03:34:35'),
(91, 91, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:35', '2018-12-11 03:34:35'),
(92, 92, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:35', '2018-12-11 03:34:35'),
(93, 93, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:35', '2018-12-11 03:34:35'),
(94, 94, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:36', '2018-12-11 03:34:36'),
(95, 95, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:36', '2018-12-11 03:34:36'),
(96, 96, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:36', '2018-12-11 03:34:36'),
(97, 97, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:36', '2018-12-11 03:34:36'),
(98, 98, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:36', '2018-12-11 03:34:36'),
(99, 99, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:36', '2018-12-11 03:34:36'),
(100, 100, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:36', '2018-12-11 03:34:36'),
(101, 101, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:37', '2018-12-11 03:34:37'),
(102, 102, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:37', '2018-12-11 03:34:37'),
(103, 103, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:37', '2018-12-11 03:34:37'),
(104, 104, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:37', '2018-12-11 03:34:37'),
(105, 105, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:38', '2018-12-11 03:34:38'),
(106, 106, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:38', '2018-12-11 03:34:38'),
(107, 107, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:38', '2018-12-11 03:34:38'),
(108, 108, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:38', '2018-12-11 03:34:38'),
(109, 109, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:38', '2018-12-11 03:34:38'),
(110, 110, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:39', '2018-12-11 03:34:39'),
(111, 111, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:39', '2018-12-11 03:34:39'),
(112, 112, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:39', '2018-12-11 03:34:39'),
(113, 113, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:39', '2018-12-11 03:34:39'),
(114, 114, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:39', '2018-12-11 03:34:39'),
(115, 115, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:40', '2018-12-11 03:34:40'),
(116, 116, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:40', '2018-12-11 03:34:40'),
(117, 117, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:40', '2018-12-11 03:34:40'),
(118, 118, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:40', '2018-12-11 03:34:40'),
(119, 119, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:40', '2018-12-11 03:34:40'),
(120, 120, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:40', '2018-12-11 03:34:40'),
(121, 121, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:41', '2018-12-11 03:34:41'),
(122, 122, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:41', '2018-12-11 03:34:41'),
(123, 123, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:41', '2018-12-11 03:34:41'),
(124, 124, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:41', '2018-12-11 03:34:41'),
(125, 125, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:41', '2018-12-11 03:34:41'),
(126, 126, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:41', '2018-12-11 03:34:41'),
(127, 127, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:41', '2018-12-11 03:34:41'),
(128, 128, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:42', '2018-12-11 03:34:42'),
(129, 129, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:42', '2018-12-11 03:34:42'),
(130, 130, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:42', '2018-12-11 03:34:42'),
(131, 131, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:42', '2018-12-11 03:34:42'),
(132, 132, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:42', '2018-12-11 03:34:42'),
(133, 133, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:43', '2018-12-11 03:34:43'),
(134, 134, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:43', '2018-12-11 03:34:43'),
(135, 135, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:43', '2018-12-11 03:34:43'),
(136, 136, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:43', '2018-12-11 03:34:43'),
(137, 137, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:43', '2018-12-11 03:34:43'),
(138, 138, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:43', '2018-12-11 03:34:43'),
(139, 139, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:43', '2018-12-11 03:34:43'),
(140, 140, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:44', '2018-12-11 03:34:44'),
(141, 141, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:44', '2018-12-11 03:34:44'),
(142, 142, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:44', '2018-12-11 03:34:44'),
(143, 143, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:44', '2018-12-11 03:34:44'),
(144, 144, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:44', '2018-12-11 03:34:44'),
(145, 145, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:44', '2018-12-11 03:34:44'),
(146, 146, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:45', '2018-12-11 03:34:45'),
(147, 147, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:45', '2018-12-11 03:34:45'),
(148, 148, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:46', '2018-12-11 03:34:46'),
(149, 149, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:46', '2018-12-11 03:34:46'),
(150, 150, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:46', '2018-12-11 03:34:46'),
(151, 151, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:46', '2018-12-11 03:34:46'),
(152, 152, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:46', '2018-12-11 03:34:46'),
(153, 153, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:46', '2018-12-11 03:34:46'),
(154, 154, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:46', '2018-12-11 03:34:46'),
(155, 155, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:47', '2018-12-11 03:34:47'),
(156, 156, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:47', '2018-12-11 03:34:47'),
(157, 157, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:47', '2018-12-11 03:34:47'),
(158, 158, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:47', '2018-12-11 03:34:47'),
(159, 159, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:47', '2018-12-11 03:34:47'),
(160, 160, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:47', '2018-12-11 03:34:47'),
(161, 161, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:48', '2018-12-11 03:34:48'),
(162, 162, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:48', '2018-12-11 03:34:48'),
(163, 163, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:48', '2018-12-11 03:34:48'),
(164, 164, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:49', '2018-12-11 03:34:49'),
(165, 165, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:49', '2018-12-11 03:34:49'),
(166, 166, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:49', '2018-12-11 03:34:49'),
(167, 167, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:49', '2018-12-11 03:34:49'),
(168, 168, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:49', '2018-12-11 03:34:49'),
(169, 169, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:50', '2018-12-11 03:34:50'),
(170, 170, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:51', '2018-12-11 03:34:51'),
(171, 171, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:51', '2018-12-11 03:34:51'),
(172, 172, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:52', '2018-12-11 03:34:52'),
(173, 173, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:52', '2018-12-11 03:34:52'),
(174, 174, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:52', '2018-12-11 03:34:52'),
(175, 175, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:52', '2018-12-11 03:34:52'),
(176, 176, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:53', '2018-12-11 03:34:53'),
(177, 177, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:53', '2018-12-11 03:34:53'),
(178, 178, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:53', '2018-12-11 03:34:53'),
(179, 179, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:54', '2018-12-11 03:34:54'),
(180, 180, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:55', '2018-12-11 03:34:55'),
(181, 181, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:55', '2018-12-11 03:34:55'),
(182, 182, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:55', '2018-12-11 03:34:55'),
(183, 183, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:55', '2018-12-11 03:34:55'),
(184, 184, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:55', '2018-12-11 03:34:55'),
(185, 185, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:55', '2018-12-11 03:34:55'),
(186, 186, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:56', '2018-12-11 03:34:56'),
(187, 187, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:56', '2018-12-11 03:34:56'),
(188, 188, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:56', '2018-12-11 03:34:56'),
(189, 189, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:56', '2018-12-11 03:34:56'),
(190, 190, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:56', '2018-12-11 03:34:56'),
(191, 191, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:57', '2018-12-11 03:34:57'),
(192, 192, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:57', '2018-12-11 03:34:57'),
(193, 193, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:57', '2018-12-11 03:34:57'),
(194, 194, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:57', '2018-12-11 03:34:57'),
(195, 195, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:57', '2018-12-11 03:34:57'),
(196, 196, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:57', '2018-12-11 03:34:57'),
(197, 197, 4, 'The monkeys are back and rested!', 1, '2018-12-11 03:34:58', '2018-12-11 03:34:58'),
(198, 198, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:58', '2018-12-11 03:34:58'),
(199, 199, 3, 'Our monkeys need a break from performing. They\'ll be back after a good rest.', 1, '2018-12-11 03:34:58', '2018-12-11 03:34:58'),
(200, 200, 2, 'We have identified the issue with our lovely performing monkeys.', 1, '2018-12-11 03:34:58', '2018-12-11 03:34:58');

-- --------------------------------------------------------

--
-- Table structure for table `invites`
--

CREATE TABLE `invites` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `claimed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `meta`
--

CREATE TABLE `meta` (
  `id` int(10) UNSIGNED NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_id` int(10) UNSIGNED NOT NULL,
  `meta_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `metrics`
--

CREATE TABLE `metrics` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `suffix` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_value` decimal(10,3) NOT NULL,
  `calc_type` tinyint(4) NOT NULL,
  `display_chart` tinyint(1) NOT NULL DEFAULT '1',
  `places` int(10) UNSIGNED NOT NULL DEFAULT '2',
  `default_view` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `threshold` int(10) UNSIGNED NOT NULL DEFAULT '5',
  `order` tinyint(4) NOT NULL DEFAULT '0',
  `visible` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `metrics`
--

INSERT INTO `metrics` (`id`, `name`, `suffix`, `description`, `default_value`, `calc_type`, `display_chart`, `places`, `default_view`, `threshold`, `order`, `visible`, `created_at`, `updated_at`) VALUES
(1, 'Cups of coffee0', 'Cups0', 'How many cups of coffee we\'ve drank.0', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:19', '2018-12-11 03:35:19'),
(2, 'Cups of coffee1', 'Cups1', 'How many cups of coffee we\'ve drank.1', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:19', '2018-12-11 03:35:19'),
(3, 'Cups of coffee2', 'Cups2', 'How many cups of coffee we\'ve drank.2', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:20', '2018-12-11 03:35:20'),
(4, 'Cups of coffee3', 'Cups3', 'How many cups of coffee we\'ve drank.3', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:20', '2018-12-11 03:35:20'),
(5, 'Cups of coffee4', 'Cups4', 'How many cups of coffee we\'ve drank.4', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:20', '2018-12-11 03:35:20'),
(6, 'Cups of coffee5', 'Cups5', 'How many cups of coffee we\'ve drank.5', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:20', '2018-12-11 03:35:20'),
(7, 'Cups of coffee6', 'Cups6', 'How many cups of coffee we\'ve drank.6', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:20', '2018-12-11 03:35:20'),
(8, 'Cups of coffee7', 'Cups7', 'How many cups of coffee we\'ve drank.7', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:20', '2018-12-11 03:35:20'),
(9, 'Cups of coffee8', 'Cups8', 'How many cups of coffee we\'ve drank.8', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:20', '2018-12-11 03:35:20'),
(10, 'Cups of coffee9', 'Cups9', 'How many cups of coffee we\'ve drank.9', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:20', '2018-12-11 03:35:20'),
(11, 'Cups of coffee10', 'Cups10', 'How many cups of coffee we\'ve drank.10', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:20', '2018-12-11 03:35:20'),
(12, 'Cups of coffee11', 'Cups11', 'How many cups of coffee we\'ve drank.11', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:20', '2018-12-11 03:35:20'),
(13, 'Cups of coffee12', 'Cups12', 'How many cups of coffee we\'ve drank.12', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:20', '2018-12-11 03:35:20'),
(14, 'Cups of coffee13', 'Cups13', 'How many cups of coffee we\'ve drank.13', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:21', '2018-12-11 03:35:21'),
(15, 'Cups of coffee14', 'Cups14', 'How many cups of coffee we\'ve drank.14', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:21', '2018-12-11 03:35:21'),
(16, 'Cups of coffee15', 'Cups15', 'How many cups of coffee we\'ve drank.15', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:21', '2018-12-11 03:35:21'),
(17, 'Cups of coffee16', 'Cups16', 'How many cups of coffee we\'ve drank.16', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:21', '2018-12-11 03:35:21'),
(18, 'Cups of coffee17', 'Cups17', 'How many cups of coffee we\'ve drank.17', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:21', '2018-12-11 03:35:21'),
(19, 'Cups of coffee18', 'Cups18', 'How many cups of coffee we\'ve drank.18', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:21', '2018-12-11 03:35:21'),
(20, 'Cups of coffee19', 'Cups19', 'How many cups of coffee we\'ve drank.19', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:21', '2018-12-11 03:35:21'),
(21, 'Cups of coffee20', 'Cups20', 'How many cups of coffee we\'ve drank.20', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:21', '2018-12-11 03:35:21'),
(22, 'Cups of coffee21', 'Cups21', 'How many cups of coffee we\'ve drank.21', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:21', '2018-12-11 03:35:21'),
(23, 'Cups of coffee22', 'Cups22', 'How many cups of coffee we\'ve drank.22', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:22', '2018-12-11 03:35:22'),
(24, 'Cups of coffee23', 'Cups23', 'How many cups of coffee we\'ve drank.23', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:22', '2018-12-11 03:35:22'),
(25, 'Cups of coffee24', 'Cups24', 'How many cups of coffee we\'ve drank.24', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:22', '2018-12-11 03:35:22'),
(26, 'Cups of coffee25', 'Cups25', 'How many cups of coffee we\'ve drank.25', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:22', '2018-12-11 03:35:22'),
(27, 'Cups of coffee26', 'Cups26', 'How many cups of coffee we\'ve drank.26', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:22', '2018-12-11 03:35:22'),
(28, 'Cups of coffee27', 'Cups27', 'How many cups of coffee we\'ve drank.27', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:22', '2018-12-11 03:35:22'),
(29, 'Cups of coffee28', 'Cups28', 'How many cups of coffee we\'ve drank.28', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:22', '2018-12-11 03:35:22'),
(30, 'Cups of coffee29', 'Cups29', 'How many cups of coffee we\'ve drank.29', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:22', '2018-12-11 03:35:22'),
(31, 'Cups of coffee30', 'Cups30', 'How many cups of coffee we\'ve drank.30', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:22', '2018-12-11 03:35:22'),
(32, 'Cups of coffee31', 'Cups31', 'How many cups of coffee we\'ve drank.31', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:22', '2018-12-11 03:35:22'),
(33, 'Cups of coffee32', 'Cups32', 'How many cups of coffee we\'ve drank.32', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:22', '2018-12-11 03:35:22'),
(34, 'Cups of coffee33', 'Cups33', 'How many cups of coffee we\'ve drank.33', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:22', '2018-12-11 03:35:22'),
(35, 'Cups of coffee34', 'Cups34', 'How many cups of coffee we\'ve drank.34', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:22', '2018-12-11 03:35:22'),
(36, 'Cups of coffee35', 'Cups35', 'How many cups of coffee we\'ve drank.35', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:22', '2018-12-11 03:35:22'),
(37, 'Cups of coffee36', 'Cups36', 'How many cups of coffee we\'ve drank.36', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:22', '2018-12-11 03:35:22'),
(38, 'Cups of coffee37', 'Cups37', 'How many cups of coffee we\'ve drank.37', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:23', '2018-12-11 03:35:23'),
(39, 'Cups of coffee38', 'Cups38', 'How many cups of coffee we\'ve drank.38', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:23', '2018-12-11 03:35:23'),
(40, 'Cups of coffee39', 'Cups39', 'How many cups of coffee we\'ve drank.39', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:23', '2018-12-11 03:35:23'),
(41, 'Cups of coffee40', 'Cups40', 'How many cups of coffee we\'ve drank.40', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:23', '2018-12-11 03:35:23'),
(42, 'Cups of coffee41', 'Cups41', 'How many cups of coffee we\'ve drank.41', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:23', '2018-12-11 03:35:23'),
(43, 'Cups of coffee42', 'Cups42', 'How many cups of coffee we\'ve drank.42', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:23', '2018-12-11 03:35:23'),
(44, 'Cups of coffee43', 'Cups43', 'How many cups of coffee we\'ve drank.43', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:23', '2018-12-11 03:35:23'),
(45, 'Cups of coffee44', 'Cups44', 'How many cups of coffee we\'ve drank.44', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:23', '2018-12-11 03:35:23'),
(46, 'Cups of coffee45', 'Cups45', 'How many cups of coffee we\'ve drank.45', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:23', '2018-12-11 03:35:23'),
(47, 'Cups of coffee46', 'Cups46', 'How many cups of coffee we\'ve drank.46', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:23', '2018-12-11 03:35:23'),
(48, 'Cups of coffee47', 'Cups47', 'How many cups of coffee we\'ve drank.47', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:23', '2018-12-11 03:35:23'),
(49, 'Cups of coffee48', 'Cups48', 'How many cups of coffee we\'ve drank.48', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:24', '2018-12-11 03:35:24'),
(50, 'Cups of coffee49', 'Cups49', 'How many cups of coffee we\'ve drank.49', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:24', '2018-12-11 03:35:24'),
(51, 'Cups of coffee50', 'Cups50', 'How many cups of coffee we\'ve drank.50', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:24', '2018-12-11 03:35:24'),
(52, 'Cups of coffee51', 'Cups51', 'How many cups of coffee we\'ve drank.51', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:24', '2018-12-11 03:35:24'),
(53, 'Cups of coffee52', 'Cups52', 'How many cups of coffee we\'ve drank.52', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:24', '2018-12-11 03:35:24'),
(54, 'Cups of coffee53', 'Cups53', 'How many cups of coffee we\'ve drank.53', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:24', '2018-12-11 03:35:24'),
(55, 'Cups of coffee54', 'Cups54', 'How many cups of coffee we\'ve drank.54', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:24', '2018-12-11 03:35:24'),
(56, 'Cups of coffee55', 'Cups55', 'How many cups of coffee we\'ve drank.55', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:24', '2018-12-11 03:35:24'),
(57, 'Cups of coffee56', 'Cups56', 'How many cups of coffee we\'ve drank.56', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:24', '2018-12-11 03:35:24'),
(58, 'Cups of coffee57', 'Cups57', 'How many cups of coffee we\'ve drank.57', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:24', '2018-12-11 03:35:24'),
(59, 'Cups of coffee58', 'Cups58', 'How many cups of coffee we\'ve drank.58', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:24', '2018-12-11 03:35:24'),
(60, 'Cups of coffee59', 'Cups59', 'How many cups of coffee we\'ve drank.59', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:24', '2018-12-11 03:35:24'),
(61, 'Cups of coffee60', 'Cups60', 'How many cups of coffee we\'ve drank.60', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:24', '2018-12-11 03:35:24'),
(62, 'Cups of coffee61', 'Cups61', 'How many cups of coffee we\'ve drank.61', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:24', '2018-12-11 03:35:24'),
(63, 'Cups of coffee62', 'Cups62', 'How many cups of coffee we\'ve drank.62', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:24', '2018-12-11 03:35:24'),
(64, 'Cups of coffee63', 'Cups63', 'How many cups of coffee we\'ve drank.63', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:25', '2018-12-11 03:35:25'),
(65, 'Cups of coffee64', 'Cups64', 'How many cups of coffee we\'ve drank.64', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:25', '2018-12-11 03:35:25'),
(66, 'Cups of coffee65', 'Cups65', 'How many cups of coffee we\'ve drank.65', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:25', '2018-12-11 03:35:25'),
(67, 'Cups of coffee66', 'Cups66', 'How many cups of coffee we\'ve drank.66', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:25', '2018-12-11 03:35:25'),
(68, 'Cups of coffee67', 'Cups67', 'How many cups of coffee we\'ve drank.67', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:25', '2018-12-11 03:35:25'),
(69, 'Cups of coffee68', 'Cups68', 'How many cups of coffee we\'ve drank.68', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:25', '2018-12-11 03:35:25'),
(70, 'Cups of coffee69', 'Cups69', 'How many cups of coffee we\'ve drank.69', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:25', '2018-12-11 03:35:25'),
(71, 'Cups of coffee70', 'Cups70', 'How many cups of coffee we\'ve drank.70', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:25', '2018-12-11 03:35:25'),
(72, 'Cups of coffee71', 'Cups71', 'How many cups of coffee we\'ve drank.71', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:25', '2018-12-11 03:35:25'),
(73, 'Cups of coffee72', 'Cups72', 'How many cups of coffee we\'ve drank.72', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:25', '2018-12-11 03:35:25'),
(74, 'Cups of coffee73', 'Cups73', 'How many cups of coffee we\'ve drank.73', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:26', '2018-12-11 03:35:26'),
(75, 'Cups of coffee74', 'Cups74', 'How many cups of coffee we\'ve drank.74', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:26', '2018-12-11 03:35:26'),
(76, 'Cups of coffee75', 'Cups75', 'How many cups of coffee we\'ve drank.75', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:26', '2018-12-11 03:35:26'),
(77, 'Cups of coffee76', 'Cups76', 'How many cups of coffee we\'ve drank.76', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:26', '2018-12-11 03:35:26'),
(78, 'Cups of coffee77', 'Cups77', 'How many cups of coffee we\'ve drank.77', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:26', '2018-12-11 03:35:26'),
(79, 'Cups of coffee78', 'Cups78', 'How many cups of coffee we\'ve drank.78', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:26', '2018-12-11 03:35:26'),
(80, 'Cups of coffee79', 'Cups79', 'How many cups of coffee we\'ve drank.79', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:26', '2018-12-11 03:35:26'),
(81, 'Cups of coffee80', 'Cups80', 'How many cups of coffee we\'ve drank.80', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:26', '2018-12-11 03:35:26'),
(82, 'Cups of coffee81', 'Cups81', 'How many cups of coffee we\'ve drank.81', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:26', '2018-12-11 03:35:26'),
(83, 'Cups of coffee82', 'Cups82', 'How many cups of coffee we\'ve drank.82', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:26', '2018-12-11 03:35:26'),
(84, 'Cups of coffee83', 'Cups83', 'How many cups of coffee we\'ve drank.83', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:26', '2018-12-11 03:35:26'),
(85, 'Cups of coffee84', 'Cups84', 'How many cups of coffee we\'ve drank.84', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:26', '2018-12-11 03:35:26'),
(86, 'Cups of coffee85', 'Cups85', 'How many cups of coffee we\'ve drank.85', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:27', '2018-12-11 03:35:27'),
(87, 'Cups of coffee86', 'Cups86', 'How many cups of coffee we\'ve drank.86', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:27', '2018-12-11 03:35:27'),
(88, 'Cups of coffee87', 'Cups87', 'How many cups of coffee we\'ve drank.87', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:27', '2018-12-11 03:35:27'),
(89, 'Cups of coffee88', 'Cups88', 'How many cups of coffee we\'ve drank.88', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:27', '2018-12-11 03:35:27'),
(90, 'Cups of coffee89', 'Cups89', 'How many cups of coffee we\'ve drank.89', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:27', '2018-12-11 03:35:27'),
(91, 'Cups of coffee90', 'Cups90', 'How many cups of coffee we\'ve drank.90', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:27', '2018-12-11 03:35:27'),
(92, 'Cups of coffee91', 'Cups91', 'How many cups of coffee we\'ve drank.91', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:27', '2018-12-11 03:35:27'),
(93, 'Cups of coffee92', 'Cups92', 'How many cups of coffee we\'ve drank.92', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:27', '2018-12-11 03:35:27'),
(94, 'Cups of coffee93', 'Cups93', 'How many cups of coffee we\'ve drank.93', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:27', '2018-12-11 03:35:27'),
(95, 'Cups of coffee94', 'Cups94', 'How many cups of coffee we\'ve drank.94', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:27', '2018-12-11 03:35:27'),
(96, 'Cups of coffee95', 'Cups95', 'How many cups of coffee we\'ve drank.95', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:27', '2018-12-11 03:35:27'),
(97, 'Cups of coffee96', 'Cups96', 'How many cups of coffee we\'ve drank.96', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:27', '2018-12-11 03:35:27'),
(98, 'Cups of coffee97', 'Cups97', 'How many cups of coffee we\'ve drank.97', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:27', '2018-12-11 03:35:27'),
(99, 'Cups of coffee98', 'Cups98', 'How many cups of coffee we\'ve drank.98', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:27', '2018-12-11 03:35:27'),
(100, 'Cups of coffee99', 'Cups99', 'How many cups of coffee we\'ve drank.99', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:27', '2018-12-11 03:35:27'),
(101, 'Cups of coffee100', 'Cups100', 'How many cups of coffee we\'ve drank.100', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:28', '2018-12-11 03:35:28'),
(102, 'Cups of coffee101', 'Cups101', 'How many cups of coffee we\'ve drank.101', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:28', '2018-12-11 03:35:28'),
(103, 'Cups of coffee102', 'Cups102', 'How many cups of coffee we\'ve drank.102', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:28', '2018-12-11 03:35:28'),
(104, 'Cups of coffee103', 'Cups103', 'How many cups of coffee we\'ve drank.103', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:28', '2018-12-11 03:35:28'),
(105, 'Cups of coffee104', 'Cups104', 'How many cups of coffee we\'ve drank.104', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:28', '2018-12-11 03:35:28'),
(106, 'Cups of coffee105', 'Cups105', 'How many cups of coffee we\'ve drank.105', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:28', '2018-12-11 03:35:28'),
(107, 'Cups of coffee106', 'Cups106', 'How many cups of coffee we\'ve drank.106', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:28', '2018-12-11 03:35:28'),
(108, 'Cups of coffee107', 'Cups107', 'How many cups of coffee we\'ve drank.107', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:28', '2018-12-11 03:35:28'),
(109, 'Cups of coffee108', 'Cups108', 'How many cups of coffee we\'ve drank.108', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:28', '2018-12-11 03:35:28'),
(110, 'Cups of coffee109', 'Cups109', 'How many cups of coffee we\'ve drank.109', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:28', '2018-12-11 03:35:28'),
(111, 'Cups of coffee110', 'Cups110', 'How many cups of coffee we\'ve drank.110', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:28', '2018-12-11 03:35:28'),
(112, 'Cups of coffee111', 'Cups111', 'How many cups of coffee we\'ve drank.111', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:28', '2018-12-11 03:35:28'),
(113, 'Cups of coffee112', 'Cups112', 'How many cups of coffee we\'ve drank.112', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:28', '2018-12-11 03:35:28'),
(114, 'Cups of coffee113', 'Cups113', 'How many cups of coffee we\'ve drank.113', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:28', '2018-12-11 03:35:28'),
(115, 'Cups of coffee114', 'Cups114', 'How many cups of coffee we\'ve drank.114', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:29', '2018-12-11 03:35:29'),
(116, 'Cups of coffee115', 'Cups115', 'How many cups of coffee we\'ve drank.115', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:29', '2018-12-11 03:35:29'),
(117, 'Cups of coffee116', 'Cups116', 'How many cups of coffee we\'ve drank.116', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:29', '2018-12-11 03:35:29'),
(118, 'Cups of coffee117', 'Cups117', 'How many cups of coffee we\'ve drank.117', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:29', '2018-12-11 03:35:29'),
(119, 'Cups of coffee118', 'Cups118', 'How many cups of coffee we\'ve drank.118', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:29', '2018-12-11 03:35:29'),
(120, 'Cups of coffee119', 'Cups119', 'How many cups of coffee we\'ve drank.119', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:29', '2018-12-11 03:35:29'),
(121, 'Cups of coffee120', 'Cups120', 'How many cups of coffee we\'ve drank.120', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:29', '2018-12-11 03:35:29'),
(122, 'Cups of coffee121', 'Cups121', 'How many cups of coffee we\'ve drank.121', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:29', '2018-12-11 03:35:29'),
(123, 'Cups of coffee122', 'Cups122', 'How many cups of coffee we\'ve drank.122', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:29', '2018-12-11 03:35:29'),
(124, 'Cups of coffee123', 'Cups123', 'How many cups of coffee we\'ve drank.123', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:29', '2018-12-11 03:35:29'),
(125, 'Cups of coffee124', 'Cups124', 'How many cups of coffee we\'ve drank.124', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:29', '2018-12-11 03:35:29'),
(126, 'Cups of coffee125', 'Cups125', 'How many cups of coffee we\'ve drank.125', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:29', '2018-12-11 03:35:29'),
(127, 'Cups of coffee126', 'Cups126', 'How many cups of coffee we\'ve drank.126', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:29', '2018-12-11 03:35:29'),
(128, 'Cups of coffee127', 'Cups127', 'How many cups of coffee we\'ve drank.127', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:29', '2018-12-11 03:35:29'),
(129, 'Cups of coffee128', 'Cups128', 'How many cups of coffee we\'ve drank.128', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:30', '2018-12-11 03:35:30'),
(130, 'Cups of coffee129', 'Cups129', 'How many cups of coffee we\'ve drank.129', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:30', '2018-12-11 03:35:30'),
(131, 'Cups of coffee130', 'Cups130', 'How many cups of coffee we\'ve drank.130', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:30', '2018-12-11 03:35:30'),
(132, 'Cups of coffee131', 'Cups131', 'How many cups of coffee we\'ve drank.131', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:30', '2018-12-11 03:35:30'),
(133, 'Cups of coffee132', 'Cups132', 'How many cups of coffee we\'ve drank.132', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:30', '2018-12-11 03:35:30'),
(134, 'Cups of coffee133', 'Cups133', 'How many cups of coffee we\'ve drank.133', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:30', '2018-12-11 03:35:30'),
(135, 'Cups of coffee134', 'Cups134', 'How many cups of coffee we\'ve drank.134', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:31', '2018-12-11 03:35:31'),
(136, 'Cups of coffee135', 'Cups135', 'How many cups of coffee we\'ve drank.135', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:31', '2018-12-11 03:35:31'),
(137, 'Cups of coffee136', 'Cups136', 'How many cups of coffee we\'ve drank.136', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:31', '2018-12-11 03:35:31'),
(138, 'Cups of coffee137', 'Cups137', 'How many cups of coffee we\'ve drank.137', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:31', '2018-12-11 03:35:31'),
(139, 'Cups of coffee138', 'Cups138', 'How many cups of coffee we\'ve drank.138', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:31', '2018-12-11 03:35:31'),
(140, 'Cups of coffee139', 'Cups139', 'How many cups of coffee we\'ve drank.139', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:31', '2018-12-11 03:35:31'),
(141, 'Cups of coffee140', 'Cups140', 'How many cups of coffee we\'ve drank.140', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:31', '2018-12-11 03:35:31'),
(142, 'Cups of coffee141', 'Cups141', 'How many cups of coffee we\'ve drank.141', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:31', '2018-12-11 03:35:31'),
(143, 'Cups of coffee142', 'Cups142', 'How many cups of coffee we\'ve drank.142', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:31', '2018-12-11 03:35:31'),
(144, 'Cups of coffee143', 'Cups143', 'How many cups of coffee we\'ve drank.143', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:31', '2018-12-11 03:35:31'),
(145, 'Cups of coffee144', 'Cups144', 'How many cups of coffee we\'ve drank.144', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:31', '2018-12-11 03:35:31'),
(146, 'Cups of coffee145', 'Cups145', 'How many cups of coffee we\'ve drank.145', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:31', '2018-12-11 03:35:31'),
(147, 'Cups of coffee146', 'Cups146', 'How many cups of coffee we\'ve drank.146', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:31', '2018-12-11 03:35:31'),
(148, 'Cups of coffee147', 'Cups147', 'How many cups of coffee we\'ve drank.147', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:31', '2018-12-11 03:35:31'),
(149, 'Cups of coffee148', 'Cups148', 'How many cups of coffee we\'ve drank.148', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:31', '2018-12-11 03:35:31'),
(150, 'Cups of coffee149', 'Cups149', 'How many cups of coffee we\'ve drank.149', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:31', '2018-12-11 03:35:31'),
(151, 'Cups of coffee150', 'Cups150', 'How many cups of coffee we\'ve drank.150', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:32', '2018-12-11 03:35:32'),
(152, 'Cups of coffee151', 'Cups151', 'How many cups of coffee we\'ve drank.151', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:32', '2018-12-11 03:35:32'),
(153, 'Cups of coffee152', 'Cups152', 'How many cups of coffee we\'ve drank.152', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:32', '2018-12-11 03:35:32'),
(154, 'Cups of coffee153', 'Cups153', 'How many cups of coffee we\'ve drank.153', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:32', '2018-12-11 03:35:32'),
(155, 'Cups of coffee154', 'Cups154', 'How many cups of coffee we\'ve drank.154', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:32', '2018-12-11 03:35:32'),
(156, 'Cups of coffee155', 'Cups155', 'How many cups of coffee we\'ve drank.155', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:32', '2018-12-11 03:35:32'),
(157, 'Cups of coffee156', 'Cups156', 'How many cups of coffee we\'ve drank.156', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:32', '2018-12-11 03:35:32'),
(158, 'Cups of coffee157', 'Cups157', 'How many cups of coffee we\'ve drank.157', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:32', '2018-12-11 03:35:32'),
(159, 'Cups of coffee158', 'Cups158', 'How many cups of coffee we\'ve drank.158', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:32', '2018-12-11 03:35:32'),
(160, 'Cups of coffee159', 'Cups159', 'How many cups of coffee we\'ve drank.159', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:32', '2018-12-11 03:35:32'),
(161, 'Cups of coffee160', 'Cups160', 'How many cups of coffee we\'ve drank.160', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:32', '2018-12-11 03:35:32'),
(162, 'Cups of coffee161', 'Cups161', 'How many cups of coffee we\'ve drank.161', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:32', '2018-12-11 03:35:32'),
(163, 'Cups of coffee162', 'Cups162', 'How many cups of coffee we\'ve drank.162', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:32', '2018-12-11 03:35:32'),
(164, 'Cups of coffee163', 'Cups163', 'How many cups of coffee we\'ve drank.163', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:33', '2018-12-11 03:35:33'),
(165, 'Cups of coffee164', 'Cups164', 'How many cups of coffee we\'ve drank.164', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:33', '2018-12-11 03:35:33'),
(166, 'Cups of coffee165', 'Cups165', 'How many cups of coffee we\'ve drank.165', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:33', '2018-12-11 03:35:33'),
(167, 'Cups of coffee166', 'Cups166', 'How many cups of coffee we\'ve drank.166', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:33', '2018-12-11 03:35:33'),
(168, 'Cups of coffee167', 'Cups167', 'How many cups of coffee we\'ve drank.167', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:33', '2018-12-11 03:35:33'),
(169, 'Cups of coffee168', 'Cups168', 'How many cups of coffee we\'ve drank.168', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:33', '2018-12-11 03:35:33'),
(170, 'Cups of coffee169', 'Cups169', 'How many cups of coffee we\'ve drank.169', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:33', '2018-12-11 03:35:33'),
(171, 'Cups of coffee170', 'Cups170', 'How many cups of coffee we\'ve drank.170', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:33', '2018-12-11 03:35:33'),
(172, 'Cups of coffee171', 'Cups171', 'How many cups of coffee we\'ve drank.171', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:33', '2018-12-11 03:35:33'),
(173, 'Cups of coffee172', 'Cups172', 'How many cups of coffee we\'ve drank.172', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:33', '2018-12-11 03:35:33'),
(174, 'Cups of coffee173', 'Cups173', 'How many cups of coffee we\'ve drank.173', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:33', '2018-12-11 03:35:33'),
(175, 'Cups of coffee174', 'Cups174', 'How many cups of coffee we\'ve drank.174', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:34', '2018-12-11 03:35:34'),
(176, 'Cups of coffee175', 'Cups175', 'How many cups of coffee we\'ve drank.175', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:34', '2018-12-11 03:35:34'),
(177, 'Cups of coffee176', 'Cups176', 'How many cups of coffee we\'ve drank.176', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:34', '2018-12-11 03:35:34'),
(178, 'Cups of coffee177', 'Cups177', 'How many cups of coffee we\'ve drank.177', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:34', '2018-12-11 03:35:34'),
(179, 'Cups of coffee178', 'Cups178', 'How many cups of coffee we\'ve drank.178', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:34', '2018-12-11 03:35:34'),
(180, 'Cups of coffee179', 'Cups179', 'How many cups of coffee we\'ve drank.179', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:34', '2018-12-11 03:35:34'),
(181, 'Cups of coffee180', 'Cups180', 'How many cups of coffee we\'ve drank.180', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:34', '2018-12-11 03:35:34'),
(182, 'Cups of coffee181', 'Cups181', 'How many cups of coffee we\'ve drank.181', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:34', '2018-12-11 03:35:34'),
(183, 'Cups of coffee182', 'Cups182', 'How many cups of coffee we\'ve drank.182', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:34', '2018-12-11 03:35:34'),
(184, 'Cups of coffee183', 'Cups183', 'How many cups of coffee we\'ve drank.183', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:34', '2018-12-11 03:35:34'),
(185, 'Cups of coffee184', 'Cups184', 'How many cups of coffee we\'ve drank.184', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:34', '2018-12-11 03:35:34'),
(186, 'Cups of coffee185', 'Cups185', 'How many cups of coffee we\'ve drank.185', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:34', '2018-12-11 03:35:34'),
(187, 'Cups of coffee186', 'Cups186', 'How many cups of coffee we\'ve drank.186', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:34', '2018-12-11 03:35:34'),
(188, 'Cups of coffee187', 'Cups187', 'How many cups of coffee we\'ve drank.187', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:34', '2018-12-11 03:35:34'),
(189, 'Cups of coffee188', 'Cups188', 'How many cups of coffee we\'ve drank.188', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:34', '2018-12-11 03:35:34'),
(190, 'Cups of coffee189', 'Cups189', 'How many cups of coffee we\'ve drank.189', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:35', '2018-12-11 03:35:35'),
(191, 'Cups of coffee190', 'Cups190', 'How many cups of coffee we\'ve drank.190', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:35', '2018-12-11 03:35:35'),
(192, 'Cups of coffee191', 'Cups191', 'How many cups of coffee we\'ve drank.191', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:35', '2018-12-11 03:35:35'),
(193, 'Cups of coffee192', 'Cups192', 'How many cups of coffee we\'ve drank.192', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:35', '2018-12-11 03:35:35'),
(194, 'Cups of coffee193', 'Cups193', 'How many cups of coffee we\'ve drank.193', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:35', '2018-12-11 03:35:35'),
(195, 'Cups of coffee194', 'Cups194', 'How many cups of coffee we\'ve drank.194', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:35', '2018-12-11 03:35:35'),
(196, 'Cups of coffee195', 'Cups195', 'How many cups of coffee we\'ve drank.195', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:35', '2018-12-11 03:35:35'),
(197, 'Cups of coffee196', 'Cups196', 'How many cups of coffee we\'ve drank.196', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:35', '2018-12-11 03:35:35'),
(198, 'Cups of coffee197', 'Cups197', 'How many cups of coffee we\'ve drank.197', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:35', '2018-12-11 03:35:35'),
(199, 'Cups of coffee198', 'Cups198', 'How many cups of coffee we\'ve drank.198', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:35', '2018-12-11 03:35:35'),
(200, 'Cups of coffee199', 'Cups199', 'How many cups of coffee we\'ve drank.199', '0.000', 1, 1, 2, 1, 5, 0, 1, '2018-12-11 03:35:35', '2018-12-11 03:35:35');

-- --------------------------------------------------------

--
-- Table structure for table `metric_points`
--

CREATE TABLE `metric_points` (
  `id` int(10) UNSIGNED NOT NULL,
  `metric_id` int(11) NOT NULL,
  `value` decimal(15,3) NOT NULL,
  `counter` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `metric_points`
--

INSERT INTO `metric_points` (`id`, `metric_id`, `value`, `counter`, `created_at`, `updated_at`) VALUES
(1, 1, '9.000', 1, '2018-12-11 03:35:00', '2018-12-11 03:35:00'),
(2, 1, '2.000', 1, '2018-12-11 02:35:00', '2018-12-11 03:35:00'),
(3, 1, '4.000', 1, '2018-12-11 01:35:00', '2018-12-11 03:35:00'),
(4, 1, '3.000', 1, '2018-12-11 00:35:00', '2018-12-11 03:35:00'),
(5, 1, '6.000', 1, '2018-12-10 23:35:00', '2018-12-11 03:35:00'),
(6, 1, '5.000', 1, '2018-12-10 22:35:00', '2018-12-11 03:35:00'),
(7, 1, '5.000', 1, '2018-12-10 21:35:00', '2018-12-11 03:35:01'),
(8, 1, '7.000', 1, '2018-12-10 20:35:00', '2018-12-11 03:35:01'),
(9, 1, '10.000', 1, '2018-12-10 19:35:00', '2018-12-11 03:35:01'),
(10, 1, '6.000', 1, '2018-12-10 18:35:00', '2018-12-11 03:35:01'),
(11, 1, '9.000', 1, '2018-12-10 17:35:00', '2018-12-11 03:35:01'),
(12, 1, '5.000', 1, '2018-12-10 16:35:00', '2018-12-11 03:35:01'),
(13, 1, '10.000', 1, '2018-12-10 15:35:00', '2018-12-11 03:35:01'),
(14, 1, '9.000', 1, '2018-12-10 14:35:00', '2018-12-11 03:35:01'),
(15, 1, '7.000', 1, '2018-12-10 13:35:00', '2018-12-11 03:35:01'),
(16, 1, '8.000', 1, '2018-12-10 12:35:00', '2018-12-11 03:35:02'),
(17, 1, '1.000', 1, '2018-12-10 11:35:00', '2018-12-11 03:35:02'),
(18, 1, '5.000', 1, '2018-12-10 10:35:00', '2018-12-11 03:35:02'),
(19, 1, '1.000', 1, '2018-12-10 09:35:00', '2018-12-11 03:35:02'),
(20, 1, '3.000', 1, '2018-12-10 08:35:00', '2018-12-11 03:35:02'),
(21, 1, '2.000', 1, '2018-12-10 07:35:00', '2018-12-11 03:35:02'),
(22, 1, '5.000', 1, '2018-12-10 06:35:00', '2018-12-11 03:35:02'),
(23, 1, '3.000', 1, '2018-12-10 05:35:00', '2018-12-11 03:35:02'),
(24, 1, '4.000', 1, '2018-12-10 04:35:00', '2018-12-11 03:35:02'),
(25, 1, '9.000', 1, '2018-12-10 03:35:00', '2018-12-11 03:35:02'),
(26, 1, '6.000', 1, '2018-12-10 02:35:00', '2018-12-11 03:35:03'),
(27, 1, '1.000', 1, '2018-12-10 01:35:00', '2018-12-11 03:35:03'),
(28, 1, '3.000', 1, '2018-12-10 00:35:00', '2018-12-11 03:35:03'),
(29, 1, '1.000', 1, '2018-12-09 23:35:00', '2018-12-11 03:35:03'),
(30, 1, '9.000', 1, '2018-12-09 22:35:00', '2018-12-11 03:35:03'),
(31, 1, '4.000', 1, '2018-12-09 21:35:00', '2018-12-11 03:35:03'),
(32, 1, '6.000', 1, '2018-12-09 20:35:00', '2018-12-11 03:35:04'),
(33, 1, '2.000', 1, '2018-12-09 19:35:00', '2018-12-11 03:35:04'),
(34, 1, '7.000', 1, '2018-12-09 18:35:00', '2018-12-11 03:35:04'),
(35, 1, '6.000', 1, '2018-12-09 17:35:00', '2018-12-11 03:35:04'),
(36, 1, '2.000', 1, '2018-12-09 16:35:00', '2018-12-11 03:35:04'),
(37, 1, '7.000', 1, '2018-12-09 15:35:00', '2018-12-11 03:35:04'),
(38, 1, '9.000', 1, '2018-12-09 14:35:00', '2018-12-11 03:35:04'),
(39, 1, '6.000', 1, '2018-12-09 13:35:00', '2018-12-11 03:35:04'),
(40, 1, '8.000', 1, '2018-12-09 12:35:00', '2018-12-11 03:35:04'),
(41, 1, '9.000', 1, '2018-12-09 11:35:00', '2018-12-11 03:35:04'),
(42, 1, '6.000', 1, '2018-12-09 10:35:00', '2018-12-11 03:35:04'),
(43, 1, '2.000', 1, '2018-12-09 09:35:00', '2018-12-11 03:35:04'),
(44, 1, '4.000', 1, '2018-12-09 08:35:00', '2018-12-11 03:35:04'),
(45, 1, '9.000', 1, '2018-12-09 07:35:00', '2018-12-11 03:35:04'),
(46, 1, '1.000', 1, '2018-12-09 06:35:00', '2018-12-11 03:35:04'),
(47, 1, '9.000', 1, '2018-12-09 05:35:00', '2018-12-11 03:35:05'),
(48, 1, '3.000', 1, '2018-12-09 04:35:00', '2018-12-11 03:35:05'),
(49, 1, '4.000', 1, '2018-12-09 03:35:00', '2018-12-11 03:35:05'),
(50, 1, '9.000', 1, '2018-12-09 02:35:00', '2018-12-11 03:35:05'),
(51, 1, '2.000', 1, '2018-12-09 01:35:00', '2018-12-11 03:35:05'),
(52, 1, '10.000', 1, '2018-12-09 00:35:00', '2018-12-11 03:35:05'),
(53, 1, '6.000', 1, '2018-12-08 23:35:00', '2018-12-11 03:35:05'),
(54, 1, '1.000', 1, '2018-12-08 22:35:00', '2018-12-11 03:35:05'),
(55, 1, '6.000', 1, '2018-12-08 21:35:00', '2018-12-11 03:35:05'),
(56, 1, '7.000', 1, '2018-12-08 20:35:00', '2018-12-11 03:35:05'),
(57, 1, '5.000', 1, '2018-12-08 19:35:00', '2018-12-11 03:35:05'),
(58, 1, '7.000', 1, '2018-12-08 18:35:00', '2018-12-11 03:35:06'),
(59, 1, '8.000', 1, '2018-12-08 17:35:00', '2018-12-11 03:35:06'),
(60, 1, '1.000', 1, '2018-12-08 16:35:00', '2018-12-11 03:35:06'),
(61, 1, '7.000', 1, '2018-12-08 15:35:00', '2018-12-11 03:35:06'),
(62, 1, '3.000', 1, '2018-12-08 14:35:00', '2018-12-11 03:35:06'),
(63, 1, '7.000', 1, '2018-12-08 13:35:00', '2018-12-11 03:35:06'),
(64, 1, '9.000', 1, '2018-12-08 12:35:00', '2018-12-11 03:35:06'),
(65, 1, '3.000', 1, '2018-12-08 11:35:00', '2018-12-11 03:35:06'),
(66, 1, '8.000', 1, '2018-12-08 10:35:00', '2018-12-11 03:35:07'),
(67, 1, '7.000', 1, '2018-12-08 09:35:00', '2018-12-11 03:35:07'),
(68, 1, '7.000', 1, '2018-12-08 08:35:00', '2018-12-11 03:35:07'),
(69, 1, '6.000', 1, '2018-12-08 07:35:00', '2018-12-11 03:35:07'),
(70, 1, '7.000', 1, '2018-12-08 06:35:00', '2018-12-11 03:35:07'),
(71, 1, '5.000', 1, '2018-12-08 05:35:00', '2018-12-11 03:35:07'),
(72, 1, '2.000', 1, '2018-12-08 04:35:00', '2018-12-11 03:35:07'),
(73, 1, '4.000', 1, '2018-12-08 03:35:00', '2018-12-11 03:35:07'),
(74, 1, '1.000', 1, '2018-12-08 02:35:00', '2018-12-11 03:35:07'),
(75, 1, '6.000', 1, '2018-12-08 01:35:00', '2018-12-11 03:35:07'),
(76, 1, '3.000', 1, '2018-12-08 00:35:00', '2018-12-11 03:35:07'),
(77, 1, '1.000', 1, '2018-12-07 23:35:00', '2018-12-11 03:35:07'),
(78, 1, '1.000', 1, '2018-12-07 22:35:00', '2018-12-11 03:35:07'),
(79, 1, '5.000', 1, '2018-12-07 21:35:00', '2018-12-11 03:35:08'),
(80, 1, '8.000', 1, '2018-12-07 20:35:00', '2018-12-11 03:35:08'),
(81, 1, '7.000', 1, '2018-12-07 19:35:00', '2018-12-11 03:35:08'),
(82, 1, '2.000', 1, '2018-12-07 18:35:00', '2018-12-11 03:35:08'),
(83, 1, '4.000', 1, '2018-12-07 17:35:00', '2018-12-11 03:35:08'),
(84, 1, '8.000', 1, '2018-12-07 16:35:00', '2018-12-11 03:35:08'),
(85, 1, '9.000', 1, '2018-12-07 15:35:00', '2018-12-11 03:35:08'),
(86, 1, '2.000', 1, '2018-12-07 14:35:00', '2018-12-11 03:35:08'),
(87, 1, '8.000', 1, '2018-12-07 13:35:00', '2018-12-11 03:35:08'),
(88, 1, '9.000', 1, '2018-12-07 12:35:00', '2018-12-11 03:35:08'),
(89, 1, '2.000', 1, '2018-12-07 11:35:00', '2018-12-11 03:35:08'),
(90, 1, '8.000', 1, '2018-12-07 10:35:00', '2018-12-11 03:35:08'),
(91, 1, '8.000', 1, '2018-12-07 09:35:00', '2018-12-11 03:35:08'),
(92, 1, '4.000', 1, '2018-12-07 08:35:00', '2018-12-11 03:35:08'),
(93, 1, '5.000', 1, '2018-12-07 07:35:00', '2018-12-11 03:35:08'),
(94, 1, '6.000', 1, '2018-12-07 06:35:00', '2018-12-11 03:35:08'),
(95, 1, '6.000', 1, '2018-12-07 05:35:00', '2018-12-11 03:35:08'),
(96, 1, '10.000', 1, '2018-12-07 04:35:00', '2018-12-11 03:35:08'),
(97, 1, '1.000', 1, '2018-12-07 03:35:00', '2018-12-11 03:35:08'),
(98, 1, '7.000', 1, '2018-12-07 02:35:00', '2018-12-11 03:35:09'),
(99, 1, '8.000', 1, '2018-12-07 01:35:00', '2018-12-11 03:35:09'),
(100, 1, '7.000', 1, '2018-12-07 00:35:00', '2018-12-11 03:35:09'),
(101, 1, '1.000', 1, '2018-12-06 23:35:00', '2018-12-11 03:35:09'),
(102, 1, '6.000', 1, '2018-12-06 22:35:00', '2018-12-11 03:35:09'),
(103, 1, '1.000', 1, '2018-12-06 21:35:00', '2018-12-11 03:35:09'),
(104, 1, '4.000', 1, '2018-12-06 20:35:00', '2018-12-11 03:35:09'),
(105, 1, '9.000', 1, '2018-12-06 19:35:00', '2018-12-11 03:35:10'),
(106, 1, '10.000', 1, '2018-12-06 18:35:00', '2018-12-11 03:35:10'),
(107, 1, '2.000', 1, '2018-12-06 17:35:00', '2018-12-11 03:35:10'),
(108, 1, '3.000', 1, '2018-12-06 16:35:00', '2018-12-11 03:35:10'),
(109, 1, '6.000', 1, '2018-12-06 15:35:00', '2018-12-11 03:35:10'),
(110, 1, '9.000', 1, '2018-12-06 14:35:00', '2018-12-11 03:35:10'),
(111, 1, '6.000', 1, '2018-12-06 13:35:00', '2018-12-11 03:35:10'),
(112, 1, '4.000', 1, '2018-12-06 12:35:00', '2018-12-11 03:35:10'),
(113, 1, '2.000', 1, '2018-12-06 11:35:00', '2018-12-11 03:35:10'),
(114, 1, '7.000', 1, '2018-12-06 10:35:00', '2018-12-11 03:35:10'),
(115, 1, '9.000', 1, '2018-12-06 09:35:00', '2018-12-11 03:35:10'),
(116, 1, '4.000', 1, '2018-12-06 08:35:00', '2018-12-11 03:35:10'),
(117, 1, '8.000', 1, '2018-12-06 07:35:00', '2018-12-11 03:35:10'),
(118, 1, '4.000', 1, '2018-12-06 06:35:00', '2018-12-11 03:35:10'),
(119, 1, '1.000', 1, '2018-12-06 05:35:00', '2018-12-11 03:35:10'),
(120, 1, '5.000', 1, '2018-12-06 04:35:00', '2018-12-11 03:35:10'),
(121, 1, '3.000', 1, '2018-12-06 03:35:00', '2018-12-11 03:35:11'),
(122, 1, '8.000', 1, '2018-12-06 02:35:00', '2018-12-11 03:35:11'),
(123, 1, '9.000', 1, '2018-12-06 01:35:00', '2018-12-11 03:35:11'),
(124, 1, '6.000', 1, '2018-12-06 00:35:00', '2018-12-11 03:35:11'),
(125, 1, '6.000', 1, '2018-12-05 23:35:00', '2018-12-11 03:35:11'),
(126, 1, '6.000', 1, '2018-12-05 22:35:00', '2018-12-11 03:35:11'),
(127, 1, '7.000', 1, '2018-12-05 21:35:00', '2018-12-11 03:35:11'),
(128, 1, '5.000', 1, '2018-12-05 20:35:00', '2018-12-11 03:35:11'),
(129, 1, '10.000', 1, '2018-12-05 19:35:00', '2018-12-11 03:35:11'),
(130, 1, '9.000', 1, '2018-12-05 18:35:00', '2018-12-11 03:35:12'),
(131, 1, '4.000', 1, '2018-12-05 17:35:00', '2018-12-11 03:35:12'),
(132, 1, '3.000', 1, '2018-12-05 16:35:00', '2018-12-11 03:35:12'),
(133, 1, '6.000', 1, '2018-12-05 15:35:00', '2018-12-11 03:35:12'),
(134, 1, '5.000', 1, '2018-12-05 14:35:00', '2018-12-11 03:35:12'),
(135, 1, '2.000', 1, '2018-12-05 13:35:00', '2018-12-11 03:35:12'),
(136, 1, '9.000', 1, '2018-12-05 12:35:00', '2018-12-11 03:35:12'),
(137, 1, '6.000', 1, '2018-12-05 11:35:00', '2018-12-11 03:35:12'),
(138, 1, '5.000', 1, '2018-12-05 10:35:00', '2018-12-11 03:35:12'),
(139, 1, '1.000', 1, '2018-12-05 09:35:00', '2018-12-11 03:35:12'),
(140, 1, '6.000', 1, '2018-12-05 08:35:00', '2018-12-11 03:35:12'),
(141, 1, '3.000', 1, '2018-12-05 07:35:00', '2018-12-11 03:35:12'),
(142, 1, '2.000', 1, '2018-12-05 06:35:00', '2018-12-11 03:35:12'),
(143, 1, '7.000', 1, '2018-12-05 05:35:00', '2018-12-11 03:35:13'),
(144, 1, '6.000', 1, '2018-12-05 04:35:00', '2018-12-11 03:35:13'),
(145, 1, '9.000', 1, '2018-12-05 03:35:00', '2018-12-11 03:35:13'),
(146, 1, '9.000', 1, '2018-12-05 02:35:00', '2018-12-11 03:35:13'),
(147, 1, '3.000', 1, '2018-12-05 01:35:00', '2018-12-11 03:35:13'),
(148, 1, '3.000', 1, '2018-12-05 00:35:00', '2018-12-11 03:35:13'),
(149, 1, '2.000', 1, '2018-12-04 23:35:00', '2018-12-11 03:35:13'),
(150, 1, '8.000', 1, '2018-12-04 22:35:00', '2018-12-11 03:35:13'),
(151, 1, '3.000', 1, '2018-12-04 21:35:00', '2018-12-11 03:35:13'),
(152, 1, '5.000', 1, '2018-12-04 20:35:00', '2018-12-11 03:35:13'),
(153, 1, '1.000', 1, '2018-12-04 19:35:00', '2018-12-11 03:35:13'),
(154, 1, '5.000', 1, '2018-12-04 18:35:00', '2018-12-11 03:35:13'),
(155, 1, '2.000', 1, '2018-12-04 17:35:00', '2018-12-11 03:35:14'),
(156, 1, '9.000', 1, '2018-12-04 16:35:00', '2018-12-11 03:35:14'),
(157, 1, '4.000', 1, '2018-12-04 15:35:00', '2018-12-11 03:35:14'),
(158, 1, '7.000', 1, '2018-12-04 14:35:00', '2018-12-11 03:35:14'),
(159, 1, '7.000', 1, '2018-12-04 13:35:00', '2018-12-11 03:35:14'),
(160, 1, '4.000', 1, '2018-12-04 12:35:00', '2018-12-11 03:35:14'),
(161, 1, '8.000', 1, '2018-12-04 11:35:00', '2018-12-11 03:35:14'),
(162, 1, '10.000', 1, '2018-12-04 10:35:00', '2018-12-11 03:35:14'),
(163, 1, '10.000', 1, '2018-12-04 09:35:00', '2018-12-11 03:35:14'),
(164, 1, '10.000', 1, '2018-12-04 08:35:00', '2018-12-11 03:35:14'),
(165, 1, '10.000', 1, '2018-12-04 07:35:30', '2018-12-11 03:35:15'),
(166, 1, '8.000', 1, '2018-12-04 06:35:30', '2018-12-11 03:35:15'),
(167, 1, '7.000', 1, '2018-12-04 05:35:30', '2018-12-11 03:35:15'),
(168, 1, '9.000', 1, '2018-12-04 04:35:30', '2018-12-11 03:35:15'),
(169, 1, '6.000', 1, '2018-12-04 03:35:30', '2018-12-11 03:35:15'),
(170, 1, '7.000', 1, '2018-12-04 02:35:30', '2018-12-11 03:35:15'),
(171, 1, '4.000', 1, '2018-12-04 01:35:30', '2018-12-11 03:35:16'),
(172, 1, '4.000', 1, '2018-12-04 00:35:30', '2018-12-11 03:35:16'),
(173, 1, '3.000', 1, '2018-12-03 23:35:30', '2018-12-11 03:35:16'),
(174, 1, '9.000', 1, '2018-12-03 22:35:30', '2018-12-11 03:35:16'),
(175, 1, '4.000', 1, '2018-12-03 21:35:30', '2018-12-11 03:35:16'),
(176, 1, '6.000', 1, '2018-12-03 20:35:30', '2018-12-11 03:35:17'),
(177, 1, '4.000', 1, '2018-12-03 19:35:30', '2018-12-11 03:35:17'),
(178, 1, '5.000', 1, '2018-12-03 18:35:30', '2018-12-11 03:35:17'),
(179, 1, '1.000', 1, '2018-12-03 17:35:30', '2018-12-11 03:35:17'),
(180, 1, '10.000', 1, '2018-12-03 16:35:30', '2018-12-11 03:35:17'),
(181, 1, '2.000', 1, '2018-12-03 15:35:30', '2018-12-11 03:35:17'),
(182, 1, '5.000', 1, '2018-12-03 14:35:30', '2018-12-11 03:35:17'),
(183, 1, '9.000', 1, '2018-12-03 13:35:30', '2018-12-11 03:35:17'),
(184, 1, '5.000', 1, '2018-12-03 12:35:30', '2018-12-11 03:35:17'),
(185, 1, '4.000', 1, '2018-12-03 11:35:30', '2018-12-11 03:35:17'),
(186, 1, '9.000', 1, '2018-12-03 10:35:30', '2018-12-11 03:35:17'),
(187, 1, '2.000', 1, '2018-12-03 09:35:30', '2018-12-11 03:35:17'),
(188, 1, '4.000', 1, '2018-12-03 08:35:30', '2018-12-11 03:35:18'),
(189, 1, '6.000', 1, '2018-12-03 07:35:30', '2018-12-11 03:35:18'),
(190, 1, '10.000', 1, '2018-12-03 06:35:30', '2018-12-11 03:35:18'),
(191, 1, '5.000', 1, '2018-12-03 05:35:30', '2018-12-11 03:35:18'),
(192, 1, '10.000', 1, '2018-12-03 04:35:30', '2018-12-11 03:35:18'),
(193, 1, '8.000', 1, '2018-12-03 03:35:30', '2018-12-11 03:35:18'),
(194, 1, '1.000', 1, '2018-12-03 02:35:30', '2018-12-11 03:35:18'),
(195, 1, '3.000', 1, '2018-12-03 01:35:30', '2018-12-11 03:35:18'),
(196, 1, '7.000', 1, '2018-12-03 00:35:30', '2018-12-11 03:35:18'),
(197, 1, '5.000', 1, '2018-12-02 23:35:30', '2018-12-11 03:35:18'),
(198, 1, '9.000', 1, '2018-12-02 22:35:30', '2018-12-11 03:35:18'),
(199, 1, '8.000', 1, '2018-12-02 21:35:30', '2018-12-11 03:35:18'),
(200, 1, '3.000', 1, '2018-12-02 20:35:30', '2018-12-11 03:35:18');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2015_01_05_201324_CreateComponentGroupsTable', 1),
(2, '2015_01_05_201444_CreateComponentsTable', 1),
(3, '2015_01_05_202446_CreateIncidentTemplatesTable', 1),
(4, '2015_01_05_202609_CreateIncidentsTable', 1),
(5, '2015_01_05_202730_CreateMetricPointsTable', 1),
(6, '2015_01_05_202826_CreateMetricsTable', 1),
(7, '2015_01_05_203014_CreateSettingsTable', 1),
(8, '2015_01_05_203235_CreateSubscribersTable', 1),
(9, '2015_01_05_203341_CreateUsersTable', 1),
(10, '2015_01_09_083419_AlterTableUsersAdd2FA', 1),
(11, '2015_01_16_083825_CreateTagsTable', 1),
(12, '2015_01_16_084030_CreateComponentTagTable', 1),
(13, '2015_02_28_214642_UpdateIncidentsAddScheduledAt', 1),
(14, '2015_05_19_214534_AlterTableComponentGroupsAddOrder', 1),
(15, '2015_05_20_073041_AlterTableIncidentsAddVisibileColumn', 1),
(16, '2015_05_24_210939_create_jobs_table', 1),
(17, '2015_05_24_210948_create_failed_jobs_table', 1),
(18, '2015_06_10_122216_AlterTableComponentsDropUserIdColumn', 1),
(19, '2015_06_10_122229_AlterTableIncidentsDropUserIdColumn', 1),
(20, '2015_08_02_120436_AlterTableSubscribersRemoveDeletedAt', 1),
(21, '2015_08_13_214123_AlterTableMetricsAddDecimalPlacesColumn', 1),
(22, '2015_10_31_211944_CreateInvitesTable', 1),
(23, '2015_11_03_211049_AlterTableComponentsAddEnabledColumn', 1),
(24, '2015_12_26_162258_AlterTableMetricsAddDefaultViewColumn', 1),
(25, '2016_01_09_141852_CreateSubscriptionsTable', 1),
(26, '2016_01_29_154937_AlterTableComponentGroupsAddCollapsedColumn', 1),
(27, '2016_02_18_085210_AlterTableMetricPointsChangeValueColumn', 1),
(28, '2016_03_01_174858_AlterTableMetricPointsAddCounterColumn', 1),
(29, '2016_03_08_125729_CreateIncidentUpdatesTable', 1),
(30, '2016_03_10_144613_AlterTableComponentGroupsMakeColumnInteger', 1),
(31, '2016_04_05_142933_create_sessions_table', 1),
(32, '2016_04_29_061916_AlterTableSubscribersAddGlobalColumn', 1),
(33, '2016_06_02_075012_AlterTableMetricsAddOrderColumn', 1),
(34, '2016_06_05_091615_create_cache_table', 1),
(35, '2016_07_25_052444_AlterTableComponentGroupsAddVisibleColumn', 1),
(36, '2016_08_23_114610_AlterTableUsersAddWelcomedColumn', 1),
(37, '2016_09_04_100000_AlterTableIncidentsAddStickiedColumn', 1),
(38, '2016_10_24_183415_AlterTableIncidentsAddOccurredAtColumn', 1),
(39, '2016_10_30_174400_CreateSchedulesTable', 1),
(40, '2016_10_30_174410_CreateScheduleComponentsTable', 1),
(41, '2016_10_30_182324_AlterTableIncidentsRemoveScheduledColumns', 1),
(42, '2016_12_04_163502_AlterTableMetricsAddVisibleColumn', 1),
(43, '2016_12_05_185045_AlterTableComponentsAddMetaColumn', 1),
(44, '2016_12_29_124643_AlterTableSubscribersAddPhoneNumberSlackColumns', 1),
(45, '2016_12_29_155956_AlterTableComponentsMakeLinkNullable', 1),
(46, '2017_01_03_143916_create_notifications_table', 1),
(47, '2017_02_03_222218_CreateActionsTable', 1),
(48, '2017_06_13_181049_CreateMetaTable', 1),
(49, '2017_07_18_214718_CreateIncidentComponents', 1),
(50, '2017_09_14_180434_AlterIncidentsAddUserId', 1),
(51, '2018_04_02_163328_CreateTaggablesTable', 1),
(52, '2018_04_02_163658_MigrateComponentTagTable', 1),
(53, '2018_06_14_201440_AlterSchedulesSoftDeletes', 1),
(54, '2018_06_17_182507_AlterIncidentsAddNotifications', 1);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) UNSIGNED NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci,
  `status` tinyint(3) UNSIGNED NOT NULL DEFAULT '0',
  `scheduled_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `name`, `message`, `status`, `scheduled_at`, `completed_at`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Demo resets every half hour!0', 'You can schedule downtime for _your_ service!0', 0, '2018-12-11 05:35:36', NULL, '2018-12-11 03:35:36', '2018-12-11 03:35:36', NULL),
(2, 'Demo resets every half hour!1', 'You can schedule downtime for _your_ service!1', 0, '2018-12-11 05:35:36', NULL, '2018-12-11 03:35:36', '2018-12-11 03:35:36', NULL),
(3, 'Demo resets every half hour!2', 'You can schedule downtime for _your_ service!2', 0, '2018-12-11 05:35:36', NULL, '2018-12-11 03:35:36', '2018-12-11 03:35:36', NULL),
(4, 'Demo resets every half hour!3', 'You can schedule downtime for _your_ service!3', 0, '2018-12-11 05:35:36', NULL, '2018-12-11 03:35:36', '2018-12-11 03:35:36', NULL),
(5, 'Demo resets every half hour!4', 'You can schedule downtime for _your_ service!4', 0, '2018-12-11 05:35:36', NULL, '2018-12-11 03:35:36', '2018-12-11 03:35:36', NULL),
(6, 'Demo resets every half hour!5', 'You can schedule downtime for _your_ service!5', 0, '2018-12-11 05:35:36', NULL, '2018-12-11 03:35:36', '2018-12-11 03:35:36', NULL),
(7, 'Demo resets every half hour!6', 'You can schedule downtime for _your_ service!6', 0, '2018-12-11 05:35:36', NULL, '2018-12-11 03:35:36', '2018-12-11 03:35:36', NULL),
(8, 'Demo resets every half hour!7', 'You can schedule downtime for _your_ service!7', 0, '2018-12-11 05:35:36', NULL, '2018-12-11 03:35:36', '2018-12-11 03:35:36', NULL),
(9, 'Demo resets every half hour!8', 'You can schedule downtime for _your_ service!8', 0, '2018-12-11 05:35:37', NULL, '2018-12-11 03:35:37', '2018-12-11 03:35:37', NULL),
(10, 'Demo resets every half hour!9', 'You can schedule downtime for _your_ service!9', 0, '2018-12-11 05:35:37', NULL, '2018-12-11 03:35:37', '2018-12-11 03:35:37', NULL),
(11, 'Demo resets every half hour!10', 'You can schedule downtime for _your_ service!10', 0, '2018-12-11 05:35:37', NULL, '2018-12-11 03:35:37', '2018-12-11 03:35:37', NULL),
(12, 'Demo resets every half hour!11', 'You can schedule downtime for _your_ service!11', 0, '2018-12-11 05:35:37', NULL, '2018-12-11 03:35:37', '2018-12-11 03:35:37', NULL),
(13, 'Demo resets every half hour!12', 'You can schedule downtime for _your_ service!12', 0, '2018-12-11 05:35:37', NULL, '2018-12-11 03:35:37', '2018-12-11 03:35:37', NULL),
(14, 'Demo resets every half hour!13', 'You can schedule downtime for _your_ service!13', 0, '2018-12-11 05:35:37', NULL, '2018-12-11 03:35:37', '2018-12-11 03:35:37', NULL),
(15, 'Demo resets every half hour!14', 'You can schedule downtime for _your_ service!14', 0, '2018-12-11 05:35:37', NULL, '2018-12-11 03:35:37', '2018-12-11 03:35:37', NULL),
(16, 'Demo resets every half hour!15', 'You can schedule downtime for _your_ service!15', 0, '2018-12-11 05:35:37', NULL, '2018-12-11 03:35:37', '2018-12-11 03:35:37', NULL),
(17, 'Demo resets every half hour!16', 'You can schedule downtime for _your_ service!16', 0, '2018-12-11 05:35:37', NULL, '2018-12-11 03:35:37', '2018-12-11 03:35:37', NULL),
(18, 'Demo resets every half hour!17', 'You can schedule downtime for _your_ service!17', 0, '2018-12-11 05:35:37', NULL, '2018-12-11 03:35:37', '2018-12-11 03:35:37', NULL),
(19, 'Demo resets every half hour!18', 'You can schedule downtime for _your_ service!18', 0, '2018-12-11 05:35:37', NULL, '2018-12-11 03:35:37', '2018-12-11 03:35:37', NULL),
(20, 'Demo resets every half hour!19', 'You can schedule downtime for _your_ service!19', 0, '2018-12-11 05:35:37', NULL, '2018-12-11 03:35:37', '2018-12-11 03:35:37', NULL),
(21, 'Demo resets every half hour!20', 'You can schedule downtime for _your_ service!20', 0, '2018-12-11 05:35:37', NULL, '2018-12-11 03:35:37', '2018-12-11 03:35:37', NULL),
(22, 'Demo resets every half hour!21', 'You can schedule downtime for _your_ service!21', 0, '2018-12-11 05:35:37', NULL, '2018-12-11 03:35:37', '2018-12-11 03:35:37', NULL),
(23, 'Demo resets every half hour!22', 'You can schedule downtime for _your_ service!22', 0, '2018-12-11 05:35:38', NULL, '2018-12-11 03:35:38', '2018-12-11 03:35:38', NULL),
(24, 'Demo resets every half hour!23', 'You can schedule downtime for _your_ service!23', 0, '2018-12-11 05:35:38', NULL, '2018-12-11 03:35:38', '2018-12-11 03:35:38', NULL),
(25, 'Demo resets every half hour!24', 'You can schedule downtime for _your_ service!24', 0, '2018-12-11 05:35:38', NULL, '2018-12-11 03:35:38', '2018-12-11 03:35:38', NULL),
(26, 'Demo resets every half hour!25', 'You can schedule downtime for _your_ service!25', 0, '2018-12-11 05:35:38', NULL, '2018-12-11 03:35:38', '2018-12-11 03:35:38', NULL),
(27, 'Demo resets every half hour!26', 'You can schedule downtime for _your_ service!26', 0, '2018-12-11 05:35:38', NULL, '2018-12-11 03:35:38', '2018-12-11 03:35:38', NULL),
(28, 'Demo resets every half hour!27', 'You can schedule downtime for _your_ service!27', 0, '2018-12-11 05:35:38', NULL, '2018-12-11 03:35:38', '2018-12-11 03:35:38', NULL),
(29, 'Demo resets every half hour!28', 'You can schedule downtime for _your_ service!28', 0, '2018-12-11 05:35:38', NULL, '2018-12-11 03:35:38', '2018-12-11 03:35:38', NULL),
(30, 'Demo resets every half hour!29', 'You can schedule downtime for _your_ service!29', 0, '2018-12-11 05:35:38', NULL, '2018-12-11 03:35:38', '2018-12-11 03:35:38', NULL),
(31, 'Demo resets every half hour!30', 'You can schedule downtime for _your_ service!30', 0, '2018-12-11 05:35:38', NULL, '2018-12-11 03:35:38', '2018-12-11 03:35:38', NULL),
(32, 'Demo resets every half hour!31', 'You can schedule downtime for _your_ service!31', 0, '2018-12-11 05:35:38', NULL, '2018-12-11 03:35:38', '2018-12-11 03:35:38', NULL),
(33, 'Demo resets every half hour!32', 'You can schedule downtime for _your_ service!32', 0, '2018-12-11 05:35:39', NULL, '2018-12-11 03:35:39', '2018-12-11 03:35:39', NULL),
(34, 'Demo resets every half hour!33', 'You can schedule downtime for _your_ service!33', 0, '2018-12-11 05:35:39', NULL, '2018-12-11 03:35:39', '2018-12-11 03:35:39', NULL),
(35, 'Demo resets every half hour!34', 'You can schedule downtime for _your_ service!34', 0, '2018-12-11 05:35:39', NULL, '2018-12-11 03:35:39', '2018-12-11 03:35:39', NULL),
(36, 'Demo resets every half hour!35', 'You can schedule downtime for _your_ service!35', 0, '2018-12-11 05:35:39', NULL, '2018-12-11 03:35:39', '2018-12-11 03:35:39', NULL),
(37, 'Demo resets every half hour!36', 'You can schedule downtime for _your_ service!36', 0, '2018-12-11 05:35:39', NULL, '2018-12-11 03:35:39', '2018-12-11 03:35:39', NULL),
(38, 'Demo resets every half hour!37', 'You can schedule downtime for _your_ service!37', 0, '2018-12-11 05:35:39', NULL, '2018-12-11 03:35:39', '2018-12-11 03:35:39', NULL),
(39, 'Demo resets every half hour!38', 'You can schedule downtime for _your_ service!38', 0, '2018-12-11 05:35:39', NULL, '2018-12-11 03:35:39', '2018-12-11 03:35:39', NULL),
(40, 'Demo resets every half hour!39', 'You can schedule downtime for _your_ service!39', 0, '2018-12-11 05:35:39', NULL, '2018-12-11 03:35:39', '2018-12-11 03:35:39', NULL),
(41, 'Demo resets every half hour!40', 'You can schedule downtime for _your_ service!40', 0, '2018-12-11 05:35:39', NULL, '2018-12-11 03:35:39', '2018-12-11 03:35:39', NULL),
(42, 'Demo resets every half hour!41', 'You can schedule downtime for _your_ service!41', 0, '2018-12-11 05:35:39', NULL, '2018-12-11 03:35:39', '2018-12-11 03:35:39', NULL),
(43, 'Demo resets every half hour!42', 'You can schedule downtime for _your_ service!42', 0, '2018-12-11 05:35:39', NULL, '2018-12-11 03:35:39', '2018-12-11 03:35:39', NULL),
(44, 'Demo resets every half hour!43', 'You can schedule downtime for _your_ service!43', 0, '2018-12-11 05:35:39', NULL, '2018-12-11 03:35:39', '2018-12-11 03:35:39', NULL),
(45, 'Demo resets every half hour!44', 'You can schedule downtime for _your_ service!44', 0, '2018-12-11 05:35:39', NULL, '2018-12-11 03:35:39', '2018-12-11 03:35:39', NULL),
(46, 'Demo resets every half hour!45', 'You can schedule downtime for _your_ service!45', 0, '2018-12-11 05:35:39', NULL, '2018-12-11 03:35:39', '2018-12-11 03:35:39', NULL),
(47, 'Demo resets every half hour!46', 'You can schedule downtime for _your_ service!46', 0, '2018-12-11 05:35:40', NULL, '2018-12-11 03:35:40', '2018-12-11 03:35:40', NULL),
(48, 'Demo resets every half hour!47', 'You can schedule downtime for _your_ service!47', 0, '2018-12-11 05:35:40', NULL, '2018-12-11 03:35:40', '2018-12-11 03:35:40', NULL),
(49, 'Demo resets every half hour!48', 'You can schedule downtime for _your_ service!48', 0, '2018-12-11 05:35:40', NULL, '2018-12-11 03:35:40', '2018-12-11 03:35:40', NULL),
(50, 'Demo resets every half hour!49', 'You can schedule downtime for _your_ service!49', 0, '2018-12-11 05:35:40', NULL, '2018-12-11 03:35:40', '2018-12-11 03:35:40', NULL),
(51, 'Demo resets every half hour!50', 'You can schedule downtime for _your_ service!50', 0, '2018-12-11 05:35:40', NULL, '2018-12-11 03:35:40', '2018-12-11 03:35:40', NULL),
(52, 'Demo resets every half hour!51', 'You can schedule downtime for _your_ service!51', 0, '2018-12-11 05:35:40', NULL, '2018-12-11 03:35:40', '2018-12-11 03:35:40', NULL),
(53, 'Demo resets every half hour!52', 'You can schedule downtime for _your_ service!52', 0, '2018-12-11 05:35:40', NULL, '2018-12-11 03:35:40', '2018-12-11 03:35:40', NULL),
(54, 'Demo resets every half hour!53', 'You can schedule downtime for _your_ service!53', 0, '2018-12-11 05:35:40', NULL, '2018-12-11 03:35:40', '2018-12-11 03:35:40', NULL),
(55, 'Demo resets every half hour!54', 'You can schedule downtime for _your_ service!54', 0, '2018-12-11 05:35:40', NULL, '2018-12-11 03:35:40', '2018-12-11 03:35:40', NULL),
(56, 'Demo resets every half hour!55', 'You can schedule downtime for _your_ service!55', 0, '2018-12-11 05:35:40', NULL, '2018-12-11 03:35:40', '2018-12-11 03:35:40', NULL),
(57, 'Demo resets every half hour!56', 'You can schedule downtime for _your_ service!56', 0, '2018-12-11 05:35:40', NULL, '2018-12-11 03:35:40', '2018-12-11 03:35:40', NULL),
(58, 'Demo resets every half hour!57', 'You can schedule downtime for _your_ service!57', 0, '2018-12-11 05:35:40', NULL, '2018-12-11 03:35:40', '2018-12-11 03:35:40', NULL),
(59, 'Demo resets every half hour!58', 'You can schedule downtime for _your_ service!58', 0, '2018-12-11 05:35:40', NULL, '2018-12-11 03:35:40', '2018-12-11 03:35:40', NULL),
(60, 'Demo resets every half hour!59', 'You can schedule downtime for _your_ service!59', 0, '2018-12-11 05:35:40', NULL, '2018-12-11 03:35:40', '2018-12-11 03:35:40', NULL),
(61, 'Demo resets every half hour!60', 'You can schedule downtime for _your_ service!60', 0, '2018-12-11 05:35:40', NULL, '2018-12-11 03:35:40', '2018-12-11 03:35:40', NULL),
(62, 'Demo resets every half hour!61', 'You can schedule downtime for _your_ service!61', 0, '2018-12-11 05:35:40', NULL, '2018-12-11 03:35:40', '2018-12-11 03:35:40', NULL),
(63, 'Demo resets every half hour!62', 'You can schedule downtime for _your_ service!62', 0, '2018-12-11 05:35:41', NULL, '2018-12-11 03:35:41', '2018-12-11 03:35:41', NULL),
(64, 'Demo resets every half hour!63', 'You can schedule downtime for _your_ service!63', 0, '2018-12-11 05:35:41', NULL, '2018-12-11 03:35:41', '2018-12-11 03:35:41', NULL),
(65, 'Demo resets every half hour!64', 'You can schedule downtime for _your_ service!64', 0, '2018-12-11 05:35:41', NULL, '2018-12-11 03:35:41', '2018-12-11 03:35:41', NULL),
(66, 'Demo resets every half hour!65', 'You can schedule downtime for _your_ service!65', 0, '2018-12-11 05:35:41', NULL, '2018-12-11 03:35:41', '2018-12-11 03:35:41', NULL),
(67, 'Demo resets every half hour!66', 'You can schedule downtime for _your_ service!66', 0, '2018-12-11 05:35:41', NULL, '2018-12-11 03:35:41', '2018-12-11 03:35:41', NULL),
(68, 'Demo resets every half hour!67', 'You can schedule downtime for _your_ service!67', 0, '2018-12-11 05:35:41', NULL, '2018-12-11 03:35:41', '2018-12-11 03:35:41', NULL),
(69, 'Demo resets every half hour!68', 'You can schedule downtime for _your_ service!68', 0, '2018-12-11 05:35:41', NULL, '2018-12-11 03:35:41', '2018-12-11 03:35:41', NULL),
(70, 'Demo resets every half hour!69', 'You can schedule downtime for _your_ service!69', 0, '2018-12-11 05:35:41', NULL, '2018-12-11 03:35:41', '2018-12-11 03:35:41', NULL),
(71, 'Demo resets every half hour!70', 'You can schedule downtime for _your_ service!70', 0, '2018-12-11 05:35:41', NULL, '2018-12-11 03:35:41', '2018-12-11 03:35:41', NULL),
(72, 'Demo resets every half hour!71', 'You can schedule downtime for _your_ service!71', 0, '2018-12-11 05:35:41', NULL, '2018-12-11 03:35:41', '2018-12-11 03:35:41', NULL),
(73, 'Demo resets every half hour!72', 'You can schedule downtime for _your_ service!72', 0, '2018-12-11 05:35:41', NULL, '2018-12-11 03:35:41', '2018-12-11 03:35:41', NULL),
(74, 'Demo resets every half hour!73', 'You can schedule downtime for _your_ service!73', 0, '2018-12-11 05:35:41', NULL, '2018-12-11 03:35:41', '2018-12-11 03:35:41', NULL),
(75, 'Demo resets every half hour!74', 'You can schedule downtime for _your_ service!74', 0, '2018-12-11 05:35:41', NULL, '2018-12-11 03:35:41', '2018-12-11 03:35:41', NULL),
(76, 'Demo resets every half hour!75', 'You can schedule downtime for _your_ service!75', 0, '2018-12-11 05:35:41', NULL, '2018-12-11 03:35:41', '2018-12-11 03:35:41', NULL),
(77, 'Demo resets every half hour!76', 'You can schedule downtime for _your_ service!76', 0, '2018-12-11 05:35:41', NULL, '2018-12-11 03:35:41', '2018-12-11 03:35:41', NULL),
(78, 'Demo resets every half hour!77', 'You can schedule downtime for _your_ service!77', 0, '2018-12-11 05:35:42', NULL, '2018-12-11 03:35:42', '2018-12-11 03:35:42', NULL),
(79, 'Demo resets every half hour!78', 'You can schedule downtime for _your_ service!78', 0, '2018-12-11 05:35:42', NULL, '2018-12-11 03:35:42', '2018-12-11 03:35:42', NULL),
(80, 'Demo resets every half hour!79', 'You can schedule downtime for _your_ service!79', 0, '2018-12-11 05:35:42', NULL, '2018-12-11 03:35:42', '2018-12-11 03:35:42', NULL),
(81, 'Demo resets every half hour!80', 'You can schedule downtime for _your_ service!80', 0, '2018-12-11 05:35:42', NULL, '2018-12-11 03:35:42', '2018-12-11 03:35:42', NULL),
(82, 'Demo resets every half hour!81', 'You can schedule downtime for _your_ service!81', 0, '2018-12-11 05:35:42', NULL, '2018-12-11 03:35:42', '2018-12-11 03:35:42', NULL),
(83, 'Demo resets every half hour!82', 'You can schedule downtime for _your_ service!82', 0, '2018-12-11 05:35:42', NULL, '2018-12-11 03:35:42', '2018-12-11 03:35:42', NULL),
(84, 'Demo resets every half hour!83', 'You can schedule downtime for _your_ service!83', 0, '2018-12-11 05:35:42', NULL, '2018-12-11 03:35:42', '2018-12-11 03:35:42', NULL),
(85, 'Demo resets every half hour!84', 'You can schedule downtime for _your_ service!84', 0, '2018-12-11 05:35:42', NULL, '2018-12-11 03:35:42', '2018-12-11 03:35:42', NULL),
(86, 'Demo resets every half hour!85', 'You can schedule downtime for _your_ service!85', 0, '2018-12-11 05:35:42', NULL, '2018-12-11 03:35:42', '2018-12-11 03:35:42', NULL),
(87, 'Demo resets every half hour!86', 'You can schedule downtime for _your_ service!86', 0, '2018-12-11 05:35:42', NULL, '2018-12-11 03:35:42', '2018-12-11 03:35:42', NULL),
(88, 'Demo resets every half hour!87', 'You can schedule downtime for _your_ service!87', 0, '2018-12-11 05:35:42', NULL, '2018-12-11 03:35:42', '2018-12-11 03:35:42', NULL),
(89, 'Demo resets every half hour!88', 'You can schedule downtime for _your_ service!88', 0, '2018-12-11 05:35:42', NULL, '2018-12-11 03:35:42', '2018-12-11 03:35:42', NULL),
(90, 'Demo resets every half hour!89', 'You can schedule downtime for _your_ service!89', 0, '2018-12-11 05:35:42', NULL, '2018-12-11 03:35:42', '2018-12-11 03:35:42', NULL),
(91, 'Demo resets every half hour!90', 'You can schedule downtime for _your_ service!90', 0, '2018-12-11 05:35:42', NULL, '2018-12-11 03:35:42', '2018-12-11 03:35:42', NULL),
(92, 'Demo resets every half hour!91', 'You can schedule downtime for _your_ service!91', 0, '2018-12-11 05:35:43', NULL, '2018-12-11 03:35:43', '2018-12-11 03:35:43', NULL),
(93, 'Demo resets every half hour!92', 'You can schedule downtime for _your_ service!92', 0, '2018-12-11 05:35:43', NULL, '2018-12-11 03:35:43', '2018-12-11 03:35:43', NULL),
(94, 'Demo resets every half hour!93', 'You can schedule downtime for _your_ service!93', 0, '2018-12-11 05:35:43', NULL, '2018-12-11 03:35:43', '2018-12-11 03:35:43', NULL),
(95, 'Demo resets every half hour!94', 'You can schedule downtime for _your_ service!94', 0, '2018-12-11 05:35:43', NULL, '2018-12-11 03:35:43', '2018-12-11 03:35:43', NULL),
(96, 'Demo resets every half hour!95', 'You can schedule downtime for _your_ service!95', 0, '2018-12-11 05:35:43', NULL, '2018-12-11 03:35:43', '2018-12-11 03:35:43', NULL),
(97, 'Demo resets every half hour!96', 'You can schedule downtime for _your_ service!96', 0, '2018-12-11 05:35:43', NULL, '2018-12-11 03:35:43', '2018-12-11 03:35:43', NULL),
(98, 'Demo resets every half hour!97', 'You can schedule downtime for _your_ service!97', 0, '2018-12-11 05:35:43', NULL, '2018-12-11 03:35:43', '2018-12-11 03:35:43', NULL),
(99, 'Demo resets every half hour!98', 'You can schedule downtime for _your_ service!98', 0, '2018-12-11 05:35:43', NULL, '2018-12-11 03:35:43', '2018-12-11 03:35:43', NULL),
(100, 'Demo resets every half hour!99', 'You can schedule downtime for _your_ service!99', 0, '2018-12-11 05:35:43', NULL, '2018-12-11 03:35:43', '2018-12-11 03:35:43', NULL),
(101, 'Demo resets every half hour!100', 'You can schedule downtime for _your_ service!100', 0, '2018-12-11 05:35:43', NULL, '2018-12-11 03:35:43', '2018-12-11 03:35:43', NULL),
(102, 'Demo resets every half hour!101', 'You can schedule downtime for _your_ service!101', 0, '2018-12-11 05:35:44', NULL, '2018-12-11 03:35:44', '2018-12-11 03:35:44', NULL),
(103, 'Demo resets every half hour!102', 'You can schedule downtime for _your_ service!102', 0, '2018-12-11 05:35:44', NULL, '2018-12-11 03:35:44', '2018-12-11 03:35:44', NULL),
(104, 'Demo resets every half hour!103', 'You can schedule downtime for _your_ service!103', 0, '2018-12-11 05:35:44', NULL, '2018-12-11 03:35:44', '2018-12-11 03:35:44', NULL),
(105, 'Demo resets every half hour!104', 'You can schedule downtime for _your_ service!104', 0, '2018-12-11 05:35:44', NULL, '2018-12-11 03:35:44', '2018-12-11 03:35:44', NULL),
(106, 'Demo resets every half hour!105', 'You can schedule downtime for _your_ service!105', 0, '2018-12-11 05:35:44', NULL, '2018-12-11 03:35:44', '2018-12-11 03:35:44', NULL),
(107, 'Demo resets every half hour!106', 'You can schedule downtime for _your_ service!106', 0, '2018-12-11 05:35:44', NULL, '2018-12-11 03:35:44', '2018-12-11 03:35:44', NULL),
(108, 'Demo resets every half hour!107', 'You can schedule downtime for _your_ service!107', 0, '2018-12-11 05:35:44', NULL, '2018-12-11 03:35:44', '2018-12-11 03:35:44', NULL),
(109, 'Demo resets every half hour!108', 'You can schedule downtime for _your_ service!108', 0, '2018-12-11 05:35:44', NULL, '2018-12-11 03:35:44', '2018-12-11 03:35:44', NULL),
(110, 'Demo resets every half hour!109', 'You can schedule downtime for _your_ service!109', 0, '2018-12-11 05:35:44', NULL, '2018-12-11 03:35:44', '2018-12-11 03:35:44', NULL),
(111, 'Demo resets every half hour!110', 'You can schedule downtime for _your_ service!110', 0, '2018-12-11 05:35:44', NULL, '2018-12-11 03:35:44', '2018-12-11 03:35:44', NULL),
(112, 'Demo resets every half hour!111', 'You can schedule downtime for _your_ service!111', 0, '2018-12-11 05:35:44', NULL, '2018-12-11 03:35:44', '2018-12-11 03:35:44', NULL),
(113, 'Demo resets every half hour!112', 'You can schedule downtime for _your_ service!112', 0, '2018-12-11 05:35:44', NULL, '2018-12-11 03:35:44', '2018-12-11 03:35:44', NULL),
(114, 'Demo resets every half hour!113', 'You can schedule downtime for _your_ service!113', 0, '2018-12-11 05:35:44', NULL, '2018-12-11 03:35:44', '2018-12-11 03:35:44', NULL),
(115, 'Demo resets every half hour!114', 'You can schedule downtime for _your_ service!114', 0, '2018-12-11 05:35:45', NULL, '2018-12-11 03:35:45', '2018-12-11 03:35:45', NULL),
(116, 'Demo resets every half hour!115', 'You can schedule downtime for _your_ service!115', 0, '2018-12-11 05:35:45', NULL, '2018-12-11 03:35:45', '2018-12-11 03:35:45', NULL),
(117, 'Demo resets every half hour!116', 'You can schedule downtime for _your_ service!116', 0, '2018-12-11 05:35:45', NULL, '2018-12-11 03:35:45', '2018-12-11 03:35:45', NULL),
(118, 'Demo resets every half hour!117', 'You can schedule downtime for _your_ service!117', 0, '2018-12-11 05:35:45', NULL, '2018-12-11 03:35:45', '2018-12-11 03:35:45', NULL),
(119, 'Demo resets every half hour!118', 'You can schedule downtime for _your_ service!118', 0, '2018-12-11 05:35:45', NULL, '2018-12-11 03:35:45', '2018-12-11 03:35:45', NULL),
(120, 'Demo resets every half hour!119', 'You can schedule downtime for _your_ service!119', 0, '2018-12-11 05:35:45', NULL, '2018-12-11 03:35:45', '2018-12-11 03:35:45', NULL),
(121, 'Demo resets every half hour!120', 'You can schedule downtime for _your_ service!120', 0, '2018-12-11 05:35:45', NULL, '2018-12-11 03:35:45', '2018-12-11 03:35:45', NULL),
(122, 'Demo resets every half hour!121', 'You can schedule downtime for _your_ service!121', 0, '2018-12-11 05:35:45', NULL, '2018-12-11 03:35:45', '2018-12-11 03:35:45', NULL),
(123, 'Demo resets every half hour!122', 'You can schedule downtime for _your_ service!122', 0, '2018-12-11 05:35:45', NULL, '2018-12-11 03:35:45', '2018-12-11 03:35:45', NULL),
(124, 'Demo resets every half hour!123', 'You can schedule downtime for _your_ service!123', 0, '2018-12-11 05:35:45', NULL, '2018-12-11 03:35:45', '2018-12-11 03:35:45', NULL),
(125, 'Demo resets every half hour!124', 'You can schedule downtime for _your_ service!124', 0, '2018-12-11 05:35:45', NULL, '2018-12-11 03:35:45', '2018-12-11 03:35:45', NULL),
(126, 'Demo resets every half hour!125', 'You can schedule downtime for _your_ service!125', 0, '2018-12-11 05:35:45', NULL, '2018-12-11 03:35:45', '2018-12-11 03:35:45', NULL),
(127, 'Demo resets every half hour!126', 'You can schedule downtime for _your_ service!126', 0, '2018-12-11 05:35:46', NULL, '2018-12-11 03:35:46', '2018-12-11 03:35:46', NULL),
(128, 'Demo resets every half hour!127', 'You can schedule downtime for _your_ service!127', 0, '2018-12-11 05:35:46', NULL, '2018-12-11 03:35:46', '2018-12-11 03:35:46', NULL),
(129, 'Demo resets every half hour!128', 'You can schedule downtime for _your_ service!128', 0, '2018-12-11 05:35:46', NULL, '2018-12-11 03:35:46', '2018-12-11 03:35:46', NULL),
(130, 'Demo resets every half hour!129', 'You can schedule downtime for _your_ service!129', 0, '2018-12-11 05:35:46', NULL, '2018-12-11 03:35:46', '2018-12-11 03:35:46', NULL),
(131, 'Demo resets every half hour!130', 'You can schedule downtime for _your_ service!130', 0, '2018-12-11 05:35:46', NULL, '2018-12-11 03:35:46', '2018-12-11 03:35:46', NULL),
(132, 'Demo resets every half hour!131', 'You can schedule downtime for _your_ service!131', 0, '2018-12-11 05:35:46', NULL, '2018-12-11 03:35:46', '2018-12-11 03:35:46', NULL),
(133, 'Demo resets every half hour!132', 'You can schedule downtime for _your_ service!132', 0, '2018-12-11 05:35:46', NULL, '2018-12-11 03:35:46', '2018-12-11 03:35:46', NULL),
(134, 'Demo resets every half hour!133', 'You can schedule downtime for _your_ service!133', 0, '2018-12-11 05:35:46', NULL, '2018-12-11 03:35:46', '2018-12-11 03:35:46', NULL),
(135, 'Demo resets every half hour!134', 'You can schedule downtime for _your_ service!134', 0, '2018-12-11 05:35:47', NULL, '2018-12-11 03:35:47', '2018-12-11 03:35:47', NULL),
(136, 'Demo resets every half hour!135', 'You can schedule downtime for _your_ service!135', 0, '2018-12-11 05:35:47', NULL, '2018-12-11 03:35:47', '2018-12-11 03:35:47', NULL),
(137, 'Demo resets every half hour!136', 'You can schedule downtime for _your_ service!136', 0, '2018-12-11 05:35:47', NULL, '2018-12-11 03:35:47', '2018-12-11 03:35:47', NULL),
(138, 'Demo resets every half hour!137', 'You can schedule downtime for _your_ service!137', 0, '2018-12-11 05:35:47', NULL, '2018-12-11 03:35:47', '2018-12-11 03:35:47', NULL),
(139, 'Demo resets every half hour!138', 'You can schedule downtime for _your_ service!138', 0, '2018-12-11 05:35:47', NULL, '2018-12-11 03:35:47', '2018-12-11 03:35:47', NULL),
(140, 'Demo resets every half hour!139', 'You can schedule downtime for _your_ service!139', 0, '2018-12-11 05:35:47', NULL, '2018-12-11 03:35:47', '2018-12-11 03:35:47', NULL),
(141, 'Demo resets every half hour!140', 'You can schedule downtime for _your_ service!140', 0, '2018-12-11 05:35:47', NULL, '2018-12-11 03:35:47', '2018-12-11 03:35:47', NULL),
(142, 'Demo resets every half hour!141', 'You can schedule downtime for _your_ service!141', 0, '2018-12-11 05:35:47', NULL, '2018-12-11 03:35:47', '2018-12-11 03:35:47', NULL),
(143, 'Demo resets every half hour!142', 'You can schedule downtime for _your_ service!142', 0, '2018-12-11 05:35:47', NULL, '2018-12-11 03:35:47', '2018-12-11 03:35:47', NULL),
(144, 'Demo resets every half hour!143', 'You can schedule downtime for _your_ service!143', 0, '2018-12-11 05:35:48', NULL, '2018-12-11 03:35:48', '2018-12-11 03:35:48', NULL),
(145, 'Demo resets every half hour!144', 'You can schedule downtime for _your_ service!144', 0, '2018-12-11 05:35:48', NULL, '2018-12-11 03:35:48', '2018-12-11 03:35:48', NULL),
(146, 'Demo resets every half hour!145', 'You can schedule downtime for _your_ service!145', 0, '2018-12-11 05:35:48', NULL, '2018-12-11 03:35:48', '2018-12-11 03:35:48', NULL),
(147, 'Demo resets every half hour!146', 'You can schedule downtime for _your_ service!146', 0, '2018-12-11 05:35:48', NULL, '2018-12-11 03:35:48', '2018-12-11 03:35:48', NULL),
(148, 'Demo resets every half hour!147', 'You can schedule downtime for _your_ service!147', 0, '2018-12-11 05:35:48', NULL, '2018-12-11 03:35:48', '2018-12-11 03:35:48', NULL),
(149, 'Demo resets every half hour!148', 'You can schedule downtime for _your_ service!148', 0, '2018-12-11 05:35:48', NULL, '2018-12-11 03:35:48', '2018-12-11 03:35:48', NULL),
(150, 'Demo resets every half hour!149', 'You can schedule downtime for _your_ service!149', 0, '2018-12-11 05:35:48', NULL, '2018-12-11 03:35:48', '2018-12-11 03:35:48', NULL),
(151, 'Demo resets every half hour!150', 'You can schedule downtime for _your_ service!150', 0, '2018-12-11 05:35:48', NULL, '2018-12-11 03:35:48', '2018-12-11 03:35:48', NULL),
(152, 'Demo resets every half hour!151', 'You can schedule downtime for _your_ service!151', 0, '2018-12-11 05:35:48', NULL, '2018-12-11 03:35:48', '2018-12-11 03:35:48', NULL),
(153, 'Demo resets every half hour!152', 'You can schedule downtime for _your_ service!152', 0, '2018-12-11 05:35:48', NULL, '2018-12-11 03:35:48', '2018-12-11 03:35:48', NULL),
(154, 'Demo resets every half hour!153', 'You can schedule downtime for _your_ service!153', 0, '2018-12-11 05:35:48', NULL, '2018-12-11 03:35:48', '2018-12-11 03:35:48', NULL),
(155, 'Demo resets every half hour!154', 'You can schedule downtime for _your_ service!154', 0, '2018-12-11 05:35:48', NULL, '2018-12-11 03:35:48', '2018-12-11 03:35:48', NULL),
(156, 'Demo resets every half hour!155', 'You can schedule downtime for _your_ service!155', 0, '2018-12-11 05:35:49', NULL, '2018-12-11 03:35:49', '2018-12-11 03:35:49', NULL),
(157, 'Demo resets every half hour!156', 'You can schedule downtime for _your_ service!156', 0, '2018-12-11 05:35:49', NULL, '2018-12-11 03:35:49', '2018-12-11 03:35:49', NULL),
(158, 'Demo resets every half hour!157', 'You can schedule downtime for _your_ service!157', 0, '2018-12-11 05:35:49', NULL, '2018-12-11 03:35:49', '2018-12-11 03:35:49', NULL),
(159, 'Demo resets every half hour!158', 'You can schedule downtime for _your_ service!158', 0, '2018-12-11 05:35:49', NULL, '2018-12-11 03:35:49', '2018-12-11 03:35:49', NULL),
(160, 'Demo resets every half hour!159', 'You can schedule downtime for _your_ service!159', 0, '2018-12-11 05:35:49', NULL, '2018-12-11 03:35:49', '2018-12-11 03:35:49', NULL),
(161, 'Demo resets every half hour!160', 'You can schedule downtime for _your_ service!160', 0, '2018-12-11 05:35:49', NULL, '2018-12-11 03:35:49', '2018-12-11 03:35:49', NULL),
(162, 'Demo resets every half hour!161', 'You can schedule downtime for _your_ service!161', 0, '2018-12-11 05:35:49', NULL, '2018-12-11 03:35:49', '2018-12-11 03:35:49', NULL),
(163, 'Demo resets every half hour!162', 'You can schedule downtime for _your_ service!162', 0, '2018-12-11 05:35:49', NULL, '2018-12-11 03:35:49', '2018-12-11 03:35:49', NULL),
(164, 'Demo resets every half hour!163', 'You can schedule downtime for _your_ service!163', 0, '2018-12-11 05:35:49', NULL, '2018-12-11 03:35:49', '2018-12-11 03:35:49', NULL),
(165, 'Demo resets every half hour!164', 'You can schedule downtime for _your_ service!164', 0, '2018-12-11 05:35:49', NULL, '2018-12-11 03:35:49', '2018-12-11 03:35:49', NULL),
(166, 'Demo resets every half hour!165', 'You can schedule downtime for _your_ service!165', 0, '2018-12-11 05:35:49', NULL, '2018-12-11 03:35:49', '2018-12-11 03:35:49', NULL),
(167, 'Demo resets every half hour!166', 'You can schedule downtime for _your_ service!166', 0, '2018-12-11 05:35:49', NULL, '2018-12-11 03:35:49', '2018-12-11 03:35:49', NULL),
(168, 'Demo resets every half hour!167', 'You can schedule downtime for _your_ service!167', 0, '2018-12-11 05:35:49', NULL, '2018-12-11 03:35:49', '2018-12-11 03:35:49', NULL),
(169, 'Demo resets every half hour!168', 'You can schedule downtime for _your_ service!168', 0, '2018-12-11 05:35:49', NULL, '2018-12-11 03:35:49', '2018-12-11 03:35:49', NULL),
(170, 'Demo resets every half hour!169', 'You can schedule downtime for _your_ service!169', 0, '2018-12-11 05:35:49', NULL, '2018-12-11 03:35:49', '2018-12-11 03:35:49', NULL),
(171, 'Demo resets every half hour!170', 'You can schedule downtime for _your_ service!170', 0, '2018-12-11 05:35:49', NULL, '2018-12-11 03:35:49', '2018-12-11 03:35:49', NULL),
(172, 'Demo resets every half hour!171', 'You can schedule downtime for _your_ service!171', 0, '2018-12-11 05:35:49', NULL, '2018-12-11 03:35:49', '2018-12-11 03:35:49', NULL),
(173, 'Demo resets every half hour!172', 'You can schedule downtime for _your_ service!172', 0, '2018-12-11 05:35:49', NULL, '2018-12-11 03:35:49', '2018-12-11 03:35:49', NULL),
(174, 'Demo resets every half hour!173', 'You can schedule downtime for _your_ service!173', 0, '2018-12-11 05:35:50', NULL, '2018-12-11 03:35:50', '2018-12-11 03:35:50', NULL),
(175, 'Demo resets every half hour!174', 'You can schedule downtime for _your_ service!174', 0, '2018-12-11 05:35:50', NULL, '2018-12-11 03:35:50', '2018-12-11 03:35:50', NULL),
(176, 'Demo resets every half hour!175', 'You can schedule downtime for _your_ service!175', 0, '2018-12-11 05:35:50', NULL, '2018-12-11 03:35:50', '2018-12-11 03:35:50', NULL),
(177, 'Demo resets every half hour!176', 'You can schedule downtime for _your_ service!176', 0, '2018-12-11 05:35:50', NULL, '2018-12-11 03:35:50', '2018-12-11 03:35:50', NULL),
(178, 'Demo resets every half hour!177', 'You can schedule downtime for _your_ service!177', 0, '2018-12-11 05:35:50', NULL, '2018-12-11 03:35:50', '2018-12-11 03:35:50', NULL),
(179, 'Demo resets every half hour!178', 'You can schedule downtime for _your_ service!178', 0, '2018-12-11 05:35:50', NULL, '2018-12-11 03:35:50', '2018-12-11 03:35:50', NULL),
(180, 'Demo resets every half hour!179', 'You can schedule downtime for _your_ service!179', 0, '2018-12-11 05:35:50', NULL, '2018-12-11 03:35:50', '2018-12-11 03:35:50', NULL),
(181, 'Demo resets every half hour!180', 'You can schedule downtime for _your_ service!180', 0, '2018-12-11 05:35:50', NULL, '2018-12-11 03:35:50', '2018-12-11 03:35:50', NULL),
(182, 'Demo resets every half hour!181', 'You can schedule downtime for _your_ service!181', 0, '2018-12-11 05:35:50', NULL, '2018-12-11 03:35:50', '2018-12-11 03:35:50', NULL),
(183, 'Demo resets every half hour!182', 'You can schedule downtime for _your_ service!182', 0, '2018-12-11 05:35:51', NULL, '2018-12-11 03:35:51', '2018-12-11 03:35:51', NULL),
(184, 'Demo resets every half hour!183', 'You can schedule downtime for _your_ service!183', 0, '2018-12-11 05:35:51', NULL, '2018-12-11 03:35:51', '2018-12-11 03:35:51', NULL),
(185, 'Demo resets every half hour!184', 'You can schedule downtime for _your_ service!184', 0, '2018-12-11 05:35:51', NULL, '2018-12-11 03:35:51', '2018-12-11 03:35:51', NULL),
(186, 'Demo resets every half hour!185', 'You can schedule downtime for _your_ service!185', 0, '2018-12-11 05:35:51', NULL, '2018-12-11 03:35:51', '2018-12-11 03:35:51', NULL),
(187, 'Demo resets every half hour!186', 'You can schedule downtime for _your_ service!186', 0, '2018-12-11 05:35:51', NULL, '2018-12-11 03:35:51', '2018-12-11 03:35:51', NULL),
(188, 'Demo resets every half hour!187', 'You can schedule downtime for _your_ service!187', 0, '2018-12-11 05:35:51', NULL, '2018-12-11 03:35:51', '2018-12-11 03:35:51', NULL),
(189, 'Demo resets every half hour!188', 'You can schedule downtime for _your_ service!188', 0, '2018-12-11 05:35:51', NULL, '2018-12-11 03:35:51', '2018-12-11 03:35:51', NULL),
(190, 'Demo resets every half hour!189', 'You can schedule downtime for _your_ service!189', 0, '2018-12-11 05:35:51', NULL, '2018-12-11 03:35:51', '2018-12-11 03:35:51', NULL),
(191, 'Demo resets every half hour!190', 'You can schedule downtime for _your_ service!190', 0, '2018-12-11 05:35:51', NULL, '2018-12-11 03:35:51', '2018-12-11 03:35:51', NULL),
(192, 'Demo resets every half hour!191', 'You can schedule downtime for _your_ service!191', 0, '2018-12-11 05:35:51', NULL, '2018-12-11 03:35:51', '2018-12-11 03:35:51', NULL),
(193, 'Demo resets every half hour!192', 'You can schedule downtime for _your_ service!192', 0, '2018-12-11 05:35:51', NULL, '2018-12-11 03:35:51', '2018-12-11 03:35:51', NULL),
(194, 'Demo resets every half hour!193', 'You can schedule downtime for _your_ service!193', 0, '2018-12-11 05:35:51', NULL, '2018-12-11 03:35:51', '2018-12-11 03:35:51', NULL),
(195, 'Demo resets every half hour!194', 'You can schedule downtime for _your_ service!194', 0, '2018-12-11 05:35:51', NULL, '2018-12-11 03:35:51', '2018-12-11 03:35:51', NULL),
(196, 'Demo resets every half hour!195', 'You can schedule downtime for _your_ service!195', 0, '2018-12-11 05:35:51', NULL, '2018-12-11 03:35:51', '2018-12-11 03:35:51', NULL),
(197, 'Demo resets every half hour!196', 'You can schedule downtime for _your_ service!196', 0, '2018-12-11 05:35:51', NULL, '2018-12-11 03:35:51', '2018-12-11 03:35:51', NULL),
(198, 'Demo resets every half hour!197', 'You can schedule downtime for _your_ service!197', 0, '2018-12-11 05:35:51', NULL, '2018-12-11 03:35:51', '2018-12-11 03:35:51', NULL),
(199, 'Demo resets every half hour!198', 'You can schedule downtime for _your_ service!198', 0, '2018-12-11 05:35:52', NULL, '2018-12-11 03:35:52', '2018-12-11 03:35:52', NULL),
(200, 'Demo resets every half hour!199', 'You can schedule downtime for _your_ service!199', 0, '2018-12-11 05:35:52', NULL, '2018-12-11 03:35:52', '2018-12-11 03:35:52', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `schedule_components`
--

CREATE TABLE `schedule_components` (
  `id` int(10) UNSIGNED NOT NULL,
  `schedule_id` int(10) UNSIGNED NOT NULL,
  `component_id` int(10) UNSIGNED NOT NULL,
  `component_status` tinyint(3) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(20636, 'app_name', 'Cachet Demo', '2018-12-11 03:35:52', '2018-12-11 03:35:52'),
(20637, 'app_domain', 'https://demo.cachethq.io', '2018-12-11 03:35:52', '2018-12-11 03:35:52'),
(20638, 'show_support', '1', '2018-12-11 03:35:52', '2018-12-11 03:35:52'),
(20639, 'app_locale', 'en', '2018-12-11 03:35:52', '2018-12-11 03:35:52'),
(20640, 'app_timezone', 'Europe/London', '2018-12-11 03:35:52', '2018-12-11 03:35:52'),
(20641, 'app_incident_days', '7', '2018-12-11 03:35:52', '2018-12-11 03:35:52'),
(20642, 'app_refresh_rate', '0', '2018-12-11 03:35:52', '2018-12-11 03:35:52'),
(20643, 'app_analytics', 'UA-58442674-3', '2018-12-11 03:35:52', '2018-12-11 03:35:52'),
(20644, 'app_analytics_gs', 'GSN-712462-P', '2018-12-11 03:35:53', '2018-12-11 03:35:53'),
(20645, 'display_graphs', '1', '2018-12-11 03:35:53', '2018-12-11 03:35:53'),
(20646, 'app_about', 'This is the demo instance of [Cachet](https://cachethq.io?ref=demo). The open source status page system, for everyone. An [Alt Three](https://alt-three.com) product.', '2018-12-11 03:35:53', '2018-12-11 03:35:53'),
(20647, 'enable_subscribers', '0', '2018-12-11 03:35:53', '2018-12-11 03:35:53');

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE `subscribers` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verify_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slack_webhook_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verified_at` timestamp NULL DEFAULT NULL,
  `global` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions`
--

CREATE TABLE `subscriptions` (
  `id` int(10) UNSIGNED NOT NULL,
  `subscriber_id` int(10) UNSIGNED NOT NULL,
  `component_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subscriptions`
--

INSERT INTO `subscriptions` (`id`, `subscriber_id`, `component_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2018-11-26 05:17:10', '2018-11-26 05:17:10');

-- --------------------------------------------------------

--
-- Table structure for table `taggables`
--

CREATE TABLE `taggables` (
  `id` int(10) UNSIGNED NOT NULL,
  `tag_id` int(10) UNSIGNED NOT NULL,
  `taggable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `taggable_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `taggables`
--

INSERT INTO `taggables` (`id`, `tag_id`, `taggable_type`, `taggable_id`, `created_at`, `updated_at`) VALUES
(1, 1, 'components', 1, '2018-11-26 05:04:29', '2018-11-26 05:04:29');

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'SSSSS', 'sssss', '2018-11-26 05:04:29', '2018-11-26 05:04:29');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_2fa_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `api_key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `level` tinyint(4) NOT NULL DEFAULT '2',
  `welcomed` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `remember_token`, `google_2fa_secret`, `email`, `api_key`, `active`, `level`, `welcomed`, `created_at`, `updated_at`) VALUES
(1, 'test0', '$2y$10$ymZZaKrzuQB9QrwFQyLM3OeOmMp/FVAzOP2hcmXBiti.3qLcjKm8i', NULL, NULL, 'test@test0.com', '9yMHsdioQosnyVK4iCVR0', 1, 1, 0, '2018-12-11 03:33:10', '2018-12-11 03:33:10'),
(2, 'test1', '$2y$10$dlNhNh3WGeR5c7L3E3y98.Jb0Y74EEVf4uew.EvhbxU/fP14Ozlq.', NULL, NULL, 'test@test1.com', '9yMHsdioQosnyVK4iCVR1', 1, 1, 0, '2018-12-11 03:33:10', '2018-12-11 03:33:10'),
(3, 'test2', '$2y$10$fjdUiW95hOxdIS9rx07Y3.2hQpAp17Vb.66Pv6J/OSvPwp.yHTJEu', NULL, NULL, 'test@test2.com', '9yMHsdioQosnyVK4iCVR2', 1, 1, 0, '2018-12-11 03:33:10', '2018-12-11 03:33:10'),
(4, 'test3', '$2y$10$gHrwFK8nppMUbKm0HNkUeehUJYk6uf/nh9AZMV2i.AX0jwQWKnPp.', NULL, NULL, 'test@test3.com', '9yMHsdioQosnyVK4iCVR3', 1, 1, 0, '2018-12-11 03:33:10', '2018-12-11 03:33:10'),
(5, 'test4', '$2y$10$1VyRGgeMui9c131eNAqc..95mhgKbThyefMn0POX4D7fWRecelXPO', NULL, NULL, 'test@test4.com', '9yMHsdioQosnyVK4iCVR4', 1, 1, 0, '2018-12-11 03:33:11', '2018-12-11 03:33:11'),
(6, 'test5', '$2y$10$fYDrF8sBt4Ldq2L8CovUP.nMvFZ3J6bJj59rM7cMhmkIoa8a0f5Vq', NULL, NULL, 'test@test5.com', '9yMHsdioQosnyVK4iCVR5', 1, 1, 0, '2018-12-11 03:33:11', '2018-12-11 03:33:11'),
(7, 'test6', '$2y$10$2a92/KR.IOcu5WsMOs0hjudlWYApQJqphpoMpF4HxQiVpvszTl7S6', NULL, NULL, 'test@test6.com', '9yMHsdioQosnyVK4iCVR6', 1, 1, 0, '2018-12-11 03:33:11', '2018-12-11 03:33:11'),
(8, 'test7', '$2y$10$74.ZtOzMd73SEqgDTeAs0..NM6hQtKCerPLQ2lYAVr8u4PONqqNmW', NULL, NULL, 'test@test7.com', '9yMHsdioQosnyVK4iCVR7', 1, 1, 0, '2018-12-11 03:33:11', '2018-12-11 03:33:11'),
(9, 'test8', '$2y$10$UAASo4Eta6gfEzN7mMmvw.NACHXirPj9JJiOcDqVfuqdP8fitdDB6', NULL, NULL, 'test@test8.com', '9yMHsdioQosnyVK4iCVR8', 1, 1, 0, '2018-12-11 03:33:11', '2018-12-11 03:33:11'),
(10, 'test9', '$2y$10$AHaG91H9O/Wy6Ke7sFMF9OZDLojDwrt9/kBhBctoF2zH7mTooqi9m', NULL, NULL, 'test@test9.com', '9yMHsdioQosnyVK4iCVR9', 1, 1, 0, '2018-12-11 03:33:12', '2018-12-11 03:33:12'),
(11, 'test10', '$2y$10$WBvegh1VUEKfj/2eyqkpsu9ORwTEMSWKfoMSl2SrkXKDQJVCAshk.', NULL, NULL, 'test@test10.com', '9yMHsdioQosnyVK4iCVR10', 1, 1, 0, '2018-12-11 03:33:12', '2018-12-11 03:33:12'),
(12, 'test11', '$2y$10$oVtWCO2sKWNdJBddH77t9esWuQJ5UIslsTDszKz/rMtLZs1EWKtm2', NULL, NULL, 'test@test11.com', '9yMHsdioQosnyVK4iCVR11', 1, 1, 0, '2018-12-11 03:33:12', '2018-12-11 03:33:12'),
(13, 'test12', '$2y$10$r2BhtcmmN06NlyahPg1LSe6AvkLVt/crr9ZK.EtC28B5mnJWXNauW', NULL, NULL, 'test@test12.com', '9yMHsdioQosnyVK4iCVR12', 1, 1, 0, '2018-12-11 03:33:13', '2018-12-11 03:33:13'),
(14, 'test13', '$2y$10$quVL5OFdh3gZXgY.oVY83uUjjoFhAkteM4wn82SW7Ck5oiMRpt0My', NULL, NULL, 'test@test13.com', '9yMHsdioQosnyVK4iCVR13', 1, 1, 0, '2018-12-11 03:33:13', '2018-12-11 03:33:13'),
(15, 'test14', '$2y$10$Jt4E3A.u9yUQx56TIMDwvOQzkcHfA/LwmsoZGd1BjPGBiG3lgCHwO', NULL, NULL, 'test@test14.com', '9yMHsdioQosnyVK4iCVR14', 1, 1, 0, '2018-12-11 03:33:13', '2018-12-11 03:33:13'),
(16, 'test15', '$2y$10$rLVGuHLMO7WKs4p7lF8jFeatM6wyp/2dPabN7K795TdorBxCc9Ewi', NULL, NULL, 'test@test15.com', '9yMHsdioQosnyVK4iCVR15', 1, 1, 0, '2018-12-11 03:33:13', '2018-12-11 03:33:13'),
(17, 'test16', '$2y$10$EUUI2yyNb/WmyeH1dFYEOeuqNZkKuofUNhL/zQnOHPWhVET3bDemy', NULL, NULL, 'test@test16.com', '9yMHsdioQosnyVK4iCVR16', 1, 1, 0, '2018-12-11 03:33:13', '2018-12-11 03:33:13'),
(18, 'test17', '$2y$10$JamCQnXPsQwiLsQJhCZwB.2ale8elmrgd8iEnOrF5Y8Zmp.ELm83m', NULL, NULL, 'test@test17.com', '9yMHsdioQosnyVK4iCVR17', 1, 1, 0, '2018-12-11 03:33:14', '2018-12-11 03:33:14'),
(19, 'test18', '$2y$10$oKt0jZZqAQBGb5qS2BH92eroTyXfyqnp3lXB/Jvt8GvSGOG/tsgmu', NULL, NULL, 'test@test18.com', '9yMHsdioQosnyVK4iCVR18', 1, 1, 0, '2018-12-11 03:33:14', '2018-12-11 03:33:14'),
(20, 'test19', '$2y$10$6g/dPPHxmNxub5PjZ5sxIu6i0YKPonItAjME0KvKjNeEoapWT/3TW', NULL, NULL, 'test@test19.com', '9yMHsdioQosnyVK4iCVR19', 1, 1, 0, '2018-12-11 03:33:14', '2018-12-11 03:33:14'),
(21, 'test20', '$2y$10$gSdE5l/4OyPc9hWjUJ6.MOveCp8GOAR07bIhAc1V17d3BGwuWdnYq', NULL, NULL, 'test@test20.com', '9yMHsdioQosnyVK4iCVR20', 1, 1, 0, '2018-12-11 03:33:14', '2018-12-11 03:33:14'),
(22, 'test21', '$2y$10$E6N6tmXAMKovlrLHCYvyGu.wtxfxY5hdCH97akG.yJR5wneTAXney', NULL, NULL, 'test@test21.com', '9yMHsdioQosnyVK4iCVR21', 1, 1, 0, '2018-12-11 03:33:15', '2018-12-11 03:33:15'),
(23, 'test22', '$2y$10$2vvEXKCIDUuWfwDaNO9Vzu70RrADMFuInOn6q4oUgVY4GzHCx8Wpe', NULL, NULL, 'test@test22.com', '9yMHsdioQosnyVK4iCVR22', 1, 1, 0, '2018-12-11 03:33:15', '2018-12-11 03:33:15'),
(24, 'test23', '$2y$10$B.TICoSf3KJNcCaiR3xI6e0yuNr8.dTscYMtCbCnnIiWCwF7YikEa', NULL, NULL, 'test@test23.com', '9yMHsdioQosnyVK4iCVR23', 1, 1, 0, '2018-12-11 03:33:15', '2018-12-11 03:33:15'),
(25, 'test24', '$2y$10$z2QS7ilLKkpmjvpsMT69Me/SxIk1AlVHrIP16l/Gbq2VCE64MtCdu', NULL, NULL, 'test@test24.com', '9yMHsdioQosnyVK4iCVR24', 1, 1, 0, '2018-12-11 03:33:15', '2018-12-11 03:33:15'),
(26, 'test25', '$2y$10$/ERaxJ3.BEGnR8tcmOI4mO9bBIGlaobWGmc1.EN2h/heQ700pG1RC', NULL, NULL, 'test@test25.com', '9yMHsdioQosnyVK4iCVR25', 1, 1, 0, '2018-12-11 03:33:15', '2018-12-11 03:33:15'),
(27, 'test26', '$2y$10$ApuRfcfh84ZFNo2pIZzT4OUCSvggN7zLYSWo2y5o6pkrMNDhAjz0O', NULL, NULL, 'test@test26.com', '9yMHsdioQosnyVK4iCVR26', 1, 1, 0, '2018-12-11 03:33:16', '2018-12-11 03:33:16'),
(28, 'test27', '$2y$10$FPGiAZQrUiXfpj1Ed.nxOOprIoTZPW2fEoUGuR1EBE8UPKdJ5xcRu', NULL, NULL, 'test@test27.com', '9yMHsdioQosnyVK4iCVR27', 1, 1, 0, '2018-12-11 03:33:16', '2018-12-11 03:33:16'),
(29, 'test28', '$2y$10$gsI6VYT3rAd/jqHlAv.0ZeMock0MDceJrE1cgudLFWpef12NWLDFq', NULL, NULL, 'test@test28.com', '9yMHsdioQosnyVK4iCVR28', 1, 1, 0, '2018-12-11 03:33:16', '2018-12-11 03:33:16'),
(30, 'test29', '$2y$10$O69ac1zrlqWGLBUvZ13Nfu40qcpHxD5wO3klDyn/syl6w/Lbe7sti', NULL, NULL, 'test@test29.com', '9yMHsdioQosnyVK4iCVR29', 1, 1, 0, '2018-12-11 03:33:16', '2018-12-11 03:33:16'),
(31, 'test30', '$2y$10$nN2jVBlKbMgR.ccNPokCIeSacEUohUgyK.16M5gzlttgBBYC1jKVS', NULL, NULL, 'test@test30.com', '9yMHsdioQosnyVK4iCVR30', 1, 1, 0, '2018-12-11 03:33:17', '2018-12-11 03:33:17'),
(32, 'test31', '$2y$10$/Ssh7w0Rfkqn2reu//Qy7.eeL4UUa1bycMV52Fm5OdMqASa185gdq', NULL, NULL, 'test@test31.com', '9yMHsdioQosnyVK4iCVR31', 1, 1, 0, '2018-12-11 03:33:17', '2018-12-11 03:33:17'),
(33, 'test32', '$2y$10$cjy44IeEjyrEZtll99PNEeg.vI3R84zsvctcqAL2jHHAVmb32J/pW', NULL, NULL, 'test@test32.com', '9yMHsdioQosnyVK4iCVR32', 1, 1, 0, '2018-12-11 03:33:17', '2018-12-11 03:33:17'),
(34, 'test33', '$2y$10$Hjy4e28Zq1kzyC/wWVexDu2fQNtmorDACNveZdytzuH.aCKdfjnxa', NULL, NULL, 'test@test33.com', '9yMHsdioQosnyVK4iCVR33', 1, 1, 0, '2018-12-11 03:33:17', '2018-12-11 03:33:17'),
(35, 'test34', '$2y$10$V/YQlyNTe5eYoSmB/b6hGu/z.aXTJ0bVmZrQCGzSaq5ILWUJkfZsS', NULL, NULL, 'test@test34.com', '9yMHsdioQosnyVK4iCVR34', 1, 1, 0, '2018-12-11 03:33:17', '2018-12-11 03:33:17'),
(36, 'test35', '$2y$10$RskRuEL4TcpboA/w8cmzpOKwGur0nNrbBKkS/g7f9WXvDBREgumPG', NULL, NULL, 'test@test35.com', '9yMHsdioQosnyVK4iCVR35', 1, 1, 0, '2018-12-11 03:33:18', '2018-12-11 03:33:18'),
(37, 'test36', '$2y$10$/3A8fp5lYXFOHSVnv4aPcuhs7AIhl4sIPOvCZ5dR0ePB7jMdE/.F2', NULL, NULL, 'test@test36.com', '9yMHsdioQosnyVK4iCVR36', 1, 1, 0, '2018-12-11 03:33:18', '2018-12-11 03:33:18'),
(38, 'test37', '$2y$10$dmIFgamSFV59zqualzAg5OFGOqlhHyKu8zF5vkyca/.dmc5Q7mOu.', NULL, NULL, 'test@test37.com', '9yMHsdioQosnyVK4iCVR37', 1, 1, 0, '2018-12-11 03:33:18', '2018-12-11 03:33:18'),
(39, 'test38', '$2y$10$cwd4cqnIcsLln1m3GI7gJuMwmAwhJqavMSget0byGX5LumESC.j4C', NULL, NULL, 'test@test38.com', '9yMHsdioQosnyVK4iCVR38', 1, 1, 0, '2018-12-11 03:33:18', '2018-12-11 03:33:18'),
(40, 'test39', '$2y$10$IBnGrKSBo9yu762VT4Hx1u9s69cX.JWdmTzMoAZ5Uf1nXaEXldHrW', NULL, NULL, 'test@test39.com', '9yMHsdioQosnyVK4iCVR39', 1, 1, 0, '2018-12-11 03:33:18', '2018-12-11 03:33:18'),
(41, 'test40', '$2y$10$VHy2aSE/rOauAOI..srH9urPYMw7o7iVtIQ6m.BFEYFNUM4Trvkhe', NULL, NULL, 'test@test40.com', '9yMHsdioQosnyVK4iCVR40', 1, 1, 0, '2018-12-11 03:33:19', '2018-12-11 03:33:19'),
(42, 'test41', '$2y$10$KWuGzDrK5lhFpeujyFxFBeKRqWBZP0BrcIpAAOHjXaZ5e1LgeJODy', NULL, NULL, 'test@test41.com', '9yMHsdioQosnyVK4iCVR41', 1, 1, 0, '2018-12-11 03:33:19', '2018-12-11 03:33:19'),
(43, 'test42', '$2y$10$FNuAuAb0C2GMJemp03rrj.K36wfDzOV9L.nQZPJ1keyW3xDsJYKgq', NULL, NULL, 'test@test42.com', '9yMHsdioQosnyVK4iCVR42', 1, 1, 0, '2018-12-11 03:33:19', '2018-12-11 03:33:19'),
(44, 'test43', '$2y$10$reEnztOwQ9pTXTI49qNl4usX/JPgmgcjVTkNnt0.ZYtUFOBbVVckm', NULL, NULL, 'test@test43.com', '9yMHsdioQosnyVK4iCVR43', 1, 1, 0, '2018-12-11 03:33:19', '2018-12-11 03:33:19'),
(45, 'test44', '$2y$10$YrjNW3emJBeSYVs44b6kuepj6G52iKHMXWOgXWTY2bJXzEBEf4mqa', NULL, NULL, 'test@test44.com', '9yMHsdioQosnyVK4iCVR44', 1, 1, 0, '2018-12-11 03:33:19', '2018-12-11 03:33:19'),
(46, 'test45', '$2y$10$Mlz3g6TIqCGxNBHu1WMvoe5UWL1sklPWo96b8WOHb5vyV8twoCkyG', NULL, NULL, 'test@test45.com', '9yMHsdioQosnyVK4iCVR45', 1, 1, 0, '2018-12-11 03:33:20', '2018-12-11 03:33:20'),
(47, 'test46', '$2y$10$rWBKpElc8y6qweS/IsGusuxUXeqMtW6.TNwnVHxVUMt4.cQQlv8he', NULL, NULL, 'test@test46.com', '9yMHsdioQosnyVK4iCVR46', 1, 1, 0, '2018-12-11 03:33:20', '2018-12-11 03:33:20'),
(48, 'test47', '$2y$10$KJ1CJBHOZcy7Hm1P4qyWD.IwOGAdk4OmNi.V37I9fOfR6G/aiMek6', NULL, NULL, 'test@test47.com', '9yMHsdioQosnyVK4iCVR47', 1, 1, 0, '2018-12-11 03:33:20', '2018-12-11 03:33:20'),
(49, 'test48', '$2y$10$MoZ1tSzUjZ3xpI9urrHZnOCoKCHxtQG73/qJNhFMQQxUbib8foBMu', NULL, NULL, 'test@test48.com', '9yMHsdioQosnyVK4iCVR48', 1, 1, 0, '2018-12-11 03:33:20', '2018-12-11 03:33:20'),
(50, 'test49', '$2y$10$rfOHV6DaTtZgE8veKab58OrV6d2Y4aO5dR7fMkfwolmMenlbubpki', NULL, NULL, 'test@test49.com', '9yMHsdioQosnyVK4iCVR49', 1, 1, 0, '2018-12-11 03:33:20', '2018-12-11 03:33:20'),
(51, 'test50', '$2y$10$6gFJF6PtLuUUVb6FPDAdlOooEvAhNd.NU/5nek7wyhBFVgMzdYRX2', NULL, NULL, 'test@test50.com', '9yMHsdioQosnyVK4iCVR50', 1, 1, 0, '2018-12-11 03:33:21', '2018-12-11 03:33:21'),
(52, 'test51', '$2y$10$1kLUaqJo7lzM0y/2Hi11oOTiuw35G.5owkG1Y0XIkdmraamWStsBG', NULL, NULL, 'test@test51.com', '9yMHsdioQosnyVK4iCVR51', 1, 1, 0, '2018-12-11 03:33:21', '2018-12-11 03:33:21'),
(53, 'test52', '$2y$10$SXIQpXQCTEsJPyu9Xe1PI.AqeMTRZCkiTha51lDZMngE/jG4k4jla', NULL, NULL, 'test@test52.com', '9yMHsdioQosnyVK4iCVR52', 1, 1, 0, '2018-12-11 03:33:21', '2018-12-11 03:33:21'),
(54, 'test53', '$2y$10$3jun5FQe295AQ7tG8S1elO1PW5XDKsu3X3192J6ZmNYbYNe0CT9uG', NULL, NULL, 'test@test53.com', '9yMHsdioQosnyVK4iCVR53', 1, 1, 0, '2018-12-11 03:33:21', '2018-12-11 03:33:21'),
(55, 'test54', '$2y$10$LbDK37B/2.N.w/tRkVqYN.TiH7bPAic42sp9PVZVJe0tWqOJl3aoK', NULL, NULL, 'test@test54.com', '9yMHsdioQosnyVK4iCVR54', 1, 1, 0, '2018-12-11 03:33:21', '2018-12-11 03:33:21'),
(56, 'test55', '$2y$10$8Iw7DoxYb6pcR2LUt0pba.xgoOA5s5wdeVfrmd32RndQO9E5jatfu', NULL, NULL, 'test@test55.com', '9yMHsdioQosnyVK4iCVR55', 1, 1, 0, '2018-12-11 03:33:22', '2018-12-11 03:33:22'),
(57, 'test56', '$2y$10$kWmFJqyOo6HODyJEM2w0teJVtRJXrFlYmyLp70JzPaxAd1BQ8C2uC', NULL, NULL, 'test@test56.com', '9yMHsdioQosnyVK4iCVR56', 1, 1, 0, '2018-12-11 03:33:22', '2018-12-11 03:33:22'),
(58, 'test57', '$2y$10$YRAWssglq0coj6WRG73yxuM4id94IereLm.9/D17yUVEvDnkKkqOO', NULL, NULL, 'test@test57.com', '9yMHsdioQosnyVK4iCVR57', 1, 1, 0, '2018-12-11 03:33:22', '2018-12-11 03:33:22'),
(59, 'test58', '$2y$10$TTnjMGbWBVcfSa0XAj7d0u927ateMj4BLJYRryMpvUFQjUA..dSyq', NULL, NULL, 'test@test58.com', '9yMHsdioQosnyVK4iCVR58', 1, 1, 0, '2018-12-11 03:33:23', '2018-12-11 03:33:23'),
(60, 'test59', '$2y$10$qW8Xu3Pl0HDOUkqAyXdNU.baR1lFpfSwpvBPc4NhP/BgyLbapUVki', NULL, NULL, 'test@test59.com', '9yMHsdioQosnyVK4iCVR59', 1, 1, 0, '2018-12-11 03:33:23', '2018-12-11 03:33:23'),
(61, 'test60', '$2y$10$Z/n2gAEO2VoCSNqyN1fAKeIuH7XAPVXMtZ3SQ9Q.tr8QJU1xFO4Ja', NULL, NULL, 'test@test60.com', '9yMHsdioQosnyVK4iCVR60', 1, 1, 0, '2018-12-11 03:33:23', '2018-12-11 03:33:23'),
(62, 'test61', '$2y$10$UnXUYEIijZBIiVhQWg7ojOzxMimsowjFpBax30aTt4oS/nx0ME.r.', NULL, NULL, 'test@test61.com', '9yMHsdioQosnyVK4iCVR61', 1, 1, 0, '2018-12-11 03:33:23', '2018-12-11 03:33:23'),
(63, 'test62', '$2y$10$HeELFQFVSBzQ225isgaFbuGJIS9Ng8dK25w/i1iNxmVGt3uxWaYPK', NULL, NULL, 'test@test62.com', '9yMHsdioQosnyVK4iCVR62', 1, 1, 0, '2018-12-11 03:33:23', '2018-12-11 03:33:23'),
(64, 'test63', '$2y$10$vdg0pGCaaj0L2KNbLopgEOkEwUPQzlNlfAKNoj.OvT9YgBPUTyP6u', NULL, NULL, 'test@test63.com', '9yMHsdioQosnyVK4iCVR63', 1, 1, 0, '2018-12-11 03:33:23', '2018-12-11 03:33:23'),
(65, 'test64', '$2y$10$vkbkC1F3XnwR0T9dKhUO4eSUk6ZFfKqRt4Ai4iLCWrb8LnQW//cFa', NULL, NULL, 'test@test64.com', '9yMHsdioQosnyVK4iCVR64', 1, 1, 0, '2018-12-11 03:33:24', '2018-12-11 03:33:24'),
(66, 'test65', '$2y$10$7IGKh8SMXR2NMbsu3dcnFuqUqrenFTVvbh1Rhvv9FIvuneUzGdVcS', NULL, NULL, 'test@test65.com', '9yMHsdioQosnyVK4iCVR65', 1, 1, 0, '2018-12-11 03:33:24', '2018-12-11 03:33:24'),
(67, 'test66', '$2y$10$8ZqIyIv8CT3WkN1WBmnrmORRduuVRC5ZZoizcjYl/OI545uf3Qqsi', NULL, NULL, 'test@test66.com', '9yMHsdioQosnyVK4iCVR66', 1, 1, 0, '2018-12-11 03:33:24', '2018-12-11 03:33:24'),
(68, 'test67', '$2y$10$j5ELHiq3AJBfamQKdPFRDup7mamlxIGDBdNgp9TJrswOHrAnRNC8a', NULL, NULL, 'test@test67.com', '9yMHsdioQosnyVK4iCVR67', 1, 1, 0, '2018-12-11 03:33:24', '2018-12-11 03:33:24'),
(69, 'test68', '$2y$10$8MTs4ZbK3YboPOEmgKwAJu4a1NgNEJAMzATnjzAoNAkhEpmL4t5/.', NULL, NULL, 'test@test68.com', '9yMHsdioQosnyVK4iCVR68', 1, 1, 0, '2018-12-11 03:33:25', '2018-12-11 03:33:25'),
(70, 'test69', '$2y$10$p0Z6Y8izin0ONiLe5qNaJ.CbOF4qdSbXop.IqQUzrqWgooA6g1V2S', NULL, NULL, 'test@test69.com', '9yMHsdioQosnyVK4iCVR69', 1, 1, 0, '2018-12-11 03:33:25', '2018-12-11 03:33:25'),
(71, 'test70', '$2y$10$rbI9B2nR.DPcKfco2yug.ugDS/AHdfi.tNvM8pnz2Hyu.GHoJ0zlO', NULL, NULL, 'test@test70.com', '9yMHsdioQosnyVK4iCVR70', 1, 1, 0, '2018-12-11 03:33:25', '2018-12-11 03:33:25'),
(72, 'test71', '$2y$10$Yu.rMe13boHfsPQQxGTh2uKf8QlODN1Cn2iFTLnL7Yebk/3e5hHrm', NULL, NULL, 'test@test71.com', '9yMHsdioQosnyVK4iCVR71', 1, 1, 0, '2018-12-11 03:33:25', '2018-12-11 03:33:25'),
(73, 'test72', '$2y$10$izWgV5gJYsp/VosGPQ/oYOKu9vzb8qmzFJSaiPwM/19vHTZ.djPEO', NULL, NULL, 'test@test72.com', '9yMHsdioQosnyVK4iCVR72', 1, 1, 0, '2018-12-11 03:33:25', '2018-12-11 03:33:25'),
(74, 'test73', '$2y$10$iz1tJ1UGOe0IEb3smdCIheAoduHc7Jm5oPzqOHmwEpkTbz5f6kxmK', NULL, NULL, 'test@test73.com', '9yMHsdioQosnyVK4iCVR73', 1, 1, 0, '2018-12-11 03:33:26', '2018-12-11 03:33:26'),
(75, 'test74', '$2y$10$bO2/l74EZ1OmGy4BCEclRefKD9qlAwPBglXjqrwzfErDWAemf5ScK', NULL, NULL, 'test@test74.com', '9yMHsdioQosnyVK4iCVR74', 1, 1, 0, '2018-12-11 03:33:26', '2018-12-11 03:33:26'),
(76, 'test75', '$2y$10$5FFG43m/hhT9H7zbBvNNSeFamVSRLDuRrdp2cMYctILaSPabU/Cgi', NULL, NULL, 'test@test75.com', '9yMHsdioQosnyVK4iCVR75', 1, 1, 0, '2018-12-11 03:33:26', '2018-12-11 03:33:26'),
(77, 'test76', '$2y$10$Oykztb3NVsFUWyxMsUTBZObO7JtppbAdRxqZsy4KPl26QTeYZnCae', NULL, NULL, 'test@test76.com', '9yMHsdioQosnyVK4iCVR76', 1, 1, 0, '2018-12-11 03:33:26', '2018-12-11 03:33:26'),
(78, 'test77', '$2y$10$g.rOM72quS4tbywYKjCLOuDSVuNpaKBwcB4jJy4RSBMexJNUTX80S', NULL, NULL, 'test@test77.com', '9yMHsdioQosnyVK4iCVR77', 1, 1, 0, '2018-12-11 03:33:26', '2018-12-11 03:33:26'),
(79, 'test78', '$2y$10$N60pyI./aAXmGzdlomyl/OgOCENS7STGphSllWD.tQb9wZkrbOvBG', NULL, NULL, 'test@test78.com', '9yMHsdioQosnyVK4iCVR78', 1, 1, 0, '2018-12-11 03:33:27', '2018-12-11 03:33:27'),
(80, 'test79', '$2y$10$yPtfmakLJLHuIjFUu5RgEeHTinFIBoKazn5uSfPMKtFPXuhuYs5NW', NULL, NULL, 'test@test79.com', '9yMHsdioQosnyVK4iCVR79', 1, 1, 0, '2018-12-11 03:33:27', '2018-12-11 03:33:27'),
(81, 'test80', '$2y$10$u7soQDFv.Pm7I2kOVLWmheNx2KMpPqymz.DPSrwAv3N0OrzPKZ2Wu', NULL, NULL, 'test@test80.com', '9yMHsdioQosnyVK4iCVR80', 1, 1, 0, '2018-12-11 03:33:27', '2018-12-11 03:33:27'),
(82, 'test81', '$2y$10$og.ZW.e8evvABHyANGkMEOeij3jce30NeP9gJaMTENTf0qA3yddWa', NULL, NULL, 'test@test81.com', '9yMHsdioQosnyVK4iCVR81', 1, 1, 0, '2018-12-11 03:33:27', '2018-12-11 03:33:27'),
(83, 'test82', '$2y$10$EnlXi53I3cvDlegZcCycR.7ooRstqUobwM5ghwa3GrWBoaj0d9eBe', NULL, NULL, 'test@test82.com', '9yMHsdioQosnyVK4iCVR82', 1, 1, 0, '2018-12-11 03:33:27', '2018-12-11 03:33:27'),
(84, 'test83', '$2y$10$kPYpSuukGHIJDe0bGVZlPey9qxLVMj0ddNfhyo4lvMnnYMbSlaXSW', NULL, NULL, 'test@test83.com', '9yMHsdioQosnyVK4iCVR83', 1, 1, 0, '2018-12-11 03:33:28', '2018-12-11 03:33:28'),
(85, 'test84', '$2y$10$pha0OjV8gzM4Y72dOeMgUuKJYoZ8NwbY0dDKxdEwi6TsXJHMlRmDm', NULL, NULL, 'test@test84.com', '9yMHsdioQosnyVK4iCVR84', 1, 1, 0, '2018-12-11 03:33:28', '2018-12-11 03:33:28'),
(86, 'test85', '$2y$10$aGzjNVz/571aa5ql9EwCne/mq3kXrD0krSa0Kw.dY0USqWlVHpKhu', NULL, NULL, 'test@test85.com', '9yMHsdioQosnyVK4iCVR85', 1, 1, 0, '2018-12-11 03:33:28', '2018-12-11 03:33:28'),
(87, 'test86', '$2y$10$IjYFBB.n7sVZE1Bvf5i9H.N0DdGOT3Fq0p8/yqGMk82apDI2Palde', NULL, NULL, 'test@test86.com', '9yMHsdioQosnyVK4iCVR86', 1, 1, 0, '2018-12-11 03:33:28', '2018-12-11 03:33:28'),
(88, 'test87', '$2y$10$rM/iQ3I9yvc8/n4FyDtt/.DvcbyhkvTqEETQwN8FgTU7FwpbgrlD2', NULL, NULL, 'test@test87.com', '9yMHsdioQosnyVK4iCVR87', 1, 1, 0, '2018-12-11 03:33:29', '2018-12-11 03:33:29'),
(89, 'test88', '$2y$10$XYg1jVRKJ2S6FXybowuPLOuknI05NS8Jh0.F3M8qMTXZREf9RaLmS', NULL, NULL, 'test@test88.com', '9yMHsdioQosnyVK4iCVR88', 1, 1, 0, '2018-12-11 03:33:29', '2018-12-11 03:33:29'),
(90, 'test89', '$2y$10$FTNDX7oHuPRV8UjYJ0RJp.NPW5u6.5Zxv0NEMVmKnlyS9W1JI7TvC', NULL, NULL, 'test@test89.com', '9yMHsdioQosnyVK4iCVR89', 1, 1, 0, '2018-12-11 03:33:29', '2018-12-11 03:33:29'),
(91, 'test90', '$2y$10$Cwn901WNz0V1BwQ2SfR97OKK4T1wYfXxW2ItaIgLV/4kqfa2EBo2K', NULL, NULL, 'test@test90.com', '9yMHsdioQosnyVK4iCVR90', 1, 1, 0, '2018-12-11 03:33:29', '2018-12-11 03:33:29'),
(92, 'test91', '$2y$10$CIR7HI0UCLuwQ1lE62kdUuFfO0VLpAQhRT/NuKAUHHz473Oj4DmsK', NULL, NULL, 'test@test91.com', '9yMHsdioQosnyVK4iCVR91', 1, 1, 0, '2018-12-11 03:33:30', '2018-12-11 03:33:30'),
(93, 'test92', '$2y$10$Ti2NcWLOUeut7kszvytjNu0Espv0nY9NXtYJD9lwbwMtMT33e7Ww2', NULL, NULL, 'test@test92.com', '9yMHsdioQosnyVK4iCVR92', 1, 1, 0, '2018-12-11 03:33:30', '2018-12-11 03:33:30'),
(94, 'test93', '$2y$10$JavSsGqSk0MhH298K/P.EOeauwPxJzJmBqsa6oDDDy61ddL1b5pFG', NULL, NULL, 'test@test93.com', '9yMHsdioQosnyVK4iCVR93', 1, 1, 0, '2018-12-11 03:33:30', '2018-12-11 03:33:30'),
(95, 'test94', '$2y$10$wAVtDoJDxOrHovlpjBHub.FV8FoFcss9xviRit36GEunos6Y1teXq', NULL, NULL, 'test@test94.com', '9yMHsdioQosnyVK4iCVR94', 1, 1, 0, '2018-12-11 03:33:30', '2018-12-11 03:33:30'),
(96, 'test95', '$2y$10$6igrMyo91KxHwb15SFu/wOK4dL81YwWZLRKyH9iGzghWStxEoB4lG', NULL, NULL, 'test@test95.com', '9yMHsdioQosnyVK4iCVR95', 1, 1, 0, '2018-12-11 03:33:30', '2018-12-11 03:33:30'),
(97, 'test96', '$2y$10$dkmrzCi2PFRrd1qB2Egzo.PS60rJIS/EBLjpBxT69BDOPE/xQiWwu', NULL, NULL, 'test@test96.com', '9yMHsdioQosnyVK4iCVR96', 1, 1, 0, '2018-12-11 03:33:31', '2018-12-11 03:33:31'),
(98, 'test97', '$2y$10$fgPg/GVrVATyuLZ4Zw5E8Ogo64mMbZ0VGfQigFpz4MQgRd4SCBcNO', NULL, NULL, 'test@test97.com', '9yMHsdioQosnyVK4iCVR97', 1, 1, 0, '2018-12-11 03:33:31', '2018-12-11 03:33:31'),
(99, 'test98', '$2y$10$weCTgeKWATE72Xf9Lpu/je56vrzBYERP5/MOjKESv2nunAPVehRFe', NULL, NULL, 'test@test98.com', '9yMHsdioQosnyVK4iCVR98', 1, 1, 0, '2018-12-11 03:33:31', '2018-12-11 03:33:31'),
(100, 'test99', '$2y$10$CD.Rx/xC5MEiBYH/EGg4vOLU.n3MDDUoLn1bthW1d2w6b9jCtKGbe', NULL, NULL, 'test@test99.com', '9yMHsdioQosnyVK4iCVR99', 1, 1, 0, '2018-12-11 03:33:31', '2018-12-11 03:33:31'),
(101, 'test100', '$2y$10$pvwgVu8ZwXlIKml7Jv4ZreRwtSJN2O6A3tU/ud8Dmh2v8iemLmD7e', NULL, NULL, 'test@test100.com', '9yMHsdioQosnyVK4iCVR100', 1, 1, 0, '2018-12-11 03:33:31', '2018-12-11 03:33:31'),
(102, 'test101', '$2y$10$MNihnVGeXDtEhYDX2huhMuvgbzojZm.TYztTiXW7pRecSHb3RNmuC', NULL, NULL, 'test@test101.com', '9yMHsdioQosnyVK4iCVR101', 1, 1, 0, '2018-12-11 03:33:32', '2018-12-11 03:33:32'),
(103, 'test102', '$2y$10$t.Rp/v74WQL1vz9ErjfpH..5eUnyG2Qdk.viTHhoawMQ/vvZw/uEO', NULL, NULL, 'test@test102.com', '9yMHsdioQosnyVK4iCVR102', 1, 1, 0, '2018-12-11 03:33:32', '2018-12-11 03:33:32'),
(104, 'test103', '$2y$10$ymAyTsNLcxhTYocsOYIVBuIWR7Kc6yJKM/2VRAlsRVP9ojubyX5a.', NULL, NULL, 'test@test103.com', '9yMHsdioQosnyVK4iCVR103', 1, 1, 0, '2018-12-11 03:33:32', '2018-12-11 03:33:32'),
(105, 'test104', '$2y$10$n6HwoilGhQ4lmE4C/58Sqe74Wv0ERlH.BNzOBqbXsg6jFYHk5mDRO', NULL, NULL, 'test@test104.com', '9yMHsdioQosnyVK4iCVR104', 1, 1, 0, '2018-12-11 03:33:32', '2018-12-11 03:33:32'),
(106, 'test105', '$2y$10$z35A1bYknUrPc2O3UpK3BeuhqsoMYr3G39WwMASYYoclYixCsuVau', NULL, NULL, 'test@test105.com', '9yMHsdioQosnyVK4iCVR105', 1, 1, 0, '2018-12-11 03:33:32', '2018-12-11 03:33:32'),
(107, 'test106', '$2y$10$tdtaKRwcUl0bNvty2ctqgOintRpOSn251veT9XLV7Fukf2.E56fLC', NULL, NULL, 'test@test106.com', '9yMHsdioQosnyVK4iCVR106', 1, 1, 0, '2018-12-11 03:33:33', '2018-12-11 03:33:33'),
(108, 'test107', '$2y$10$AOoAsuRHHdXz.oI4V0h0YeeAUNYLkTecRfWsdQ6GoVPx0Aodi.HPe', NULL, NULL, 'test@test107.com', '9yMHsdioQosnyVK4iCVR107', 1, 1, 0, '2018-12-11 03:33:33', '2018-12-11 03:33:33'),
(109, 'test108', '$2y$10$3RrJNFy2dLbqVsvmzaAxWugsg/o8UaKk54zqH77o80OBvxHJbRnsa', NULL, NULL, 'test@test108.com', '9yMHsdioQosnyVK4iCVR108', 1, 1, 0, '2018-12-11 03:33:33', '2018-12-11 03:33:33'),
(110, 'test109', '$2y$10$tbWkCp.4nsm3Leckem43FehnTvsCYdgd3yp6P61cRvNHwh.3703da', NULL, NULL, 'test@test109.com', '9yMHsdioQosnyVK4iCVR109', 1, 1, 0, '2018-12-11 03:33:33', '2018-12-11 03:33:33'),
(111, 'test110', '$2y$10$bqQ8yY4hws/yfHQnqKhk4uEGNSC5ofqWrmjtcCdQ6SMZf16cSHh.i', NULL, NULL, 'test@test110.com', '9yMHsdioQosnyVK4iCVR110', 1, 1, 0, '2018-12-11 03:33:34', '2018-12-11 03:33:34'),
(112, 'test111', '$2y$10$LcJ1dqPVP4wOpWRd1iyPr.xFekAi8qI2C/7HdXTWKIwHsje9RsjzC', NULL, NULL, 'test@test111.com', '9yMHsdioQosnyVK4iCVR111', 1, 1, 0, '2018-12-11 03:33:34', '2018-12-11 03:33:34'),
(113, 'test112', '$2y$10$orjgW5SVQLoJ6uVQV7cPfuAupq98XVaU2pNjYnWFRVGHIr6dTFfQq', NULL, NULL, 'test@test112.com', '9yMHsdioQosnyVK4iCVR112', 1, 1, 0, '2018-12-11 03:33:34', '2018-12-11 03:33:34'),
(114, 'test113', '$2y$10$Li062WBKS/gHSUDw1lEPee7gO8Yr5yC6.EvVBH32LSqSIAi6MAbka', NULL, NULL, 'test@test113.com', '9yMHsdioQosnyVK4iCVR113', 1, 1, 0, '2018-12-11 03:33:34', '2018-12-11 03:33:34'),
(115, 'test114', '$2y$10$lJINqPi7aqeOWyw0zBwgIu2g19hD2RcbypZGzZAhz8OD6YNbkegyC', NULL, NULL, 'test@test114.com', '9yMHsdioQosnyVK4iCVR114', 1, 1, 0, '2018-12-11 03:33:34', '2018-12-11 03:33:34'),
(116, 'test115', '$2y$10$FERBJ.yRfKxoECqdJ0Zza.DxcmW8RoPwrU2CZnYjR8Wlzvy9ug3n2', NULL, NULL, 'test@test115.com', '9yMHsdioQosnyVK4iCVR115', 1, 1, 0, '2018-12-11 03:33:35', '2018-12-11 03:33:35'),
(117, 'test116', '$2y$10$PrbvRMvR2pMSCB0D4bTVE.FtKKelw6dct0BK5.Svq.ML3MhAkc8qK', NULL, NULL, 'test@test116.com', '9yMHsdioQosnyVK4iCVR116', 1, 1, 0, '2018-12-11 03:33:35', '2018-12-11 03:33:35'),
(118, 'test117', '$2y$10$/yMrGV.EyyjsDkYNibt2O.l8mDBAkFFnGdgcfMMozeUiEDsp8yZD2', NULL, NULL, 'test@test117.com', '9yMHsdioQosnyVK4iCVR117', 1, 1, 0, '2018-12-11 03:33:35', '2018-12-11 03:33:35'),
(119, 'test118', '$2y$10$qafHXkELtxK91.hObzm4EuudygmU0kwyIaKproljj1oFSNFNkk17q', NULL, NULL, 'test@test118.com', '9yMHsdioQosnyVK4iCVR118', 1, 1, 0, '2018-12-11 03:33:35', '2018-12-11 03:33:35'),
(120, 'test119', '$2y$10$f/WEaMM/nOkyTVl5lw8I8.eSabx5rF4DWwYAEuc3AHqK.ugy8r5sG', NULL, NULL, 'test@test119.com', '9yMHsdioQosnyVK4iCVR119', 1, 1, 0, '2018-12-11 03:33:36', '2018-12-11 03:33:36'),
(121, 'test120', '$2y$10$R45XgzI7Rmr/AwFy1BQR4OgpvIqeEEpPYYvbDPBHjNNz1c6IvbTdW', NULL, NULL, 'test@test120.com', '9yMHsdioQosnyVK4iCVR120', 1, 1, 0, '2018-12-11 03:33:36', '2018-12-11 03:33:36'),
(122, 'test121', '$2y$10$UwxJCIY5GCjxbRgGZZSqFeq/7YbdiPSoh6g7Ov9XkZku803Hhhyr2', NULL, NULL, 'test@test121.com', '9yMHsdioQosnyVK4iCVR121', 1, 1, 0, '2018-12-11 03:33:36', '2018-12-11 03:33:36'),
(123, 'test122', '$2y$10$vd0qzNDli/SC4vYvcSYth.0GmgvULpd/taW3EOjFzJK3jFz9QTR6.', NULL, NULL, 'test@test122.com', '9yMHsdioQosnyVK4iCVR122', 1, 1, 0, '2018-12-11 03:33:36', '2018-12-11 03:33:36'),
(124, 'test123', '$2y$10$/w1/c6tXl5sTMK6uozC7R.6DFq4OlwKP1.uHBA48x/7NLIRs/sDBe', NULL, NULL, 'test@test123.com', '9yMHsdioQosnyVK4iCVR123', 1, 1, 0, '2018-12-11 03:33:36', '2018-12-11 03:33:36'),
(125, 'test124', '$2y$10$.KfbgLO7b/oSKDK5/nhL1u6rd8nMmSSV.HU6hdYe1xjWW/CeL0UJu', NULL, NULL, 'test@test124.com', '9yMHsdioQosnyVK4iCVR124', 1, 1, 0, '2018-12-11 03:33:36', '2018-12-11 03:33:36'),
(126, 'test125', '$2y$10$cEmGvSaekBQ8KocXC6hgYORegjPe/qSUsz/pSicl3jBNTKPT2lgae', NULL, NULL, 'test@test125.com', '9yMHsdioQosnyVK4iCVR125', 1, 1, 0, '2018-12-11 03:33:37', '2018-12-11 03:33:37'),
(127, 'test126', '$2y$10$DbA.bEc14xQOazkbvXCILOLgVmd4oTNdlIeWYYFVr/oGLiepdX7x6', NULL, NULL, 'test@test126.com', '9yMHsdioQosnyVK4iCVR126', 1, 1, 0, '2018-12-11 03:33:37', '2018-12-11 03:33:37'),
(128, 'test127', '$2y$10$knA28L7mliz58fks0sGxx.gMP5N4WwVZZ5GS90AENU2EOpKYr7weK', NULL, NULL, 'test@test127.com', '9yMHsdioQosnyVK4iCVR127', 1, 1, 0, '2018-12-11 03:33:37', '2018-12-11 03:33:37'),
(129, 'test128', '$2y$10$tpWQ/44UzyuMrnUvPf9.qeBMB0fQhfY4xpHQiIXNG7tSRejU5WNG2', NULL, NULL, 'test@test128.com', '9yMHsdioQosnyVK4iCVR128', 1, 1, 0, '2018-12-11 03:33:37', '2018-12-11 03:33:37'),
(130, 'test129', '$2y$10$l9daOJRsz8lUoiiOHMVoGegcTZn504ea6.zWV3T.gMxUpgZzX4v1W', NULL, NULL, 'test@test129.com', '9yMHsdioQosnyVK4iCVR129', 1, 1, 0, '2018-12-11 03:33:38', '2018-12-11 03:33:38'),
(131, 'test130', '$2y$10$We92pq.wUTR1hkqvEguxHukpwi79uJTvrbgjxaSTqvspD4ZJNJXna', NULL, NULL, 'test@test130.com', '9yMHsdioQosnyVK4iCVR130', 1, 1, 0, '2018-12-11 03:33:38', '2018-12-11 03:33:38'),
(132, 'test131', '$2y$10$RSU./MMExbPIhV40eTddP.pEjrUPGYuVebA/u19iKLuG3N.n8Pnkq', NULL, NULL, 'test@test131.com', '9yMHsdioQosnyVK4iCVR131', 1, 1, 0, '2018-12-11 03:33:38', '2018-12-11 03:33:38'),
(133, 'test132', '$2y$10$cD3vcIUzjk1EYDkNqaxVgeJtFES1MsKAh61NVYPFnk.KE2JBiIR1y', NULL, NULL, 'test@test132.com', '9yMHsdioQosnyVK4iCVR132', 1, 1, 0, '2018-12-11 03:33:38', '2018-12-11 03:33:38'),
(134, 'test133', '$2y$10$IwaPQptpfSGdQVnERJ0QIuXzam7wjdJ32f9tyg93wSYTsENz5i1IG', NULL, NULL, 'test@test133.com', '9yMHsdioQosnyVK4iCVR133', 1, 1, 0, '2018-12-11 03:33:39', '2018-12-11 03:33:39'),
(135, 'test134', '$2y$10$FAussbpekOdEt9L.UwdbK.hGbsxxyZdgaOcIMHU6AM373EvxwPnWa', NULL, NULL, 'test@test134.com', '9yMHsdioQosnyVK4iCVR134', 1, 1, 0, '2018-12-11 03:33:39', '2018-12-11 03:33:39'),
(136, 'test135', '$2y$10$lj9NkXKv59ALYy6yrjPB2.bgjPHczYSW8ND8ZGCtDYA7nl9l1Divu', NULL, NULL, 'test@test135.com', '9yMHsdioQosnyVK4iCVR135', 1, 1, 0, '2018-12-11 03:33:39', '2018-12-11 03:33:39'),
(137, 'test136', '$2y$10$x49N/QoWSGBktA2rabgevu9OYHlB9KfiMXHVm7KdbgrQWu6uIIoMS', NULL, NULL, 'test@test136.com', '9yMHsdioQosnyVK4iCVR136', 1, 1, 0, '2018-12-11 03:33:40', '2018-12-11 03:33:40'),
(138, 'test137', '$2y$10$h1FBclugSKgiPizU6Sphr.HXSCdfSugS9E5VsEBIqaTwK.zcKkKGu', NULL, NULL, 'test@test137.com', '9yMHsdioQosnyVK4iCVR137', 1, 1, 0, '2018-12-11 03:33:40', '2018-12-11 03:33:40'),
(139, 'test138', '$2y$10$XphoG6IYFY4gPowoNoUswOncokurtiJpeuli9pQVCr/41lcPhAwxq', NULL, NULL, 'test@test138.com', '9yMHsdioQosnyVK4iCVR138', 1, 1, 0, '2018-12-11 03:33:40', '2018-12-11 03:33:40'),
(140, 'test139', '$2y$10$9U2qHy7bRj5GTpuiF.D/zeTnsRJ04fcdchweakY5Ru9A3wbxKkp66', NULL, NULL, 'test@test139.com', '9yMHsdioQosnyVK4iCVR139', 1, 1, 0, '2018-12-11 03:33:40', '2018-12-11 03:33:40'),
(141, 'test140', '$2y$10$th6bP7D77KKYLLEQon/UL.gcpAkZ6OOQLbHIWpVSWjycZXt.dmMKO', NULL, NULL, 'test@test140.com', '9yMHsdioQosnyVK4iCVR140', 1, 1, 0, '2018-12-11 03:33:40', '2018-12-11 03:33:40'),
(142, 'test141', '$2y$10$M4y5sLhXoAgYen5BmFy8IupF6Y2FalaSYJ0h6ma6h3.hfhLNdyFRG', NULL, NULL, 'test@test141.com', '9yMHsdioQosnyVK4iCVR141', 1, 1, 0, '2018-12-11 03:33:40', '2018-12-11 03:33:40'),
(143, 'test142', '$2y$10$YuRf4jEUycgrWfLWFtIeTOl02d63J8Qg7wbscOsuXF5ANtfAwvYMm', NULL, NULL, 'test@test142.com', '9yMHsdioQosnyVK4iCVR142', 1, 1, 0, '2018-12-11 03:33:41', '2018-12-11 03:33:41'),
(144, 'test143', '$2y$10$AN/onCOyAZHxT7tkUpn3aeefl0KhyjrAzuveMsydgSUJmN8BYstDa', NULL, NULL, 'test@test143.com', '9yMHsdioQosnyVK4iCVR143', 1, 1, 0, '2018-12-11 03:33:41', '2018-12-11 03:33:41'),
(145, 'test144', '$2y$10$AYH7yte/4psQstq.mDX/1uULHmMGVLlbXZCXicAs5DskJJQmEyCje', NULL, NULL, 'test@test144.com', '9yMHsdioQosnyVK4iCVR144', 1, 1, 0, '2018-12-11 03:33:41', '2018-12-11 03:33:41'),
(146, 'test145', '$2y$10$tkIGQQijjCmOawWQ79d/4e2z.resxmcEdykbyyE83JaxOlPO1kBHG', NULL, NULL, 'test@test145.com', '9yMHsdioQosnyVK4iCVR145', 1, 1, 0, '2018-12-11 03:33:41', '2018-12-11 03:33:41'),
(147, 'test146', '$2y$10$xz7mTMSFTSILJ397ON.Ru.eGSalSe73Ae3AXBFaB1JVYXklK7srQm', NULL, NULL, 'test@test146.com', '9yMHsdioQosnyVK4iCVR146', 1, 1, 0, '2018-12-11 03:33:42', '2018-12-11 03:33:42'),
(148, 'test147', '$2y$10$iNe/66sQKbRv1fzf8DepueM8UGoG7rjQETQFbODH5pYq0cyZdYkqK', NULL, NULL, 'test@test147.com', '9yMHsdioQosnyVK4iCVR147', 1, 1, 0, '2018-12-11 03:33:42', '2018-12-11 03:33:42'),
(149, 'test148', '$2y$10$sqy9vIRuo3xDWyFqXYyFSOxl9.syl/RSG81WB5iXWmzZXRQwYbTiW', NULL, NULL, 'test@test148.com', '9yMHsdioQosnyVK4iCVR148', 1, 1, 0, '2018-12-11 03:33:42', '2018-12-11 03:33:42'),
(150, 'test149', '$2y$10$YYDbKxAJMwzr2NdtAq15oOFm4CzJP0VQVRIkCuFPGmEAxyYkggbGa', NULL, NULL, 'test@test149.com', '9yMHsdioQosnyVK4iCVR149', 1, 1, 0, '2018-12-11 03:33:42', '2018-12-11 03:33:42'),
(151, 'test150', '$2y$10$MRDKTs7792c/398r0EZHdei7BI4x1T6.y1G3P3PphzGb2zoUfn1zS', NULL, NULL, 'test@test150.com', '9yMHsdioQosnyVK4iCVR150', 1, 1, 0, '2018-12-11 03:33:42', '2018-12-11 03:33:42'),
(152, 'test151', '$2y$10$kHNBJyDYFH0zdWdujyr78.RxLHQoFsUzGsddc5dyJQ6GQ2makJS1a', NULL, NULL, 'test@test151.com', '9yMHsdioQosnyVK4iCVR151', 1, 1, 0, '2018-12-11 03:33:43', '2018-12-11 03:33:43'),
(153, 'test152', '$2y$10$iS0ZOrdWJNjzdsgB7CSucON7InSWjigietI3zCUT1MJHZ1pkDBOlm', NULL, NULL, 'test@test152.com', '9yMHsdioQosnyVK4iCVR152', 1, 1, 0, '2018-12-11 03:33:43', '2018-12-11 03:33:43'),
(154, 'test153', '$2y$10$ioFLn9P1NZUTuU/GgMH9H.OqkhwmqS8AsJ53CZyO2KFt7m2EaHw8S', NULL, NULL, 'test@test153.com', '9yMHsdioQosnyVK4iCVR153', 1, 1, 0, '2018-12-11 03:33:43', '2018-12-11 03:33:43'),
(155, 'test154', '$2y$10$47H0GWhiyYtCn3q5Z7izwOpf.GRoTrIFLay861nKuX0WCbd0NgXyi', NULL, NULL, 'test@test154.com', '9yMHsdioQosnyVK4iCVR154', 1, 1, 0, '2018-12-11 03:33:43', '2018-12-11 03:33:43'),
(156, 'test155', '$2y$10$JZuQKslYDxTqnZ7oN1rDCuv/ZeA3CuigdJzklBV4gC8kAgDkQJJjq', NULL, NULL, 'test@test155.com', '9yMHsdioQosnyVK4iCVR155', 1, 1, 0, '2018-12-11 03:33:43', '2018-12-11 03:33:43'),
(157, 'test156', '$2y$10$yVFwBamziRhF/MEidd9xTe5yLKMRe/9oM4bgDoX36EwJoMY0A75Pi', NULL, NULL, 'test@test156.com', '9yMHsdioQosnyVK4iCVR156', 1, 1, 0, '2018-12-11 03:33:44', '2018-12-11 03:33:44'),
(158, 'test157', '$2y$10$LvzbnhRYroYrKwRELi9dy.JNoXDjq7HZMOh.5.97DJ0B1vh71FAFG', NULL, NULL, 'test@test157.com', '9yMHsdioQosnyVK4iCVR157', 1, 1, 0, '2018-12-11 03:33:44', '2018-12-11 03:33:44'),
(159, 'test158', '$2y$10$8hWrPuU9znW2h8MxSLG2GOJazSFH0YecOvfcTFjPUL2zKgIcmt3bq', NULL, NULL, 'test@test158.com', '9yMHsdioQosnyVK4iCVR158', 1, 1, 0, '2018-12-11 03:33:44', '2018-12-11 03:33:44'),
(160, 'test159', '$2y$10$aBuDiCDCpxJ1YD6SST2DaeXPwIN2WNCKfg3dirxA5KGWphFIz/4z.', NULL, NULL, 'test@test159.com', '9yMHsdioQosnyVK4iCVR159', 1, 1, 0, '2018-12-11 03:33:44', '2018-12-11 03:33:44'),
(161, 'test160', '$2y$10$4F3xnCgUTPcELgJG2TRWyOSWrsTUDiZgGsvphrV6Hpw0aHOJ9BMr6', NULL, NULL, 'test@test160.com', '9yMHsdioQosnyVK4iCVR160', 1, 1, 0, '2018-12-11 03:33:44', '2018-12-11 03:33:44'),
(162, 'test161', '$2y$10$xXc2uLh4w1OaUj6cwfa.fuqJW8vmZwxbp224DUoEAb2Fachpczeda', NULL, NULL, 'test@test161.com', '9yMHsdioQosnyVK4iCVR161', 1, 1, 0, '2018-12-11 03:33:44', '2018-12-11 03:33:44'),
(163, 'test162', '$2y$10$EKcrLcPF0APWbCCGKUDbnuIROXcQOsWJ8M9mY7OdJI43.OIv.5Csq', NULL, NULL, 'test@test162.com', '9yMHsdioQosnyVK4iCVR162', 1, 1, 0, '2018-12-11 03:33:45', '2018-12-11 03:33:45'),
(164, 'test163', '$2y$10$KkFXeB3GwwCRJeI4mBRTC.5JldFnlQgdIMVqm1XCcs8/asadJrqrK', NULL, NULL, 'test@test163.com', '9yMHsdioQosnyVK4iCVR163', 1, 1, 0, '2018-12-11 03:33:45', '2018-12-11 03:33:45'),
(165, 'test164', '$2y$10$CxkwW8pUdJdIs8fzHKaviefwxw1GN9dQDBXS12BHnfpcApRydkogm', NULL, NULL, 'test@test164.com', '9yMHsdioQosnyVK4iCVR164', 1, 1, 0, '2018-12-11 03:33:45', '2018-12-11 03:33:45'),
(166, 'test165', '$2y$10$bg.pLGY1qBCoLXJeCS3Bcuhz7oql1iVcWF8.Ta9web2beJmUYf7by', NULL, NULL, 'test@test165.com', '9yMHsdioQosnyVK4iCVR165', 1, 1, 0, '2018-12-11 03:33:45', '2018-12-11 03:33:45'),
(167, 'test166', '$2y$10$BuMTXlW.s3s9fN8rWdwOUO.UmZJwNbCp30RFLK6Y7B.Wg/x.kp0Ua', NULL, NULL, 'test@test166.com', '9yMHsdioQosnyVK4iCVR166', 1, 1, 0, '2018-12-11 03:33:46', '2018-12-11 03:33:46'),
(168, 'test167', '$2y$10$SekqRwitr99zpzPI0tLfL.06OjacJ9YTLr4gqT.7Pvi3emArIcrgm', NULL, NULL, 'test@test167.com', '9yMHsdioQosnyVK4iCVR167', 1, 1, 0, '2018-12-11 03:33:46', '2018-12-11 03:33:46'),
(169, 'test168', '$2y$10$u8vvT6pV2vCHv7Vbev7YxeoPrG3IT89dGk7b89Pz1WxUDfMC8S75W', NULL, NULL, 'test@test168.com', '9yMHsdioQosnyVK4iCVR168', 1, 1, 0, '2018-12-11 03:33:46', '2018-12-11 03:33:46'),
(170, 'test169', '$2y$10$JI6EWpb1yz6MwDwfJQSGyeRP1.4a79pZL5xCTbTHdHKBL8RMFwPo2', NULL, NULL, 'test@test169.com', '9yMHsdioQosnyVK4iCVR169', 1, 1, 0, '2018-12-11 03:33:47', '2018-12-11 03:33:47'),
(171, 'test170', '$2y$10$U5kPvuIHWGc0PIJTLdcgi.7c/eO4Jgd44fZLyv9s60brTlR4TKf56', NULL, NULL, 'test@test170.com', '9yMHsdioQosnyVK4iCVR170', 1, 1, 0, '2018-12-11 03:33:48', '2018-12-11 03:33:48'),
(172, 'test171', '$2y$10$Tl8.E/bFOai.Sa2Q7wZQxOV48q7VZ00WjEoiP3CQTey7VL8colYQu', NULL, NULL, 'test@test171.com', '9yMHsdioQosnyVK4iCVR171', 1, 1, 0, '2018-12-11 03:33:48', '2018-12-11 03:33:48'),
(173, 'test172', '$2y$10$lQipibYNniUmg5D2TAVQ9.opzeVQ37QpkEaxfvfRatOvvoTYUnQhK', NULL, NULL, 'test@test172.com', '9yMHsdioQosnyVK4iCVR172', 1, 1, 0, '2018-12-11 03:33:48', '2018-12-11 03:33:48'),
(174, 'test173', '$2y$10$9BOKrw2ChyCIenulc0RqZeDY3yV88elz26D/r3v4ZlT7BjVlPPA7u', NULL, NULL, 'test@test173.com', '9yMHsdioQosnyVK4iCVR173', 1, 1, 0, '2018-12-11 03:33:48', '2018-12-11 03:33:48'),
(175, 'test174', '$2y$10$0Omeq7nQu.eq8gOJfOlUauk428wVbe9uqRh11rcwhRlSShz4iCvt.', NULL, NULL, 'test@test174.com', '9yMHsdioQosnyVK4iCVR174', 1, 1, 0, '2018-12-11 03:33:49', '2018-12-11 03:33:49'),
(176, 'test175', '$2y$10$K7w7z30fcwlNcEWqMJSitud3Eh3WS530feG502847S9BDoR2otGz.', NULL, NULL, 'test@test175.com', '9yMHsdioQosnyVK4iCVR175', 1, 1, 0, '2018-12-11 03:33:49', '2018-12-11 03:33:49'),
(177, 'test176', '$2y$10$IJaPvaKwQE8wUMeSVQ3SH.3ZcfW0KKGRYF1MHxd9Qyl0OrhHHYj/y', NULL, NULL, 'test@test176.com', '9yMHsdioQosnyVK4iCVR176', 1, 1, 0, '2018-12-11 03:33:49', '2018-12-11 03:33:49'),
(178, 'test177', '$2y$10$wBmF9WBemz.6.RR0D7QQSOq6SoGRDAEwkDHw0OzWZPX.4MrRixozW', NULL, NULL, 'test@test177.com', '9yMHsdioQosnyVK4iCVR177', 1, 1, 0, '2018-12-11 03:33:49', '2018-12-11 03:33:49'),
(179, 'test178', '$2y$10$nyTRjUEG9rExNlarLMC6YOTZAMu7EZjrUPoTviqmtohnKpPWt1GFm', NULL, NULL, 'test@test178.com', '9yMHsdioQosnyVK4iCVR178', 1, 1, 0, '2018-12-11 03:33:49', '2018-12-11 03:33:49'),
(180, 'test179', '$2y$10$Fde4TpbyRtNcI8b5aUycDuGFwJFppaB8WA8zNc7umAlwsMkPsY26S', NULL, NULL, 'test@test179.com', '9yMHsdioQosnyVK4iCVR179', 1, 1, 0, '2018-12-11 03:33:49', '2018-12-11 03:33:49'),
(181, 'test180', '$2y$10$mSRpMFh28ARQFaHloLGO1Ogb3OJ6H2cD7Vf8G1VYN/vNr7ON1Svdi', NULL, NULL, 'test@test180.com', '9yMHsdioQosnyVK4iCVR180', 1, 1, 0, '2018-12-11 03:33:50', '2018-12-11 03:33:50'),
(182, 'test181', '$2y$10$bq1t5wKlTIEGB7dCAn0mD.lliQ3b6GVOQwXRe2likbmD8y0sFq0nS', NULL, NULL, 'test@test181.com', '9yMHsdioQosnyVK4iCVR181', 1, 1, 0, '2018-12-11 03:33:50', '2018-12-11 03:33:50'),
(183, 'test182', '$2y$10$a5PGHjpLPzIENWz0a14lNOQK7tEIZAjrD6FqntUeU1jySH8MF.Evm', NULL, NULL, 'test@test182.com', '9yMHsdioQosnyVK4iCVR182', 1, 1, 0, '2018-12-11 03:33:50', '2018-12-11 03:33:50'),
(184, 'test183', '$2y$10$xJkjqHPggHJHR6H.toPJzOJFiM0yOygIqvj8bqKjRHn/c68CXRFIC', NULL, NULL, 'test@test183.com', '9yMHsdioQosnyVK4iCVR183', 1, 1, 0, '2018-12-11 03:33:50', '2018-12-11 03:33:50'),
(185, 'test184', '$2y$10$PkLdmvlOFeqWGoHVRSpsyeZC54dqfjEsxmwNp1BLZhiM38rP97TQm', NULL, NULL, 'test@test184.com', '9yMHsdioQosnyVK4iCVR184', 1, 1, 0, '2018-12-11 03:33:50', '2018-12-11 03:33:50'),
(186, 'test185', '$2y$10$tCqT.cKXEVNPteD1FRg3bunhF06zg6hjZhOJXwAyOU5pIykNYiNw2', NULL, NULL, 'test@test185.com', '9yMHsdioQosnyVK4iCVR185', 1, 1, 0, '2018-12-11 03:33:51', '2018-12-11 03:33:51'),
(187, 'test186', '$2y$10$pwXeAPDuh5S/H8mmSuT3OuVg31zEABKANfBemyTJfphwgL3a6Lt/S', NULL, NULL, 'test@test186.com', '9yMHsdioQosnyVK4iCVR186', 1, 1, 0, '2018-12-11 03:33:51', '2018-12-11 03:33:51'),
(188, 'test187', '$2y$10$4HbqF9c.3H03bP4mbA6iEuJSdoJJInFLc0G30ZlucP9jXTBmSTtP6', NULL, NULL, 'test@test187.com', '9yMHsdioQosnyVK4iCVR187', 1, 1, 0, '2018-12-11 03:33:51', '2018-12-11 03:33:51'),
(189, 'test188', '$2y$10$kfLyrjeMLxwTkOCAZ6kRse1kNXwPgkV/I0LxdxJ8SbNzvv3IB9SRK', NULL, NULL, 'test@test188.com', '9yMHsdioQosnyVK4iCVR188', 1, 1, 0, '2018-12-11 03:33:51', '2018-12-11 03:33:51'),
(190, 'test189', '$2y$10$dAvExJcChOSFtiIh9bAlOu4XtgSjiRlEesEenrV9lw8C7ihQRzZj2', NULL, NULL, 'test@test189.com', '9yMHsdioQosnyVK4iCVR189', 1, 1, 0, '2018-12-11 03:33:51', '2018-12-11 03:33:51'),
(191, 'test190', '$2y$10$fHR8eOXJoUb6sjgZjqZSJ.NwkcTOEZxMBqt1i80VhJA8Ia897bYEO', NULL, NULL, 'test@test190.com', '9yMHsdioQosnyVK4iCVR190', 1, 1, 0, '2018-12-11 03:33:52', '2018-12-11 03:33:52'),
(192, 'test191', '$2y$10$1DGvXw0D8JxwmLOiYgUwjeYNrACDlZeG3LYoXfUv26XMxKFXM2Xim', NULL, NULL, 'test@test191.com', '9yMHsdioQosnyVK4iCVR191', 1, 1, 0, '2018-12-11 03:33:52', '2018-12-11 03:33:52'),
(193, 'test192', '$2y$10$hvmNIh3JJcdmFfqlGTAxq.JUOlA1Zt3Vel3u6VTbZlxmdn9ypbSr.', NULL, NULL, 'test@test192.com', '9yMHsdioQosnyVK4iCVR192', 1, 1, 0, '2018-12-11 03:33:52', '2018-12-11 03:33:52'),
(194, 'test193', '$2y$10$nhZMXWC9QGpdb22tRuu2KOy/Gg.kSurr/s0m9qyl5DGwGApeH8/3.', NULL, NULL, 'test@test193.com', '9yMHsdioQosnyVK4iCVR193', 1, 1, 0, '2018-12-11 03:33:52', '2018-12-11 03:33:52'),
(195, 'test194', '$2y$10$5FFN7TAaOyb/5Bz/.G6uKOsXrShVTRdS90VNxty3HAt.SAa8PpfdK', NULL, NULL, 'test@test194.com', '9yMHsdioQosnyVK4iCVR194', 1, 1, 0, '2018-12-11 03:33:52', '2018-12-11 03:33:52'),
(196, 'test195', '$2y$10$2SN6qL7y81kGOPu4fjJuYegdtHdM8OF7pWUVSrxrlD0QMCift.hJi', NULL, NULL, 'test@test195.com', '9yMHsdioQosnyVK4iCVR195', 1, 1, 0, '2018-12-11 03:33:53', '2018-12-11 03:33:53'),
(197, 'test196', '$2y$10$YG6fcFEftgLZ.rcWDcDSt.aNG6FEUbXjsJ/z5N8VFSRNO7l7gclgm', NULL, NULL, 'test@test196.com', '9yMHsdioQosnyVK4iCVR196', 1, 1, 0, '2018-12-11 03:33:53', '2018-12-11 03:33:53'),
(198, 'test197', '$2y$10$P3mFBVYMi8A.86fpkSUOBeY6AiBmToaTW4JkEI5xvT8Bdm5ottOgu', NULL, NULL, 'test@test197.com', '9yMHsdioQosnyVK4iCVR197', 1, 1, 0, '2018-12-11 03:33:53', '2018-12-11 03:33:53'),
(199, 'test198', '$2y$10$ZYXKuzzsLKJAcP1NNwbfpeU.Tj2KHxUuUlnPfih3jPkAMuC/ARayy', NULL, NULL, 'test@test198.com', '9yMHsdioQosnyVK4iCVR198', 1, 1, 0, '2018-12-11 03:33:54', '2018-12-11 03:33:54'),
(200, 'test199', '$2y$10$SPlSlEj6TNlDPwx5kMab5eShBT.CCBFXBKJ8XHUYkGOwx.1gkgeoq', NULL, NULL, 'test@test199.com', '9yMHsdioQosnyVK4iCVR199', 1, 1, 0, '2018-12-11 03:33:54', '2018-12-11 03:33:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `actions`
--
ALTER TABLE `actions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `actions_user_id_index` (`user_id`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD UNIQUE KEY `cache_key_unique` (`key`);

--
-- Indexes for table `components`
--
ALTER TABLE `components`
  ADD PRIMARY KEY (`id`),
  ADD KEY `components_group_id_index` (`group_id`),
  ADD KEY `components_status_index` (`status`),
  ADD KEY `components_order_index` (`order`);

--
-- Indexes for table `component_groups`
--
ALTER TABLE `component_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `component_groups_order_index` (`order`),
  ADD KEY `component_groups_visible_index` (`visible`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `incidents`
--
ALTER TABLE `incidents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `incidents_component_id_index` (`component_id`),
  ADD KEY `incidents_status_index` (`status`),
  ADD KEY `incidents_visible_index` (`visible`),
  ADD KEY `incidents_stickied_index` (`stickied`),
  ADD KEY `incidents_user_id_index` (`user_id`);

--
-- Indexes for table `incident_components`
--
ALTER TABLE `incident_components`
  ADD PRIMARY KEY (`id`),
  ADD KEY `incident_components_incident_id_index` (`incident_id`),
  ADD KEY `incident_components_component_id_index` (`component_id`),
  ADD KEY `incident_components_status_id_index` (`status_id`);

--
-- Indexes for table `incident_templates`
--
ALTER TABLE `incident_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `incident_updates`
--
ALTER TABLE `incident_updates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `incident_updates_incident_id_index` (`incident_id`);

--
-- Indexes for table `invites`
--
ALTER TABLE `invites`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `invites_code_unique` (`code`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `meta`
--
ALTER TABLE `meta`
  ADD PRIMARY KEY (`id`),
  ADD KEY `meta_meta_id_meta_type_index` (`meta_id`,`meta_type`),
  ADD KEY `meta_key_index` (`key`);

--
-- Indexes for table `metrics`
--
ALTER TABLE `metrics`
  ADD PRIMARY KEY (`id`),
  ADD KEY `metrics_display_chart_index` (`display_chart`),
  ADD KEY `metrics_visible_index` (`visible`);

--
-- Indexes for table `metric_points`
--
ALTER TABLE `metric_points`
  ADD PRIMARY KEY (`id`),
  ADD KEY `metric_points_metric_id_index` (`metric_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schedule_components`
--
ALTER TABLE `schedule_components`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD UNIQUE KEY `sessions_id_unique` (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `subscribers_email_unique` (`email`);

--
-- Indexes for table `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subscriptions_subscriber_id_index` (`subscriber_id`),
  ADD KEY `subscriptions_component_id_index` (`component_id`);

--
-- Indexes for table `taggables`
--
ALTER TABLE `taggables`
  ADD PRIMARY KEY (`id`),
  ADD KEY `taggables_taggable_type_taggable_id_index` (`taggable_type`,`taggable_id`),
  ADD KEY `taggables_tag_id_index` (`tag_id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tags_name_slug_unique` (`name`,`slug`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_username_unique` (`username`),
  ADD UNIQUE KEY `users_api_key_unique` (`api_key`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_remember_token_index` (`remember_token`),
  ADD KEY `users_active_index` (`active`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `actions`
--
ALTER TABLE `actions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `components`
--
ALTER TABLE `components`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;

--
-- AUTO_INCREMENT for table `component_groups`
--
ALTER TABLE `component_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `incidents`
--
ALTER TABLE `incidents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;

--
-- AUTO_INCREMENT for table `incident_components`
--
ALTER TABLE `incident_components`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `incident_templates`
--
ALTER TABLE `incident_templates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `incident_updates`
--
ALTER TABLE `incident_updates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;

--
-- AUTO_INCREMENT for table `invites`
--
ALTER TABLE `invites`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `meta`
--
ALTER TABLE `meta`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `metrics`
--
ALTER TABLE `metrics`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;

--
-- AUTO_INCREMENT for table `metric_points`
--
ALTER TABLE `metric_points`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;

--
-- AUTO_INCREMENT for table `schedule_components`
--
ALTER TABLE `schedule_components`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20648;

--
-- AUTO_INCREMENT for table `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscriptions`
--
ALTER TABLE `subscriptions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `taggables`
--
ALTER TABLE `taggables`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
